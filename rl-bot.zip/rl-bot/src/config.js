'use strict';
// Toda a configuração do bot em um lugar só.
// O que muda com frequência (preços, prazo, cargos) fica aqui; segredos ficam no .env.

const path = require('path');
require('dotenv').config();

const env = process.env;
const RAIZ = path.join(__dirname, '..');

function numero(valor, padrao) {
  if (valor === undefined || valor === '') return padrao;
  const n = Number(valor);
  return Number.isFinite(n) ? n : padrao;
}

const config = {
  raiz: RAIZ,

  token: env.DISCORD_TOKEN,
  clientId: env.CLIENT_ID,
  guildId: env.GUILD_ID,

  canais: {
    tickets: env.TICKET_FORUM_ID,
    avaliacoes: env.AVALIACOES_CHANNEL_ID,
    avisos: env.CANAL_AVISOS_ID || null,
  },

  // Cargos: se o ID estiver no .env usa o ID; senão procura pelo nome (igual ao bot antigo)
  cargos: {
    suporte: { id: env.CARGO_SUPORTE_ID || null, nome: '・suporte' },
    cliente: { id: env.CARGO_CLIENT_ID || null, nome: '・client' },
    chaveAutorizados: (env.CARGOS_CHAVE_AUTORIZADOS || '').split(',').map(x => x.trim()).filter(Boolean),
    chaveMonitorados: (env.CARGOS_CHAVE_MONITORADOS || '1544387069294416053').split(',').map(x => x.trim()).filter(Boolean),
    superioresAlertas: (env.CARGOS_SUPERIORES_ALERTAS || '1540193298424008854').split(',').map(x => x.trim()).filter(Boolean),
  },

  pix: {
    chave: env.PIX_CHAVE || '',
    nome: env.PIX_NOME || 'Arthur Vieira',
  },

  // O QUE O CLIENTE PODE COMPRAR. O valor esperado do comprovante vem daqui.
  // (a tabela exibida no /valores continua sendo o texto original, em src/conteudo.js)
  produtos: {
    clean_30: { tipo: 'CLEAN', label: 'Clean de 30s', precoCentavos: 1000 },
    clean_60: { tipo: 'CLEAN', label: 'Clean de 1min', precoCentavos: 1500 },
    avancada_30: { tipo: 'AVANCADA', label: 'Avançada de 30s', precoCentavos: 1500 },
    avancada_60: { tipo: 'AVANCADA', label: 'Avançada de 1min', precoCentavos: 2000 },
    // ticket "Postar com Qualidade": só confirma o pagamento, não entra em fila
    postar_qualidade: { tipo: null, label: 'Postagem em máxima qualidade', precoCentavos: 300 },
  },

  // ADICIONAIS: valores extras que se somam ao produto (ex.: Clean 30s R$ 10 + R$ 5 = R$ 15)
  adicionais: {
    prioridade: { label: 'prioridade na fila', precoCentavos: 500 },
  },

  // Como o ticket "Adquirir Edit" abre. false = igual ao Rio Bot (sem menu de produto);
  // o tipo/valor é definido pela equipe ao confirmar o pagamento. true = menu de produtos no ticket.
  ticket: {
    menuProduto: env.MENU_PRODUTO === 'sim',
  },

  // Fechar ticket pelo botão: o tópico é trancado na hora e, depois de X dias,
  // a equipe é avisada (com ping no suporte) para confirmar a exclusão.
  fechamento: {
    apagarAposDias: numero(env.APAGAR_APOS_DIAS, 3),
  },

  prazo: {
    horas: 42, // conta a partir da entrada em produção
    avisoHorasAntes: 12, // avisa a equipe quando faltar isso (ou menos)
  },

  fila: {
    limiteAcumulada: numero(env.LIMITE_FILA_ACUMULADA, 0), // 0 = desligado
  },

  pagamento: {
    // padrão: manual (a equipe confirma com um clique). 'auto' só liga com PAGAMENTO_MODO=auto
    modo: env.PAGAMENTO_MODO === 'auto' ? 'auto' : 'manual',
  },

  painel: {
    debounceMs: 2500, // junta várias mudanças seguidas em uma única edição
    atualizacaoPeriodicaMs: 60 * 1000,
  },

  alertas: {
    verificacaoMs: 5 * 60 * 1000,
  },

  fusoHorario: 'America/Sao_Paulo',

  dbPath: env.DB_PATH || path.join(RAIZ, 'data', 'bot.sqlite'),

  // Onde procurar o dados-edits.json do bot antigo para migrar a contagem de edits
  arquivosEditsLegado: [
    path.join(RAIZ, 'dados-edits.json'),
    path.join(RAIZ, 'data', 'dados-edits.json'),
  ],

  // Cargos de nível por quantidade de edits (nomes IDÊNTICOS aos do Discord)
  niveisPorEdits: [
    { minimo: 1, cargo: '・client' },
    { minimo: 3, cargo: '・silver' },
    { minimo: 5, cargo: '・gold' },
    { minimo: 10, cargo: '・platinum' },
    { minimo: 15, cargo: '・emerald' },
    { minimo: 20, cargo: '・ruby' },
    { minimo: 30, cargo: '・royalty' },
  ],
};

module.exports = config;
