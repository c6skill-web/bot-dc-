'use strict';
// Banco de dados (SQLite). É a FONTE DA VERDADE dos tickets e das filas:
// o nome do tópico no Discord é só um reflexo visual do que está aqui.

const fs = require('fs');
const path = require('path');

// Cada item é uma migração. Para mudar o banco no futuro, ADICIONE um novo item
// no fim da lista (nunca edite os antigos).
const MIGRACOES = [
  `
  CREATE TABLE meta (
    chave TEXT PRIMARY KEY,
    valor TEXT
  );

  CREATE TABLE tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id TEXT NOT NULL UNIQUE,
    parent_id TEXT,
    user_id TEXT NOT NULL,
    user_name TEXT,
    nome_base TEXT,
    categoria TEXT NOT NULL,
    produto TEXT,
    tipo TEXT,                      -- CLEAN | AVANCADA | NULL
    preco_centavos INTEGER,
    status TEXT NOT NULL,           -- ABERTO, AGUARDANDO_PAGAMENTO, PAGO, NA_FILA, EM_PRODUCAO, EM_PROCESSO, RENDERIZANDO, ENTREGUE, CANCELADO
    fila_numero INTEGER,
    criado_em INTEGER NOT NULL,
    pago_em INTEGER,
    na_fila_em INTEGER,
    producao_em INTEGER,
    prazo_em INTEGER,
    entregue_em INTEGER,
    cancelado_em INTEGER,
    aviso_prazo_enviado INTEGER NOT NULL DEFAULT 0,
    atraso_enviado INTEGER NOT NULL DEFAULT 0,
    importado INTEGER NOT NULL DEFAULT 0
  );

  -- Uma pessoa só pode ter 1 ticket ativo (igual ao bot antigo)
  CREATE UNIQUE INDEX ux_ticket_ativo_usuario
    ON tickets(user_id) WHERE status NOT IN ('ENTREGUE','CANCELADO');

  -- Não existem dois pedidos ativos com o mesmo número na mesma fila
  CREATE UNIQUE INDEX ux_fila_numero_ativo
    ON tickets(tipo, fila_numero)
    WHERE fila_numero IS NOT NULL AND status NOT IN ('ENTREGUE','CANCELADO');

  CREATE INDEX ix_tickets_status ON tickets(status);

  CREATE TABLE ticket_eventos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    em INTEGER NOT NULL,
    tipo TEXT NOT NULL,
    ator_id TEXT,
    ator_nome TEXT,
    detalhe TEXT
  );
  CREATE INDEX ix_eventos_ticket ON ticket_eventos(ticket_id);

  CREATE TABLE pagamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    user_id TEXT NOT NULL,
    valor_centavos INTEGER,
    tx_id TEXT,
    hash_imagem TEXT,
    modo TEXT NOT NULL,             -- auto | manual
    confirmado_por TEXT,
    em INTEGER NOT NULL
  );
  -- Um comprovante (ID de transação OU a mesma imagem) nunca vale duas vezes
  CREATE UNIQUE INDEX ux_pagamento_tx ON pagamentos(tx_id) WHERE tx_id IS NOT NULL;
  CREATE UNIQUE INDEX ux_pagamento_hash ON pagamentos(hash_imagem) WHERE hash_imagem IS NOT NULL;

  -- Último número usado em cada fila (CLEAN / AVANCADA)
  CREATE TABLE contadores (
    tipo TEXT PRIMARY KEY,
    ultimo INTEGER NOT NULL
  );

  -- Contagem de edits por cliente (substitui o dados-edits.json)
  CREATE TABLE edits (
    user_id TEXT PRIMARY KEY,
    total INTEGER NOT NULL
  );
  `,
  // 2: adicional de prioridade na fila (R$ 5)
  `
  ALTER TABLE tickets ADD COLUMN prioridade INTEGER NOT NULL DEFAULT 0;
  `,
  // 3: fechar ticket pelo botão (status FECHADO) e apagar o tópico depois de alguns dias
  `
  ALTER TABLE tickets ADD COLUMN fechado_em INTEGER;
  ALTER TABLE tickets ADD COLUMN apagar_aviso_enviado INTEGER NOT NULL DEFAULT 0;
  ALTER TABLE tickets ADD COLUMN apagado_em INTEGER;

  DROP INDEX ux_ticket_ativo_usuario;
  DROP INDEX ux_fila_numero_ativo;
  CREATE UNIQUE INDEX ux_ticket_ativo_usuario
    ON tickets(user_id) WHERE status NOT IN ('ENTREGUE','CANCELADO','FECHADO');
  CREATE UNIQUE INDEX ux_fila_numero_ativo
    ON tickets(tipo, fila_numero)
    WHERE fila_numero IS NOT NULL AND status NOT IN ('ENTREGUE','CANCELADO','FECHADO');
  `,
  `
  CREATE TABLE alertas_seguranca (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    em INTEGER NOT NULL,
    tipo TEXT NOT NULL,
    usuario_id TEXT,
    usuario_nome TEXT,
    cargo_id TEXT,
    thread_id TEXT,
    ticket_id INTEGER,
    detalhe TEXT NOT NULL,
    mensagem_id TEXT
  );
  CREATE INDEX ix_alertas_seguranca_em ON alertas_seguranca(em DESC);
  ALTER TABLE tickets ADD COLUMN chave_autorizada_em INTEGER;
  ALTER TABLE tickets ADD COLUMN chave_autorizada_por TEXT;
  `,
];

function criarBanco(caminho, Driver) {
  const Database = Driver || require('./sqlite').BancoSqlite;

  if (caminho !== ':memory:') fs.mkdirSync(path.dirname(caminho), { recursive: true });

  const db = new Database(caminho);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');

  const versaoAtual = db.prepare('PRAGMA user_version').get().user_version;
  for (let v = versaoAtual; v < MIGRACOES.length; v++) {
    const aplicar = db.transaction(() => {
      db.exec(MIGRACOES[v]);
      db.exec(`PRAGMA user_version = ${v + 1}`);
    });
    aplicar();
  }

  return db;
}

// Helpers de "meta" (chave/valor) usados pelo painel e pelos alertas
function lerMeta(db, chave) {
  const linha = db.prepare('SELECT valor FROM meta WHERE chave = ?').get(chave);
  return linha ? linha.valor : null;
}

function gravarMeta(db, chave, valor) {
  if (valor === null || valor === undefined) {
    db.prepare('DELETE FROM meta WHERE chave = ?').run(chave);
    return;
  }
  db.prepare(
    'INSERT INTO meta (chave, valor) VALUES (?, ?) ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor'
  ).run(chave, String(valor));
}

module.exports = { criarBanco, lerMeta, gravarMeta, MIGRACOES };
