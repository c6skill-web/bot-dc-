'use strict';
// Nome do tópico (ticket) no Discord. Os formatos são os MESMOS do bot antigo,
// para a equipe continuar reconhecendo tudo:
//   🎥 (FILA 7 - CLEAN) cliente (id)      🎥 (EM PRODUÇÃO) cliente (id)
//   🎥 (EM PROCESSO) ...                  🎥 (RENDERIZANDO) ...
//   🎥 (✅ENTREGUE) ...                    ❌ (CANCELADO) ...  (novo)

const ROTULO_TIPO = { CLEAN: 'CLEAN', AVANCADA: 'AVANÇADA' };

function rotuloTipo(tipo) {
  return ROTULO_TIPO[tipo] || null;
}

// remove emoji do início e/ou uma marcação de status antiga entre parênteses
function limparNomeBase(nomeAtual) {
  return String(nomeAtual)
    .replace(/^\p{Extended_Pictographic}\uFE0F?\s*/u, '')
    .replace(/^\([^)]*\)\s*/u, '')
    .trim();
}

// Nome que o tópico DEVE ter, de acordo com o estado do ticket no banco.
// Retorna null quando o ticket ainda não deve ser renomeado (antes de entrar na fila).
function nomeDoTicket(ticket) {
  const base = ticket.nome_base || `${ticket.user_name || 'cliente'} (${ticket.user_id})`;
  let prefixo;

  switch (ticket.status) {
    case 'NA_FILA': {
      const tipo = rotuloTipo(ticket.tipo);
      const num = ticket.fila_numero != null ? ticket.fila_numero : '?';
      prefixo = `🎥 ${tipo ? `(FILA ${num} - ${tipo})` : `(FILA ${num})`}`;
      break;
    }
    case 'EM_PRODUCAO':
      prefixo = '🎥 (EM PRODUÇÃO)';
      break;
    case 'EM_PROCESSO':
      prefixo = '🎥 (EM PROCESSO)';
      break;
    case 'RENDERIZANDO':
      prefixo = '🎥 (RENDERIZANDO)';
      break;
    case 'ENTREGUE':
      prefixo = '🎥 (✅ENTREGUE)';
      break;
    case 'CANCELADO':
      prefixo = '❌ (CANCELADO)';
      break;
    default:
      return null;
  }

  return `${prefixo} ${base}`.slice(0, 100);
}

// Lê o nome de um tópico existente (usado para importar tickets do bot antigo / Rio Bot)
function interpretarNome(nome) {
  const texto = String(nome);
  const ids = [...texto.matchAll(/\((\d{17,20})\)/g)];
  const userId = ids.length ? ids[ids.length - 1][1] : null;

  const base = limparNomeBase(texto);
  const userName = userId ? base.replace(/\s*\(\d{17,20}\)\s*$/, '').trim() : base;

  const emoji = (texto.match(/^(\p{Extended_Pictographic})/u) || [])[1] || null;
  const normal = texto.toUpperCase();

  let status = null;
  let filaNumero = null;
  let tipo = null;

  const fila = normal.match(/\(FILA\s+(\d+)(?:\s*-\s*(CLEAN|AVAN[CÇ]ADA))?\)/);
  if (fila) {
    status = 'NA_FILA';
    filaNumero = Number(fila[1]);
    if (fila[2]) tipo = fila[2].startsWith('AVAN') ? 'AVANCADA' : 'CLEAN';
  } else if (/\(EM PRODU[ÇC][ÃA]O\)/.test(normal)) status = 'EM_PRODUCAO';
  else if (/\(EM PROCESSO\)/.test(normal)) status = 'EM_PROCESSO';
  else if (/\(RENDERIZANDO\)/.test(normal)) status = 'RENDERIZANDO';
  else if (/ENTREGUE\)/.test(normal)) status = 'ENTREGUE';
  else if (/\(CANCELADO\)/.test(normal)) status = 'CANCELADO';

  return { userId, userName, base, emoji, status, filaNumero, tipo };
}

// ----- usados só para tickets que o bot ainda não conhece (modo legado) -----

function nomeComEntregueLegado(nomeAtual) {
  return `🎥 (✅ENTREGUE) ${limparNomeBase(nomeAtual)}`.slice(0, 100);
}

function nomeComStatusLegado(nomeAtual, { fila, tipo, producao, processo, renderizando }) {
  const nome = limparNomeBase(nomeAtual);
  let prefixo;
  if (producao) prefixo = '(EM PRODUÇÃO)';
  else if (processo) prefixo = '(EM PROCESSO)';
  else if (renderizando) prefixo = '(RENDERIZANDO)';
  else prefixo = tipo ? `(FILA ${fila} - ${tipo})` : `(FILA ${fila})`;
  return `🎥 ${prefixo} ${nome}`.slice(0, 100);
}

module.exports = {
  rotuloTipo,
  limparNomeBase,
  nomeDoTicket,
  interpretarNome,
  nomeComEntregueLegado,
  nomeComStatusLegado,
};
