'use strict';
// Funções de tempo/dinheiro usadas no painel, nos avisos e na validação de comprovante.

function formatarDuracao(ms) {
  const totalMin = Math.max(0, Math.floor(ms / 60000));
  if (totalMin < 1) return '<1min';
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h === 0) return `${m}min`;
  return `${h}h${String(m).padStart(2, '0')}`;
}

function formatarReais(centavos) {
  return `R$ ${(centavos / 100).toFixed(2).replace('.', ',')}`;
}

// "AAAA-MM-DD" do dia em que o instante cai no fuso informado (padrão: São Paulo)
function diaNoFuso(ms, fuso = 'America/Sao_Paulo') {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: fuso,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(ms));
}

module.exports = { formatarDuracao, formatarReais, diaNoFuso };
