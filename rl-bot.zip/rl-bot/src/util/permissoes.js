'use strict';
// Quem pode o quê. Cargo por ID (se estiver no .env) ou, como no bot antigo, pelo nome.

const { PermissionFlagsBits } = require('discord.js');

// "Equipe" = quem tem o cargo de suporte (por ID ou nome) OU é administrador do servidor
function temCargo(member, cargoConfig) {
  if (!member || !member.roles || !member.roles.cache) return false;
  if (member.permissions?.has?.(PermissionFlagsBits.Administrator)) return true;
  return member.roles.cache.some(
    (role) => (cargoConfig.id && role.id === cargoConfig.id) || role.name === cargoConfig.nome
  );
}

function acharCargo(guild, cargoConfig) {
  if (!guild) return null;
  return (
    (cargoConfig.id && guild.roles.cache.get(cargoConfig.id)) ||
    guild.roles.cache.find((r) => r.name === cargoConfig.nome) ||
    null
  );
}

module.exports = { temCargo, acharCargo };
