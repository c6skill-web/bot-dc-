'use strict';
// SQLite embutido no Node (node:sqlite, Node 22.13+): não precisa instalar nem compilar nada.
// Este adaptador só dá a ele a mesma "cara" simples que o resto do bot usa
// (prepare().run/get/all, exec e transaction), com transações que podem se aninhar.

const { DatabaseSync } = require('node:sqlite');

class BancoSqlite {
  constructor(caminho) {
    this.db = new DatabaseSync(caminho);
    this.nivel = 0;
  }

  exec(sql) {
    return this.db.exec(sql);
  }

  prepare(sql) {
    const st = this.db.prepare(sql);
    return {
      run: (...a) => st.run(...a),
      get: (...a) => st.get(...a),
      all: (...a) => st.all(...a),
    };
  }

  transaction(fn) {
    return (...args) => {
      if (this.nivel > 0) return fn(...args); // já está dentro de uma transação
      this.db.exec('BEGIN IMMEDIATE');
      this.nivel++;
      try {
        const r = fn(...args);
        this.db.exec('COMMIT');
        return r;
      } catch (erro) {
        this.db.exec('ROLLBACK');
        throw erro;
      } finally {
        this.nivel--;
      }
    };
  }

  close() {
    this.db.close();
  }
}

module.exports = { BancoSqlite };
