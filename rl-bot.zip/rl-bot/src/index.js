'use strict';
// Ponto de entrada: monta os módulos e liga o bot.

const config = require('./config');
const { Client, GatewayIntentBits, Events } = require('discord.js');
const { criarBanco } = require('./db');
const { criarServicoTickets } = require('./services/tickets');
const { criarPainel } = require('./services/painel');
const { criarNotificador } = require('./services/notificar');
const { criarAlertas } = require('./services/alertas');
const { criarRenomeador } = require('./services/nomeThread');
const { migrarContagemLegada } = require('./services/niveis');
const ocr = require('./services/ocr');
const { registrarComandos } = require('./discord/comandos');
const { registrarInteracoes } = require('./discord/interacoes');
const { registrarMensagens, ligarReacoes } = require('./discord/eventos');
const { topicoFoiApagado } = require('./discord/topicos');
const { createAdmin } = require('./admin');
const { criarSeguranca } = require('./services/seguranca');

function validarConfiguracao() {
  const faltando = ['token', 'clientId', 'guildId'].filter((k) => !config[k]);
  if (faltando.length) {
    console.error(`❌ Faltam dados no .env: ${faltando.map((k) => ({ token: 'DISCORD_TOKEN', clientId: 'CLIENT_ID', guildId: 'GUILD_ID' })[k]).join(', ')}`);
    process.exit(1);
  }
  if (!config.canais.tickets) console.warn('⚠️ TICKET_FORUM_ID não definido: comprovantes e importação não vão funcionar.');
  if (!config.pix.chave) console.warn('⚠️ PIX_CHAVE não definido no .env: o /chave e a validação do comprovante ficam incompletos.');
}

validarConfiguracao();

const db = criarBanco(config.dbPath);
migrarContagemLegada(db, config.arquivosEditsLegado);

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

const tickets = criarServicoTickets(db, {
  prazoHoras: config.prazo.horas,
  avisoHorasAntes: config.prazo.avisoHorasAntes,
  produtos: config.produtos,
  fusoHorario: config.fusoHorario,
  apagarAposDias: config.fechamento.apagarAposDias,
  exigirChaveAntesPagamento: true,
});

const painel = criarPainel({ client, db, tickets, config });
const notificar = criarNotificador({ client, db, config });
const alertas = criarAlertas({ tickets, notificar, painel, db, config });
const seguranca = criarSeguranca({ db, client, config, painel, ocr });
const renomeador = criarRenomeador(client);
const admin = createAdmin({ db, client, config });

const ctx = { client, config, db, tickets, painel, notificar, renomeador, ocr, seguranca, analises: new Map() };

ligarReacoes(ctx);
registrarMensagens(client, ctx);
registrarInteracoes(client, ctx);

// Se algum tópico de ticket foi apagado enquanto o bot estava desligado, tira o pedido das filas
async function reconciliar() {
  const ativos = db.prepare("SELECT * FROM tickets WHERE status NOT IN ('ENTREGUE','CANCELADO','FECHADO')").all();
  for (const t of ativos) {
    try {
      if (await topicoFoiApagado(client, t)) {
        tickets.mudarStatus(t.id, 'CANCELADO', { id: null, nome: 'sistema' }, 'Tópico não existe mais no Discord');
      }
    } catch (erro) {
      console.error('Erro ao conferir o tópico', t.thread_id, erro.message);
    }
  }
}

client.once(Events.ClientReady, async () => {
  console.log(`Bot conectado como ${client.user.tag}`);
  try {
    await registrarComandos(config);
  } catch (erro) {
    console.error('Erro ao registrar os comandos:', erro.message);
  }
  await reconciliar();
  painel.iniciar();
  // Prepara o leitor de comprovantes já na partida (na 1ª vez baixa o idioma português)
  console.log('Preparando o leitor de comprovantes (OCR)... na primeira vez isso baixa o idioma português e pode demorar um pouco.');
  ocr.preaquecer()
    .then(() => console.log('Leitor de comprovantes (OCR) pronto.'))
    .catch((erro) => console.error(`⚠️ O leitor de comprovantes (OCR) não iniciou: ${erro.message}. Confira a internet do PC; até lá os comprovantes serão conferidos só pela equipe.`));
  alertas.iniciar();
});

async function encerrar() {
  console.log('Encerrando...');
  painel.parar();
  admin.parar();
  alertas.parar();
  await ocr.encerrar();
  db.close();
  client.destroy();
  process.exit(0);
}
process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);
process.on('unhandledRejection', (erro) => console.error('Erro não tratado:', erro));

admin.iniciar();

client.login(config.token);
