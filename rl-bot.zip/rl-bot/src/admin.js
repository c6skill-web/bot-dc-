'use strict';
// Painel administrativo web (Node.js 22+, sem dependências externas).
// Leitura apenas nesta primeira versão: não altera tickets/pagamentos nem expõe o token do Discord.
const http = require('node:http');
const crypto = require('node:crypto');

const fs = require('node:fs');
const path = require('node:path');
const HTML = fs.readFileSync(path.join(__dirname, '..', 'public', 'admin.html'), 'utf8');


function createAdmin({ db, client, config }) {
  const password = process.env.ADMIN_PASSWORD || '';
  const host = process.env.ADMIN_HOST || '127.0.0.1';
  const port = Number(process.env.ADMIN_PORT || 3210);
  const sessions = new Map();
  const attempts = new Map();
  let server;
  const safeEqual = (a, b) => { const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b)); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); };
  function send(res, status, body, headers = {}) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:", ...headers }); res.end(JSON.stringify(body)); }
  function auth(req) { const raw = req.headers.cookie || ''; const m = raw.match(/(?:^|;\s*)rl_admin=([a-f0-9]{64})(?:;|$)/); if (!m) return false; const exp = sessions.get(m[1]); if (!exp || exp < Date.now()) { sessions.delete(m[1]); return false; } sessions.set(m[1], Date.now() + 8 * 60 * 60 * 1000); return true; }
  function body(req) { return new Promise((resolve, reject) => { let data = ''; req.on('data', c => { data += c; if (data.length > 8192) { reject(new Error('Corpo muito grande')); req.destroy(); } }); req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('JSON inválido')); } }); req.on('error', reject); }); }
  function count(sql, ...args) { return Number(db.prepare(sql).get(...args).n || 0); }
  function overview() {
    const active = count("SELECT COUNT(*) n FROM tickets WHERE status NOT IN ('ENTREGUE','CANCELADO','FECHADO')");
    const queue = count("SELECT COUNT(*) n FROM tickets WHERE status IN ('NA_FILA','EM_PRODUCAO','EM_PROCESSO','RENDERIZANDO')");
    const delivered = count("SELECT COUNT(*) n FROM tickets WHERE status='ENTREGUE'");
    const recent = db.prepare('SELECT id,thread_id,user_id,user_name,nome_base,categoria,produto,tipo,preco_centavos,status,fila_numero,criado_em FROM tickets ORDER BY criado_em DESC LIMIT 500').all();
    return { bot: { ready: Boolean(client.isReady()), tag: client.user?.tag || null }, guild: config.guildId || null, counts: { active, queue, delivered }, recent };
  }
  async function handler(req, res) {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/admin') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:" }); res.end(HTML); return; }
    if (req.method === 'POST' && url.pathname === '/admin/api/login') {
      const ip = req.socket.remoteAddress || 'unknown'; const a = attempts.get(ip) || { n: 0, until: 0 };
      if (a.until > Date.now()) return send(res, 429, { error: 'Muitas tentativas. Aguarde alguns minutos.' });
      try { const data = await body(req); if (!password || !safeEqual(data.password || '', password)) { a.n++; if (a.n >= 5) { a.n = 0; a.until = Date.now() + 5 * 60 * 1000; } attempts.set(ip, a); return send(res, 401, { error: 'Senha inválida.' }); } } catch { return send(res, 400, { error: 'Requisição inválida.' }); }
      attempts.delete(ip); const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, Date.now() + 8 * 60 * 60 * 1000); const secure = req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https'; return send(res, 200, { ok: true }, { 'Set-Cookie': `rl_admin=${token}; HttpOnly; SameSite=Strict; Path=/admin; Max-Age=28800${secure ? '; Secure' : ''}` });
    }
    if (req.method === 'POST' && url.pathname === '/admin/api/logout') { const m = (req.headers.cookie || '').match(/(?:^|;\s*)rl_admin=([a-f0-9]{64})(?:;|$)/); if (m) sessions.delete(m[1]); return send(res, 200, { ok: true }, { 'Set-Cookie': 'rl_admin=; HttpOnly; SameSite=Strict; Path=/admin; Max-Age=0' }); }
    if (req.method === 'GET' && url.pathname === '/admin/api/me') return auth(req) ? send(res, 200, { ok: true }) : send(res, 401, { error: 'Não autenticado.' });
    if (!url.pathname.startsWith('/admin/api/')) return send(res, 404, { error: 'Não encontrado.' });
    if (!auth(req)) return send(res, 401, { error: 'Sessão expirada.' });
    try {
      if (req.method !== 'GET') return send(res, 405, { error: 'Método não permitido.' }, { Allow: 'GET' });
      if (url.pathname === '/admin/api/overview') return send(res, 200, overview());
      if (url.pathname === '/admin/api/payments') { const items = db.prepare('SELECT p.id,p.ticket_id,p.user_id,p.valor_centavos,p.tx_id,p.modo,p.confirmado_por,p.em FROM pagamentos p ORDER BY p.em DESC LIMIT 300').all(); return send(res, 200, { items }); }
      if (url.pathname === '/admin/api/events') { const items = db.prepare('SELECT id,ticket_id,em,tipo,ator_id,ator_nome,detalhe FROM ticket_eventos ORDER BY em DESC LIMIT 300').all(); return send(res, 200, { items }); }
      if (url.pathname === '/admin/api/security') { const items = db.prepare('SELECT id,em,tipo,usuario_id,usuario_nome,cargo_id,thread_id,ticket_id,detalhe,mensagem_id FROM alertas_seguranca ORDER BY em DESC LIMIT 500').all(); return send(res, 200, { items }); }
      return send(res, 404, { error: 'Rota não encontrada.' });
    } catch (e) { console.error('[admin] Erro na consulta:', e.message); return send(res, 500, { error: 'Erro interno ao consultar os dados.' }); }
  }
  return {
    iniciar() {
      if (!password) { console.warn('Painel admin desativado: configure ADMIN_PASSWORD no .env para habilitá-lo.'); return; }
      if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('ADMIN_PORT inválida.');
      server = http.createServer((req, res) => { handler(req, res).catch(e => { console.error('[admin] Erro HTTP:', e.message); if (!res.headersSent) send(res, 500, { error: 'Erro interno.' }); else res.destroy(); }); });
      server.listen(port, host, () => console.log(`Painel administrativo: http://${host}:${port}/admin`));
      server.on('error', e => console.error('[admin] Não foi possível iniciar:', e.message));
    },
    parar() { for (const k of sessions.keys()) sessions.delete(k); if (server) server.close(); },
  };
}
module.exports = { createAdmin };
