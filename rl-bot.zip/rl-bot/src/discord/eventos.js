'use strict';
// Eventos do Discord (mensagens) e ligação entre mudanças de ticket e o resto do bot.

const { nomeDoTicket, rotuloTipo } = require('../util/nomes');
const { registrarAvaliacao, verificarNiveis } = require('../services/niveis');
const { tratarImagemDeTicket } = require('./pagamentos');

function registrarMensagens(client, ctx) {
  // Proteção de chaves Pix e dados sensíveis em tickets. Alertas vão ao painel e aos superiores por DM.
  client.on('messageCreate', async (message) => {
    try { await ctx.seguranca?.verificarMensagem(message); }
    catch (erro) { console.error('Erro na verificação de segurança:', erro); }
  });

  // Comprovante de pagamento dentro dos tickets
  client.on('messageCreate', async (message) => {
    try {
      await tratarImagemDeTicket(message, ctx);
    } catch (erro) {
      console.error('Erro ao tratar imagem do ticket:', erro);
    }
  });

  // Contagem de edits no canal de avaliações (1 mensagem = 1 edit)
  client.on('messageCreate', async (message) => {
    try {
      if (message.author.bot) return;
      if (!ctx.config.canais.avaliacoes) return;
      if (message.channel.id !== ctx.config.canais.avaliacoes) return;

      const total = registrarAvaliacao(ctx.db, message.author.id);
      const membro = await message.guild.members.fetch(message.author.id).catch(() => null);
      if (membro) await verificarNiveis(message.guild, membro, total, ctx.config.niveisPorEdits);
    } catch (erro) {
      console.error('Erro ao contar avaliação:', erro);
    }
  });

  // Tópico de ticket apagado no Discord => cancela o pedido (some das filas)
  client.on('threadDelete', (thread) => {
    try {
      const ticket = ctx.tickets.porThread(thread.id);
      if (ticket && !['ENTREGUE', 'CANCELADO', 'FECHADO'].includes(ticket.status)) {
        ctx.tickets.mudarStatus(ticket.id, 'CANCELADO', { id: null, nome: 'sistema' }, 'Tópico apagado no Discord');
      }
    } catch (erro) {
      console.error('Erro ao tratar tópico apagado:', erro);
    }
  });
}

// O que acontece a cada mudança de ticket: painel, nome do tópico e avisos à equipe
function ligarReacoes(ctx) {
  const descrever = (t) => `${t.prioridade ? '⚡ ' : ''}**#${t.fila_numero ?? '?'} ${rotuloTipo(t.tipo) ?? 'sem tipo'}** <#${t.thread_id}> · <@${t.user_id}>`;

  ctx.tickets.bus.on('mudou', ({ ticket, evento, detalhe }) => {
    ctx.painel.agendar();

    if (evento !== 'IMPORTADO') {
      const nome = nomeDoTicket(ticket);
      if (nome) ctx.renomeador.solicitar(ticket.thread_id, nome);
    }

    switch (evento) {
      case 'NA_FILA':
        ctx.notificar.avisarEquipe({
          conteudo: `${detalhe === 'voltou para a fila' ? '↩️ **Pedido voltou para a fila**' : '🆕 **Novo pedido na fila**'} — ${descrever(ticket)}`,
        });
        break;
      case 'TRANSFERIDO':
        ctx.notificar.avisarEquipe({ conteudo: `🔀 **Pedido transferido de fila** (${detalhe}) — ${descrever(ticket)}` });
        break;
      case 'CANCELADO':
        ctx.notificar.avisarEquipe({ conteudo: `❌ **Pedido cancelado** — ${descrever(ticket)}${detalhe ? ` (${detalhe})` : ''}` });
        break;
      case 'FECHADO':
        // fechar um ticket comum não precisa de aviso; fechar um pedido em andamento, sim
        if (detalhe) ctx.notificar.avisarEquipe({ conteudo: `🔒 **Ticket fechado com pedido em andamento (pedido cancelado)** — ${descrever(ticket)}` });
        break;
      case 'PAGO_SEM_TIPO':
        ctx.notificar.avisarEquipe({
          pingarSuporte: true,
          conteudo: `💰 **Pagamento confirmado, mas falta o tipo** (Clean/Avançada) — <#${ticket.thread_id}> · <@${ticket.user_id}>. Use /tipo no ticket.`,
        });
        break;
      default:
    }
  });
}

module.exports = { registrarMensagens, ligarReacoes };
