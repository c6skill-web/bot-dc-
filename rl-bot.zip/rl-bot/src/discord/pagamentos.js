'use strict';
// Comprovante de pagamento: lê a imagem que o cliente manda no ticket (OCR) e
//  - se passar em TODAS as travas (ver services/comprovante.js) e o modo for "auto": confirma sozinho,
//    dá o cargo de cliente, coloca o pedido na fila e o nome do tópico muda sozinho;
//  - se não passar: mostra o botão para a equipe confirmar manualmente (como no bot antigo),
//    dizendo o motivo;
//  - se for um comprovante REPETIDO: bloqueia e avisa a equipe.

const crypto = require('crypto');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { analisarComprovante } = require('../services/comprovante');
const { ErroNegocio } = require('../services/tickets');
const { formatarReais } = require('../util/tempo');
const { rotuloTipo } = require('../util/nomes');
const { ticketDoCanal } = require('./contexto');
const { darCargoCliente } = require('./cargos');
const { opcoesParaValor, codigoDaOpcao, rotuloDaOpcao } = require('../services/opcoes');

const SISTEMA = { id: null, nome: 'sistema (OCR)' };
const TAMANHO_MAXIMO = 15 * 1024 * 1024;
const STATUS_AGUARDANDO = ['ABERTO', 'AGUARDANDO_PAGAMENTO'];

async function baixarImagem(url) {
  const resposta = await fetch(url);
  if (!resposta.ok) throw new Error(`download falhou (${resposta.status})`);
  return Buffer.from(await resposta.arrayBuffer());
}

function guardarAnalise(ctx, mensagemId, dados) {
  ctx.analises.set(mensagemId, { ...dados, em: Date.now() });
  if (ctx.analises.size > 200) {
    const maisAntigo = [...ctx.analises.entries()].sort((a, b) => a[1].em - b[1].em)[0];
    if (maisAntigo) ctx.analises.delete(maisAntigo[0]);
  }
}

async function avisarComprovanteRepetido(message, ctx, repetido) {
  await message
    .reply({
      content: '⚠️ Esse comprovante já foi utilizado em outro pedido, então não posso aceitá-lo. A equipe foi avisada.',
      allowedMentions: { repliedUser: false },
    })
    .catch(() => {});

  const anterior = ctx.tickets.obter(repetido.ticketId);
  await ctx.notificar.avisarEquipe({
    pingarSuporte: true,
    conteudo: `🚨 **Comprovante repetido** enviado por <@${message.author.id}> em <#${message.channel.id}>${
      anterior ? ` (já usado em <#${anterior.thread_id}>)` : ''
    }. Pagamento NÃO confirmado.`,
  });
}

async function confirmarAutomatico(message, ctx, ticket, analise, hash) {
  let resultado;
  try {
    resultado = ctx.tickets.confirmarPagamento(
      ticket.id,
      { valorCentavos: analise.valorCentavos, txId: analise.txId, hash, modo: 'auto' },
      SISTEMA
    );
  } catch (erro) {
    if (erro instanceof ErroNegocio && erro.codigo === 'ja_pago') return; // duas imagens ao mesmo tempo
    if (erro instanceof ErroNegocio && erro.codigo === 'comprovante_duplicado') {
      const rep = ctx.tickets.comprovanteUsado({ txId: analise.txId, hash });
      if (rep) await avisarComprovanteRepetido(message, ctx, rep);
      return;
    }
    throw erro;
  }

  const atualizado = resultado.ticket;
  const membro = await message.guild.members.fetch(ticket.user_id).catch(() => null);
  let falhouCargo = !membro;
  if (membro) {
    const r = await darCargoCliente(message.guild, membro, ctx.config);
    falhouCargo = !r.ok;
  }

  const linhas = [`✅ Pagamento de **${formatarReais(analise.valorCentavos)}** confirmado automaticamente!`];
  if (resultado.entrouNaFila) {
    linhas.push(`🎬 Seu pedido entrou na fila **${rotuloTipo(atualizado.tipo)}** com o número **#${atualizado.fila_numero}**.`);
  }
  await message.reply({ content: linhas.join('\n'), allowedMentions: { repliedUser: false } });

  await ctx.notificar.avisarEquipe({
    conteudo:
      `💳 Pagamento confirmado **automaticamente (OCR)** — ${formatarReais(analise.valorCentavos)} · <#${ticket.thread_id}> · ID \`${analise.txId}\`\n` +
      `⚠️ O bot lê a imagem, não o extrato: confira no banco. Se algo estiver errado, use /cancelar neste ticket.` +
      (falhouCargo ? `\n⚠️ Não consegui dar o cargo de cliente (confira "Gerenciar Cargos" e a posição do cargo do bot).` : ''),
  });
}

const dataBR = (iso) => (iso ? iso.split('-').reverse().join('/') : null);

// Resumo do que o bot leu no comprovante, para a equipe conferir de relance
function resumoDoComprovante(analise) {
  return [
    '📎 **Comprovante recebido** — o que eu li no print:',
    `• Valor: ${analise.valorCentavos != null ? `**${formatarReais(analise.valorCentavos)}**` : '❓ não consegui ler'}`,
    `• Data: ${dataBR(analise.data) ?? '❓ não consegui ler'}`,
    `• ID da transação: ${analise.txId ? `\`${analise.txId}\`` : '❓ não consegui ler'}`,
    `• Destinatário: ${
      analise.nivelDestinatario === 'confirmado' ? '✅ é para a RL' : analise.nivelDestinatario === 'parcial' ? '🟡 só reconheci o banco — confira o nome' : '⚠️ não reconheci — confira'
    }`,
  ];
}

async function pedirConfirmacaoManual(message, ctx, ticket, analise, hash) {
  const { config } = ctx;

  // Sem o menu de produto o bot não sabe o que o cliente comprou: oferece as opções que
  // batem com o valor lido e a equipe clica na certa.
  const semProduto = Boolean(ticket) && !ticket.produto && ticket.categoria === 'adquirir_edit';
  const opcoes = semProduto ? opcoesParaValor(analise.valorCentavos, config.produtos, config.adicionais) : [];

  const linhas = resumoDoComprovante(analise);
  // o destinatário já aparece no resumo; o valor esperado não existe sem o menu de produto
  const problemas = analise.problemas.filter((p) => !['sem_valor_esperado', 'destinatario', 'destinatario_parcial'].includes(p.codigo));
  if (problemas.length) linhas.push('', '🔎 Atenção:', ...problemas.map((p) => `• ${p.texto}`));

  if (semProduto && analise.valorCentavos != null && !opcoes.length) {
    linhas.push('', '⚠️ Esse valor não bate com nenhum pedido da tabela (nem com o adicional de prioridade). Confira com o cliente.');
  } else if (opcoes.length === 1) {
    linhas.push('', '👇 Só uma opção bate com esse valor. Clique para confirmar:');
  } else if (opcoes.length > 1) {
    linhas.push('', '👇 Mais de um pedido bate com esse valor. Clique no que o cliente pediu:');
  }
  linhas.push('', '⚠️ Confira no extrato se o valor realmente caiu — o bot lê o print, não o banco.');

  const botoes = opcoes.map((o) =>
    new ButtonBuilder()
      .setCustomId(`confirmar_opcao_${message.author.id}_${codigoDaOpcao(o)}`)
      .setLabel(`${rotuloDaOpcao(o)} — ${formatarReais(o.totalCentavos)}`.slice(0, 80))
      .setEmoji(o.prioridade ? '⚡' : o.tipo === 'CLEAN' ? '🧼' : '🚀')
      .setStyle(ButtonStyle.Primary)
  );
  botoes.push(
    new ButtonBuilder()
      .setCustomId(`confirmar_comprovante_${message.author.id}`)
      .setLabel(opcoes.length ? 'Confirmar sem definir a fila' : 'Confirmar e dar cargo cliente')
      .setEmoji('✅')
      .setStyle(opcoes.length ? ButtonStyle.Secondary : ButtonStyle.Success)
  );

  const resposta = await message.reply({
    content: linhas.join('\n'),
    components: [new ActionRowBuilder().addComponents(botoes)],
  });

  guardarAnalise(ctx, resposta.id, { valorCentavos: analise.valorCentavos, txId: analise.txId, hash });
}

const EXTENSOES_IMAGEM = /\.(png|jpe?g|webp)(\?|$)/i;
const ehImagem = (anexo) => anexo.contentType?.startsWith('image/') || (!anexo.contentType && EXTENSOES_IMAGEM.test(anexo.name || anexo.url || ''));

const botaoConfirmarManual = (clienteId) =>
  new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`confirmar_comprovante_${clienteId}`).setLabel('Confirmar e dar cargo cliente').setEmoji('✅').setStyle(ButtonStyle.Success)
  );

async function tratarImagemDeTicket(message, ctx) {
  const { config } = ctx;
  if (message.author.bot) return;

  const imagens = [...message.attachments.values()].filter((a) => ehImagem(a) && (a.size ?? 0) <= TAMANHO_MAXIMO).slice(0, 3);
  if (!imagens.length) return;

  // Tópico que o bot já conhece (ele mesmo criou ou já importou) vale em qualquer canal.
  // Tópico desconhecido só entra se estiver no canal de tickets configurado (importação do Rio Bot).
  const registrado = message.channel.isThread?.() ? ctx.tickets.porThread(message.channel.id) : null;
  if (!registrado && (!config.canais.tickets || message.channel.parentId !== config.canais.tickets)) return;

  const ticket = registrado || ticketDoCanal(ctx, message.channel);
  if (ticket) {
    if (ticket.user_id !== message.author.id) return; // só o dono do ticket envia comprovante
    if (ticket.pago_em || !STATUS_AGUARDANDO.includes(ticket.status)) return; // já pago/em andamento: não gasta OCR
  }

  // 🔎 mostra que o bot está lendo (a leitura pode levar alguns segundos)
  let reacao = null;
  try {
    reacao = await message.react('🔎');
  } catch {
    /* sem permissão de reagir: tudo bem */
  }

  let achado = null;
  let falhouLeitura = false;
  try {
    for (const imagem of imagens) {
      let buffer;
      let texto;
      try {
        buffer = await baixarImagem(imagem.url);
        texto = await ctx.ocr.lerTexto(buffer);
      } catch (erro) {
        console.error('Erro ao ler o comprovante (OCR):', erro.message);
        falhouLeitura = true;
        continue;
      }

      const analise = analisarComprovante(texto, {
        esperadoCentavos: ticket?.preco_centavos ?? null,
        ticketCriadoEm: ticket?.criado_em ?? null,
        agora: Date.now(),
        pix: config.pix,
        fuso: config.fusoHorario,
      });
      if (analise.relevante) {
        achado = { analise, hash: crypto.createHash('sha256').update(buffer).digest('hex') };
        break;
      }
    }
  } finally {
    if (reacao) reacao.users.remove(ctx.client.user.id).catch(() => {});
  }

  if (!achado) {
    // Imagem que nem parece comprovante: silêncio (pode ser print de edit). Falha de leitura: avisa.
    if (falhouLeitura) {
      await message.reply({
        content: '⚠️ Não consegui ler esse print automaticamente. A equipe vai conferir o comprovante na mão.',
        components: [botaoConfirmarManual(message.author.id)],
      });
    }
    return;
  }

  const { analise, hash } = achado;
  const repetido = ctx.tickets.comprovanteUsado({ txId: analise.txId, hash });
  if (repetido) {
    await avisarComprovanteRepetido(message, ctx, repetido);
    return;
  }

  if (config.pagamento.modo === 'auto' && ticket && analise.aprovadoAuto) {
    await confirmarAutomatico(message, ctx, ticket, analise, hash);
    return;
  }
  await pedirConfirmacaoManual(message, ctx, ticket, analise, hash);
}

module.exports = { tratarImagemDeTicket };
