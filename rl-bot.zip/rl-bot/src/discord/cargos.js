'use strict';
const { acharCargo } = require('../util/permissoes');

async function darCargoCliente(guild, membro, config) {
  const cargo = acharCargo(guild, config.cargos.cliente);
  if (!cargo) return { ok: false, motivo: 'cargo-nao-encontrado' };

  try {
    await membro.roles.add(cargo);
    return { ok: true };
  } catch (erro) {
    console.error('Erro ao adicionar cargo de cliente:', erro);
    return { ok: false, motivo: 'erro' };
  }
}

module.exports = { darCargoCliente };
