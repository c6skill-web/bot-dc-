'use strict';
// Botão "Fechar Ticket" (dentro de cada ticket) e a confirmação manual para APAGAR depois de alguns dias.
//
// Fechar = o ticket é encerrado no sistema, o tópico é TRANCADO e ARQUIVADO (ninguém escreve mais).
// Depois de `config.fechamento.apagarAposDias` dias o bot avisa a equipe (marcando o suporte)
// e só apaga o tópico se alguém da equipe clicar em "Apagar ticket".

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { ErroNegocio } = require('../services/tickets');
const { temCargo } = require('../util/permissoes');
const { EFEMERO, atorDe, ticketDoCanal } = require('./contexto');

const TEXTO_FECHAR = '🔒 Caso sua questão já tenha sido resolvida, clique no botão abaixo para fechar o ticket.';

function botaoFechar() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('fechar_ticket').setLabel('Fechar Ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger)
  );
}

// Tranca e arquiva o tópico. Devolve false se o bot não tiver permissão.
async function trancarTopico(canal) {
  try {
    await canal.setLocked(true, 'Ticket fechado');
    await canal.setArchived(true, 'Ticket fechado');
    return true;
  } catch (erro) {
    console.error('Não consegui trancar/arquivar o tópico:', erro.message);
    return false;
  }
}

const textoFechado = (ctx, usuario) =>
  `🔒 Ticket fechado por ${usuario}. Este tópico foi trancado e a equipe vai apagá-lo daqui a ${ctx.config.fechamento.apagarAposDias} dias.`;

const avisoSemPermissao =
  '⚠️ Fechei o ticket no sistema, mas não consegui trancar o tópico. Confira se o bot tem a permissão "Gerenciar Tópicos".';

// Clicou em "Fechar Ticket"
async function fecharPorBotao(interaction, ctx) {
  const ticket = ticketDoCanal(ctx, interaction.channel);
  if (!ticket) {
    await interaction.reply({ content: '⚠️ Este ticket não está registrado no sistema. Chame a equipe.', flags: EFEMERO });
    return;
  }

  const ehDono = interaction.user.id === ticket.user_id;
  const ehSuporte = temCargo(interaction.member, ctx.config.cargos.suporte);
  if (!ehDono && !ehSuporte) {
    await interaction.reply({ content: '🚫 Só quem abriu o ticket (ou a equipe) pode fechá-lo.', flags: EFEMERO });
    return;
  }

  try {
    ctx.tickets.fecharTicket(ticket.id, atorDe(interaction.user));
  } catch (erro) {
    if (erro instanceof ErroNegocio && erro.codigo === 'pedido_em_andamento') {
      if (!ehSuporte) {
        await interaction.reply({
          content: '⏳ Seu pedido ainda está em andamento, então só a equipe pode fechar este ticket. Se você já recebeu sua edit, chame a equipe.',
          flags: EFEMERO,
        });
        return;
      }
      const confirmar = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`fechar_confirmar_${ticket.id}`).setLabel('Fechar e cancelar o pedido').setEmoji('⚠️').setStyle(ButtonStyle.Danger)
      );
      await interaction.reply({
        content: '⚠️ Este pedido está pago e em andamento (fila/produção). Fechar o ticket **cancela o pedido** e tira ele das filas. Tem certeza?',
        components: [confirmar],
        flags: EFEMERO,
      });
      return;
    }
    throw erro;
  }

  await interaction.reply({ content: textoFechado(ctx, interaction.user) });
  if (!(await trancarTopico(interaction.channel))) {
    await interaction.followUp({ content: avisoSemPermissao, flags: EFEMERO }).catch(() => {});
  }
}

// A equipe confirmou o fechamento de um ticket com pedido em andamento
async function confirmarFechamento(interaction, ctx) {
  if (!temCargo(interaction.member, ctx.config.cargos.suporte)) {
    await interaction.reply({ content: '🚫 Só a equipe pode fechar um ticket com pedido em andamento.', flags: EFEMERO });
    return;
  }
  const ticket = ctx.tickets.obter(Number(interaction.customId.replace('fechar_confirmar_', '')));
  if (!ticket || ticket.thread_id !== interaction.channelId) {
    await interaction.reply({ content: '⚠️ Este botão não é deste ticket.', flags: EFEMERO });
    return;
  }

  ctx.tickets.fecharTicket(ticket.id, atorDe(interaction.user), { forcar: true });
  await interaction.update({ content: '✅ Ticket fechado e pedido cancelado.', components: [] });
  await interaction.channel.send({ content: textoFechado(ctx, interaction.user) });
  if (!(await trancarTopico(interaction.channel))) {
    await interaction.followUp({ content: avisoSemPermissao, flags: EFEMERO }).catch(() => {});
  }
}

// Aviso da equipe (3 dias depois): "Apagar ticket"
async function apagarTicket(interaction, ctx) {
  if (!temCargo(interaction.member, ctx.config.cargos.suporte)) {
    await interaction.reply({ content: '🚫 Só a equipe pode apagar tickets.', flags: EFEMERO });
    return;
  }
  const ticket = ctx.tickets.obter(Number(interaction.customId.replace('apagar_ticket_', '')));
  if (!ticket || !ticket.fechado_em) {
    await interaction.reply({ content: '⚠️ Esse ticket não está fechado no sistema. Nada foi apagado.', flags: EFEMERO });
    return;
  }

  if (!ticket.apagado_em) {
    try {
      const topico = await interaction.client.channels.fetch(ticket.thread_id);
      await topico.delete(`Ticket fechado — apagado por ${interaction.user.tag}`);
    } catch (erro) {
      if (erro.code !== 10003) {
        // 10003 = o tópico já não existe (tudo bem); qualquer outro erro: não finge que apagou
        console.error('Erro ao apagar o tópico:', erro.message);
        await interaction.reply({
          content: '⚠️ Não consegui apagar o tópico. Confira se o bot tem a permissão "Gerenciar Tópicos".',
          flags: EFEMERO,
        });
        return;
      }
    }
    ctx.tickets.marcarApagado(ticket.id, atorDe(interaction.user));
  }

  await interaction.update({
    content: `🗑️ Ticket de <@${ticket.user_id}> apagado por ${interaction.user}.`,
    components: [],
    allowedMentions: { parse: [] },
  });
}

// Aviso da equipe (3 dias depois): "Manter" (não pergunta de novo)
async function manterTicket(interaction, ctx) {
  if (!temCargo(interaction.member, ctx.config.cargos.suporte)) {
    await interaction.reply({ content: '🚫 Só a equipe pode decidir isso.', flags: EFEMERO });
    return;
  }
  const ticket = ctx.tickets.obter(Number(interaction.customId.replace('manter_ticket_', '')));
  await interaction.update({
    content: `📌 Ticket ${ticket ? `de <@${ticket.user_id}> ` : ''}mantido por ${interaction.user}. Não vou perguntar de novo.`,
    components: [],
    allowedMentions: { parse: [] },
  });
}

module.exports = { TEXTO_FECHAR, botaoFechar, trancarTopico, fecharPorBotao, confirmarFechamento, apagarTicket, manterTicket };
