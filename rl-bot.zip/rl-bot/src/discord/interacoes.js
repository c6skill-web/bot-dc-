'use strict';
// Roteador de interações (menus, botões e comandos de barra).

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { acharCategoria } = require('../conteudo');
const { temCargo } = require('../util/permissoes');
const { ErroNegocio } = require('../services/tickets');
const { rotuloTipo } = require('../util/nomes');
const { EFEMERO, atorDe, ticketDoCanal, responderErro } = require('./contexto');
const { abrirTicket, escolherProduto } = require('./tickets');
const { handlers } = require('./comandos');
const { darCargoCliente } = require('./cargos');
const { fecharPorBotao, confirmarFechamento, apagarTicket, manterTicket } = require('./fechamento');
const { decodificarOpcao, rotuloDaOpcao } = require('../services/opcoes');

async function confirmarComprovanteManual(interaction, ctx) {
  if (!temCargo(interaction.member, ctx.config.cargos.suporte)) {
    await interaction.reply({ content: '🚫 Você não tem permissão para confirmar pagamentos.', flags: EFEMERO });
    return;
  }

  const clienteId = interaction.customId.replace('confirmar_comprovante_', '');
  const membro = await interaction.guild.members.fetch(clienteId).catch(() => null);
  if (!membro) {
    await interaction.reply({ content: '⚠️ Não encontrei mais esse usuário no servidor.', flags: EFEMERO });
    return;
  }

  // Se o ticket está no sistema, registra o pagamento (com o ID/imagem lidos, se o bot ainda os tem)
  let extra = '';
  const ticket = ticketDoCanal(ctx, interaction.channel);
  if (ticket && ticket.user_id === clienteId && !ticket.pago_em) {
    const lido = ctx.analises.get(interaction.message.id) || {};
    try {
      const r = ctx.tickets.confirmarPagamento(
        ticket.id,
        { valorCentavos: lido.valorCentavos ?? null, txId: lido.txId ?? null, hash: lido.hash ?? null, modo: 'manual' },
        atorDe(interaction.user)
      );
      if (r.entrouNaFila) extra = ` Pedido na fila ${rotuloTipo(r.ticket.tipo)} #${r.ticket.fila_numero}.`;
      else if (r.ticket.status === 'PAGO') extra = ' Falta definir o tipo (Clean/Avançada) com /tipo para entrar na fila.';
    } catch (erro) {
      if (erro instanceof ErroNegocio && erro.codigo === 'comprovante_duplicado') {
        await interaction.reply({ content: '🚨 Este comprovante já foi usado em outro pedido. Nada foi confirmado.', flags: EFEMERO });
        return;
      }
      if (!(erro instanceof ErroNegocio && erro.codigo === 'ja_pago')) throw erro;
    }
  } else if (!ticket) {
    extra = '\n⚠️ Este canal não é um ticket reconhecido: só o cargo foi dado, nenhum pedido foi registrado.';
  } else if (ticket.user_id !== clienteId) {
    extra = `\n⚠️ O dono deste ticket é <@${ticket.user_id}>, não ${membro}. Só o cargo foi dado: o pagamento NÃO foi registrado e o pedido NÃO entrou na fila.`;
  }

  const resultado = await darCargoCliente(interaction.guild, membro, ctx.config);
  await interaction.update({
    content: resultado.ok
      ? `✅ Pagamento confirmado por ${interaction.user} — cargo "${ctx.config.cargos.cliente.nome}" adicionado pra ${membro}.${extra}`
      : `⚠️ Não consegui dar o cargo pra ${membro} (confira permissões do bot).${extra}`,
    components: [],
  });
  ctx.analises.delete(interaction.message.id);
}

// Equipe clicou numa das opções de pedido que o bot ofereceu para o valor do comprovante
async function confirmarOpcao(interaction, ctx) {
  if (!temCargo(interaction.member, ctx.config.cargos.suporte)) {
    await interaction.reply({ content: '🚫 Você não tem permissão para confirmar pagamentos.', flags: EFEMERO });
    return;
  }

  const m = interaction.customId.match(/^confirmar_opcao_([^_]+)_(.+)$/);
  if (!m) {
    await interaction.reply({ content: '⚠️ Botão inválido.', flags: EFEMERO });
    return;
  }
  const clienteId = m[1];
  const { chave, prioridade } = decodificarOpcao(m[2]);
  const produto = ctx.config.produtos[chave];
  if (!produto || !produto.tipo || (prioridade && !ctx.config.adicionais?.prioridade)) {
    await interaction.reply({ content: '⚠️ Essa opção não existe mais na tabela.', flags: EFEMERO });
    return;
  }

  const ticket = ticketDoCanal(ctx, interaction.channel);
  if (!ticket || ticket.user_id !== clienteId) {
    await interaction.reply({ content: '⚠️ Não encontrei o pedido desse cliente neste ticket.', flags: EFEMERO });
    return;
  }
  if (ticket.pago_em) {
    await interaction.reply({ content: '⚠️ O pagamento deste ticket já foi confirmado.', flags: EFEMERO });
    return;
  }

  const membro = await interaction.guild.members.fetch(clienteId).catch(() => null);
  if (!membro) {
    await interaction.reply({ content: '⚠️ Não encontrei mais esse usuário no servidor.', flags: EFEMERO });
    return;
  }

  // Segurança: a opção clicada precisa somar exatamente o valor que foi lido no print
  const lido = ctx.analises.get(interaction.message.id) || {};
  const total = produto.precoCentavos + (prioridade ? ctx.config.adicionais.prioridade.precoCentavos : 0);
  if (lido.valorCentavos != null && lido.valorCentavos !== total) {
    await interaction.reply({ content: '⚠️ Essa opção não bate com o valor lido no comprovante. Nada foi confirmado.', flags: EFEMERO });
    return;
  }

  const ator = atorDe(interaction.user);
  let r;
  try {
    ctx.tickets.definirProduto(ticket.id, chave, ator);
    if (prioridade) ctx.tickets.definirPrioridade(ticket.id, true, ator);
    r = ctx.tickets.confirmarPagamento(
      ticket.id,
      { valorCentavos: lido.valorCentavos ?? total, txId: lido.txId ?? null, hash: lido.hash ?? null, modo: 'manual' },
      ator
    );
  } catch (erro) {
    if (erro instanceof ErroNegocio && erro.codigo === 'comprovante_duplicado') {
      await interaction.reply({ content: '🚨 Este comprovante já foi usado em outro pedido. Nada foi confirmado.', flags: EFEMERO });
      return;
    }
    throw erro;
  }

  const resultado = await darCargoCliente(interaction.guild, membro, ctx.config);
  const pedido = rotuloDaOpcao({ produto, prioridade });
  const fila = r.entrouNaFila ? ` Pedido na fila ${rotuloTipo(r.ticket.tipo)} #${r.ticket.fila_numero}.` : '';
  await interaction.update({
    content: resultado.ok
      ? `✅ Pagamento confirmado por ${interaction.user} — **${pedido}**${prioridade ? ' ⚡' : ''}.${fila} Cargo "${ctx.config.cargos.cliente.nome}" adicionado pra ${membro}.`
      : `⚠️ Pagamento confirmado — **${pedido}**.${fila} Mas não consegui dar o cargo pra ${membro} (confira permissões do bot).`,
    components: [],
  });
  ctx.analises.delete(interaction.message.id);
}

function criarRoteador(ctx) {
  return async function rotear(interaction) {
    // escolheu uma categoria no painel de ticket
    if (interaction.isStringSelectMenu() && interaction.customId === 'painel_categoria') {
      const categoria = acharCategoria(interaction.values[0]);
      if (!categoria) return;

      const botao = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`abrir_ticket_${categoria.value}`).setLabel('Abrir Ticket').setEmoji('➕').setStyle(ButtonStyle.Primary)
      );
      await interaction.reply({ content: categoria.resposta, components: [botao], flags: EFEMERO });
      return;
    }

    // escolheu o produto dentro do ticket
    if (interaction.isStringSelectMenu() && interaction.customId === 'produto_select') {
      await escolherProduto(interaction, ctx);
      return;
    }

    // clicou em "Abrir Ticket"
    if (interaction.isButton() && interaction.customId.startsWith('abrir_ticket_')) {
      const categoria = acharCategoria(interaction.customId.replace('abrir_ticket_', ''));
      if (!categoria) return;
      await abrirTicket(interaction, ctx, categoria);
      return;
    }

    // botão "Copiar chave"
    if (interaction.isButton() && interaction.customId === 'copiar_chave') {
      await interaction.reply({ content: `\`${ctx.config.pix.chave}\``, flags: EFEMERO });
      return;
    }

    // fechar ticket (botão dentro do ticket) e a confirmação de apagar depois de alguns dias
    if (interaction.isButton() && interaction.customId === 'fechar_ticket') {
      await fecharPorBotao(interaction, ctx);
      return;
    }
    if (interaction.isButton() && interaction.customId.startsWith('fechar_confirmar_')) {
      await confirmarFechamento(interaction, ctx);
      return;
    }
    if (interaction.isButton() && interaction.customId.startsWith('apagar_ticket_')) {
      await apagarTicket(interaction, ctx);
      return;
    }
    if (interaction.isButton() && interaction.customId.startsWith('manter_ticket_')) {
      await manterTicket(interaction, ctx);
      return;
    }

    // botão de uma das opções de pedido que batem com o valor do comprovante
    if (interaction.isButton() && interaction.customId.startsWith('confirmar_opcao_')) {
      await confirmarOpcao(interaction, ctx);
      return;
    }

    // botão "Confirmar e dar cargo cliente" (comprovante que o bot não confirmou sozinho)
    if (interaction.isButton() && interaction.customId.startsWith('confirmar_comprovante_')) {
      await confirmarComprovanteManual(interaction, ctx);
      return;
    }

    if (!interaction.isChatInputCommand()) return;

    // /chave tem uma allowlist própria, sem bypass para administradores ou outros cargos.
    if (interaction.commandName === 'chave' && ctx.seguranca) {
      if (await ctx.seguranca.tratarComandoChave(interaction)) return;
      await handlers.chave(interaction, ctx);
      return;
    }

    if (!temCargo(interaction.member, ctx.config.cargos.suporte)) {
      await interaction.reply({ content: '🚫 Você não tem permissão para usar esse comando.', flags: EFEMERO });
      return;
    }

    const executar = handlers[interaction.commandName];
    if (executar) await executar(interaction, ctx);
  };
}

function registrarInteracoes(client, ctx) {
  const rotear = criarRoteador(ctx);
  client.on('interactionCreate', async (interaction) => {
    try {
      await rotear(interaction);
    } catch (erro) {
      await responderErro(interaction, erro);
    }
  });
}

module.exports = { registrarInteracoes, criarRoteador };
