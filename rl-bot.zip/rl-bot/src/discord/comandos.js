'use strict';
// Comandos de barra. Os antigos continuam funcionando; os novos são:
// /painelfilas, /filas, /importar, /tipo, /prioridade, /cancelar, /historico.
// Todos ficam escondidos por padrão e só quem tem o cargo de suporte consegue usar.

const { SlashCommandBuilder, REST, Routes, EmbedBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const path = require('path');
const conteudo = require('../conteudo');
const { ErroNegocio } = require('../services/tickets');
const { importarCanal } = require('../services/importar');
const { formatarReais } = require('../util/tempo');
const { nomeComEntregueLegado, nomeComStatusLegado, rotuloTipo } = require('../util/nomes');
const { EFEMERO, atorDe, ticketDoCanal } = require('./contexto');
const { darCargoCliente } = require('./cargos');

const TIPO_INTERNO = { CLEAN: 'CLEAN', 'AVANÇADA': 'AVANCADA', AVANCADA: 'AVANCADA' };

const definicoes = [
  new SlashCommandBuilder().setName('chave').setDescription('Envia a mensagem da chave/pagamento').setDefaultMemberPermissions(0),
  new SlashCommandBuilder()
    .setName('entregue')
    .setDescription('Envia a mensagem de entrega (e dá o cargo de cliente, se marcar o cliente)')
    .setDefaultMemberPermissions(0)
    .addUserOption((o) =>
      o.setName('cliente').setDescription('Cliente do ticket (opcional — se marcar, já dá o cargo "・client" também)').setRequired(false)
    ),
  new SlashCommandBuilder().setName('postar').setDescription('Envia a oferta de postagem premium').setDefaultMemberPermissions(0),
  new SlashCommandBuilder()
    .setName('renomear')
    .setDescription('Muda o status do pedido (fila, em produção, em processo ou renderizando) e renomeia o tópico')
    .setDefaultMemberPermissions(0)
    .addIntegerOption((o) =>
      o.setName('fila').setDescription('Define manualmente o número da fila (não usar com os status abaixo)').setRequired(false).setMinValue(1)
    )
    .addStringOption((o) =>
      o
        .setName('tipo')
        .setDescription('Tipo de edição (usado junto com "fila")')
        .setRequired(false)
        .addChoices({ name: 'Clean', value: 'CLEAN' }, { name: 'Avançada', value: 'AVANÇADA' })
    )
    .addBooleanOption((o) => o.setName('producao').setDescription('Marcar como "Em Produção" (começa a contar o prazo)').setRequired(false))
    .addBooleanOption((o) => o.setName('processo').setDescription('Marcar como "Em Processo"').setRequired(false))
    .addBooleanOption((o) => o.setName('renderizando').setDescription('Marcar como "Renderizando"').setRequired(false)),
  new SlashCommandBuilder()
    .setName('confirmarpagamento')
    .setDescription('Confirma o pagamento manualmente e dá o cargo de cliente')
    .setDefaultMemberPermissions(0)
    .addUserOption((o) => o.setName('usuario').setDescription('Cliente que pagou').setRequired(true)),
  new SlashCommandBuilder().setName('valores').setDescription('Mostra a tabela de valores das edits').setDefaultMemberPermissions(0),
  new SlashCommandBuilder().setName('painel').setDescription('Posta o painel de abertura de ticket neste canal').setDefaultMemberPermissions(0),

  // ----- novos -----
  new SlashCommandBuilder()
    .setName('painelfilas')
    .setDescription('Instala (ou move) o painel de monitoramento das filas neste canal')
    .setDefaultMemberPermissions(0),
  new SlashCommandBuilder()
    .setName('filas')
    .setDescription('Mostra as filas Clean e Avançada (pendentes e em produção)')
    .setDefaultMemberPermissions(0),
  new SlashCommandBuilder()
    .setName('importar')
    .setDescription('Importa os tickets que já estão abertos no canal de tickets (Rio Bot / bot antigo)')
    .setDefaultMemberPermissions(0),
  new SlashCommandBuilder()
    .setName('tipo')
    .setDescription('Define ou troca o tipo do pedido deste ticket (move para a outra fila)')
    .setDefaultMemberPermissions(0)
    .addStringOption((o) =>
      o
        .setName('tipo')
        .setDescription('Tipo da edição')
        .setRequired(true)
        .addChoices({ name: 'Clean', value: 'CLEAN' }, { name: 'Avançada', value: 'AVANÇADA' })
    ),
  new SlashCommandBuilder()
    .setName('prioridade')
    .setDescription('Marca (ou desmarca) este pedido com a prioridade paga de R$ 5')
    .setDefaultMemberPermissions(0)
    .addBooleanOption((o) => o.setName('ativar').setDescription('Padrão: ativar. Use false para remover').setRequired(false)),
  new SlashCommandBuilder()
    .setName('cancelar')
    .setDescription('Cancela o pedido deste ticket (sai das filas)')
    .setDefaultMemberPermissions(0)
    .addStringOption((o) => o.setName('motivo').setDescription('Motivo (fica no histórico)').setRequired(false)),
  new SlashCommandBuilder().setName('historico').setDescription('Mostra o histórico deste ticket').setDefaultMemberPermissions(0),
].map((c) => c.toJSON());

async function registrarComandos(config) {
  const rest = new REST({ version: '10' }).setToken(config.token);
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: definicoes });
  console.log('Comandos registrados.');
}

// ---------- utilidades ----------

const exigirTicket = (ctx, interaction) => {
  const ticket = ticketDoCanal(ctx, interaction.channel);
  if (!ticket) {
    throw new ErroNegocio('Use este comando dentro de um ticket que o sistema reconheça (se for um ticket antigo, use /importar).', 'sem_ticket');
  }
  return ticket;
};

const rotuloStatus = (t) => {
  switch (t.status) {
    case 'NA_FILA':
      return `Fila ${rotuloTipo(t.tipo) ?? ''} #${t.fila_numero ?? '?'}`.replace('  ', ' ');
    case 'EM_PRODUCAO':
      return 'Em produção';
    case 'EM_PROCESSO':
      return 'Em processo';
    case 'RENDERIZANDO':
      return 'Renderizando';
    default:
      return t.status;
  }
};

// ---------- execução ----------

const handlers = {
  async chave(i, ctx) {
    const ticket = ctx.tickets.porThread(i.channelId);
    const produto = ticket?.produto ? ctx.config.produtos[ticket.produto] : null;
    const anexo = conteudo.anexoQrCode();
    await i.reply({
      embeds: [conteudo.embedChave(produto)],
      components: [conteudo.botaoCopiarChave()],
      files: anexo ? [anexo] : [],
    });
    if (ticket && ticket.categoria === 'adquirir_edit') {
      ctx.tickets.marcarChaveAutorizada(ticket.id, atorDe(i.user));
    }
  },

  async entregue(i, ctx) {
    const membro = i.options.getMember('cliente'); // null se não marcar ninguém
    await i.reply({ embeds: [conteudo.embedEntregue()] });

    const ticket = ticketDoCanal(ctx, i.channel);
    if (ticket) {
      try {
        ctx.tickets.mudarStatus(ticket.id, 'ENTREGUE', atorDe(i.user));
      } catch (erro) {
        if (!(erro instanceof ErroNegocio)) throw erro;
        await i.followUp({ content: `⚠️ Mensagem enviada, mas não atualizei a fila: ${erro.message}`, flags: EFEMERO });
      }
    } else if (i.channel?.isThread?.()) {
      ctx.renomeador.solicitar(i.channel.id, nomeComEntregueLegado(i.channel.name)); // ticket que o sistema não conhece
    }

    if (membro) {
      const r = await darCargoCliente(i.guild, membro, ctx.config);
      if (!r.ok) {
        const motivo =
          r.motivo === 'cargo-nao-encontrado'
            ? `Não encontrei o cargo "${ctx.config.cargos.cliente.nome}" no servidor.`
            : `Confira se o bot tem "Gerenciar Cargos" e se o cargo dele está acima do "${ctx.config.cargos.cliente.nome}".`;
        await i.followUp({
          content: `⚠️ Mensagem de entrega enviada, mas não consegui dar o cargo "${ctx.config.cargos.cliente.nome}". ${motivo}`,
          flags: EFEMERO,
        });
      }
    }
  },

  async postar(i) {
    await i.reply({ embeds: [conteudo.embedPostar()] });
  },

  async valores(i) {
    await i.reply({ embeds: [conteudo.embedValores()] });
  },

  async painel(i) {
    const banner = new AttachmentBuilder(path.join(__dirname, '../../assets/central-tickets.png'), { name: 'central-tickets.png' });
    const logo = new AttachmentBuilder(path.join(__dirname, '../../assets/logo-rl.png'), { name: 'logo-rl.png' });
    await i.channel.send({
      embeds: [conteudo.painelAberturaEmbed()],
      components: [conteudo.painelAberturaRow()],
      files: [banner, logo],
    });
    await i.reply({ content: '✅ Painel postado neste canal.', flags: EFEMERO });
  },

  async renomear(i, ctx) {
    const fila = i.options.getInteger('fila');
    const tipo = i.options.getString('tipo');
    const producao = i.options.getBoolean('producao');
    const processo = i.options.getBoolean('processo');
    const renderizando = i.options.getBoolean('renderizando');

    if (!producao && !processo && !renderizando && !fila) {
      await i.reply({
        content: '⚠️ Informe o número da "fila" ou marque "producao"/"processo"/"renderizando" como verdadeiro.',
        flags: EFEMERO,
      });
      return;
    }

    const rotulo = producao
      ? 'Em Produção'
      : processo
        ? 'Em Processo'
        : renderizando
          ? 'Renderizando'
          : `Fila ${fila}${tipo ? ` - ${tipo}` : ''}`;

    await i.deferReply({ flags: EFEMERO });
    const ticket = ticketDoCanal(ctx, i.channel);

    if (!ticket) {
      // Tópico que o sistema não conhece: comportamento antigo (só renomeia)
      if (!i.channel?.isThread?.()) {
        await i.editReply({ content: '⚠️ Use este comando dentro de um ticket.' });
        return;
      }
      ctx.renomeador.solicitar(i.channel.id, nomeComStatusLegado(i.channel.name, { fila, tipo, producao, processo, renderizando }));
      await i.editReply({ content: `✅ Tópico renomeado (${rotulo}). (Este ticket não está no sistema de filas — use /importar para incluí-lo.)` });
      return;
    }

    const ator = atorDe(i.user);
    if (producao) ctx.tickets.mudarStatus(ticket.id, 'EM_PRODUCAO', ator);
    else if (processo) ctx.tickets.mudarStatus(ticket.id, 'EM_PROCESSO', ator);
    else if (renderizando) ctx.tickets.mudarStatus(ticket.id, 'RENDERIZANDO', ator);
    else ctx.tickets.definirNumeroManual(ticket.id, { tipo: tipo ? TIPO_INTERNO[tipo] : null, numero: fila }, ator);

    await i.editReply({
      content: `✅ Pedido atualizado (${rotulo}). O nome do tópico muda sozinho em instantes (o Discord limita a 2 renomeações a cada 10 min).`,
    });
  },

  async confirmarpagamento(i, ctx) {
    const membro = i.options.getMember('usuario');
    if (!membro) {
      await i.reply({ content: '⚠️ Não encontrei esse usuário no servidor.', flags: EFEMERO });
      return;
    }

    // Se o comando foi usado no ticket desse cliente, também registra o pagamento e põe na fila
    let extra = '';
    const ticket = ticketDoCanal(ctx, i.channel);
    if (ticket && ticket.user_id === membro.id && !ticket.pago_em) {
      const r = ctx.tickets.confirmarPagamento(ticket.id, { modo: 'manual' }, atorDe(i.user));
      if (r.entrouNaFila) extra = ` Pedido na fila ${rotuloTipo(r.ticket.tipo)} #${r.ticket.fila_numero}.`;
      else if (r.ticket.status === 'PAGO') extra = ' Falta definir o tipo (Clean/Avançada) com /tipo para entrar na fila.';
    } else if (!ticket) {
      extra = '\n⚠️ Este canal não é um ticket reconhecido: só o cargo foi dado, nenhum pedido foi registrado.';
    } else if (ticket.user_id !== membro.id && !ticket.pago_em) {
      extra = `\n⚠️ O dono deste ticket é <@${ticket.user_id}>, não ${membro}. Só o cargo foi dado: o pagamento NÃO foi registrado e o pedido NÃO entrou na fila. Use o comando de novo escolhendo o dono do ticket.`;
    } else if (ticket.pago_em) {
      extra = '\nℹ️ O pagamento deste ticket já estava registrado.';
    }

    const r = await darCargoCliente(i.guild, membro, ctx.config);
    if (r.ok) {
      await i.reply({ content: `✅ Pagamento confirmado! Cargo "${ctx.config.cargos.cliente.nome}" adicionado pra ${membro}.${extra}`, flags: EFEMERO });
    } else if (r.motivo === 'cargo-nao-encontrado') {
      await i.reply({ content: `⚠️ Não encontrei o cargo "${ctx.config.cargos.cliente.nome}" no servidor. Confira se o nome está exatamente igual.${extra}`, flags: EFEMERO });
    } else {
      await i.reply({
        content: `⚠️ Não consegui adicionar o cargo. Confira se o bot tem a permissão "Gerenciar Cargos" e se o cargo dele está ACIMA do cargo "${ctx.config.cargos.cliente.nome}" na lista de cargos do servidor.${extra}`,
        flags: EFEMERO,
      });
    }
  },

  async painelfilas(i, ctx) {
    await i.deferReply({ flags: EFEMERO });
    await ctx.painel.instalar(i.channel);

    const publico = i.channel.permissionsFor?.(i.guild.roles.everyone)?.has(PermissionFlagsBits.ViewChannel);
    const aviso = publico
      ? '\n\n⚠️ **Atenção:** este canal está visível para todos (@everyone). Ajuste as permissões do canal para que só o cargo de suporte consiga ver.'
      : '';
    await i.editReply({ content: `✅ Painel de filas instalado neste canal. Ele se atualiza sozinho.${aviso}` });
  },

  async filas(i, ctx) {
    await i.reply({ embeds: ctx.painel.embedsDasFilas(), flags: EFEMERO });
  },

  async importar(i, ctx) {
    await i.deferReply({ flags: EFEMERO });
    const canal = await i.client.channels.fetch(ctx.config.canais.tickets).catch(() => null);
    if (!canal || !canal.threads) {
      await i.editReply({ content: '⚠️ Não encontrei o canal de tickets (confira TICKET_FORUM_ID no .env).' });
      return;
    }

    const r = await importarCanal(ctx.tickets, canal);
    const pulados = Object.entries(r.pulados).map(([motivo, n]) => `${n}× ${motivo}`);
    await i.editReply({
      content: [
        `✅ Importação concluída: **${r.importados}** ticket(s) novo(s), ${r.jaExistiam} já existia(m).`,
        pulados.length ? `Ignorados: ${pulados.join(', ')}.` : null,
        'Pedidos importados "em produção" têm o prazo de 42h contado a partir de agora (o bot não sabe quando entraram).',
      ]
        .filter(Boolean)
        .join('\n'),
    });
    ctx.painel.agendar();
  },

  async tipo(i, ctx) {
    const ticket = exigirTicket(ctx, i);
    const novo = TIPO_INTERNO[i.options.getString('tipo', true)];
    const atualizado = ctx.tickets.definirTipo(ticket.id, novo, atorDe(i.user));
    await i.reply({ content: `✅ Pedido agora é **${rotuloTipo(novo)}** — ${rotuloStatus(atualizado)}.`, flags: EFEMERO });
  },

  async prioridade(i, ctx) {
    const ticket = exigirTicket(ctx, i);
    const ativar = i.options.getBoolean('ativar') ?? true;
    ctx.tickets.definirPrioridade(ticket.id, ativar, atorDe(i.user));
    await i.reply({ content: ativar ? '⚡ Pedido marcado com prioridade.' : '✅ Prioridade removida do pedido.', flags: EFEMERO });
  },

  async cancelar(i, ctx) {
    const ticket = exigirTicket(ctx, i);
    const motivo = i.options.getString('motivo');
    ctx.tickets.mudarStatus(ticket.id, 'CANCELADO', atorDe(i.user), motivo || undefined);
    await i.reply({ content: '✅ Pedido cancelado e removido das filas.', flags: EFEMERO });
  },

  async historico(i, ctx) {
    const ticket = exigirTicket(ctx, i);
    const eventos = ctx.tickets.historico(ticket.id);
    const linhas = eventos.map(
      (e) => `<t:${Math.floor(e.em / 1000)}:d> <t:${Math.floor(e.em / 1000)}:t> · **${e.tipo}** · ${e.ator_nome ?? 'sistema'}${e.detalhe ? ` — ${e.detalhe}` : ''}`
    );

    let texto = '';
    for (const l of linhas.slice().reverse()) {
      if (texto.length + l.length + 1 > 3800) break;
      texto = l + '\n' + texto; // mantém só os mais recentes se for muito longo
    }

    const embed = new EmbedBuilder()
      .setColor('#0E1C40')
      .setTitle(`📜 Histórico — ${rotuloStatus(ticket)}`)
      .setDescription(texto || 'Sem eventos.')
      .setFooter({
        text: ticket.preco_centavos != null ? `Valor esperado: ${formatarReais(ticket.preco_centavos)}` : 'Valor esperado: não definido',
      });
    await i.reply({ embeds: [embed], flags: EFEMERO });
  },
};

module.exports = { definicoes, registrarComandos, handlers };
