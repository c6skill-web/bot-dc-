'use strict';
// Abertura de ticket e escolha do produto (dentro do ticket "Adquirir Edit").

const { ChannelType } = require('discord.js');
const { acharCategoria, menuProdutoRow, embedChave, anexoQrCode, botaoCopiarChave } = require('../conteudo');
const { temCargo } = require('../util/permissoes');
const { EFEMERO, atorDe } = require('./contexto');
const { TEXTO_FECHAR, botaoFechar } = require('./fechamento');
const { topicoFoiApagado } = require('./topicos');

const SISTEMA = { id: null, nome: 'sistema' };

async function abrirTicket(interaction, ctx, categoria) {
  await interaction.deferReply({ flags: EFEMERO });
  const { tickets } = ctx;

  // Cada pessoa só pode ter 1 ticket ativo
  const ativo = tickets.ativoDoUsuario(interaction.user.id);
  if (ativo) {
    if (!(await topicoFoiApagado(interaction.client, ativo))) {
      await interaction.editReply({ content: `⚠️ Você já tem um ticket aberto: <#${ativo.thread_id}>` });
      return;
    }
    // o tópico foi apagado no Discord (e o bot tem certeza): encerra o registro "fantasma" e deixa abrir outro
    tickets.mudarStatus(ativo.id, 'CANCELADO', SISTEMA, 'Tópico apagado no Discord');
  }

  const usuario = interaction.user;
  const thread = await interaction.channel.threads.create({
    name: `${categoria.emoji} ${usuario.username} (${usuario.id})`.slice(0, 100),
    type: ChannelType.PrivateThread,
    autoArchiveDuration: 10080,
    reason: `Ticket aberto por ${usuario.tag} (${usuario.id}) — ${categoria.label}`,
  });

  try {
    tickets.criar(
      {
        threadId: thread.id,
        parentId: interaction.channel.id,
        userId: usuario.id,
        userName: usuario.username,
        categoria: categoria.value,
      },
      atorDe(usuario)
    );
  } catch (erro) {
    await thread.delete().catch(() => {}); // não deixa tópico órfão se o registro falhou
    throw erro;
  }

  const mensagem = categoria.boasVindas
    .replace(/{{userMention}}/g, `<@${usuario.id}>`)
    .replace(/{{supportRole}}/g, `\`${ctx.config.cargos.suporte.nome}\``);

  // Por padrão o ticket abre como no Rio Bot (só a mensagem de boas-vindas).
  // Com MENU_PRODUTO=sim aparece o menu de produtos (o bot passa a saber o valor esperado).
  const comMenu = categoria.value === 'adquirir_edit' && ctx.config.ticket?.menuProduto;
  await thread.send({
    content: comMenu ? `${mensagem}\n\n👇 **Escolha abaixo o tipo e a duração da sua edit** para ver o valor e a chave Pix:` : mensagem,
    components: comMenu ? [menuProdutoRow()] : [],
  });
  await thread.send({ content: TEXTO_FECHAR, components: [botaoFechar()] });

  await interaction.editReply({ content: `✅ Ticket criado: ${thread}` });
}

async function escolherProduto(interaction, ctx) {
  const ticket = ctx.tickets.porThread(interaction.channelId);
  if (!ticket) {
    await interaction.reply({ content: '⚠️ Este ticket não está registrado no sistema. Chame a equipe.', flags: EFEMERO });
    return;
  }

  const ehDono = interaction.user.id === ticket.user_id;
  const ehSuporte = temCargo(interaction.member, ctx.config.cargos.suporte);
  if (!ehDono && !ehSuporte) {
    await interaction.reply({ content: '🚫 Só quem abriu o ticket (ou a equipe) pode escolher.', flags: EFEMERO });
    return;
  }

  const chave = interaction.values[0];
  const produto = ctx.config.produtos[chave];
  ctx.tickets.definirProduto(ticket.id, chave, atorDe(interaction.user));

  const anexo = anexoQrCode();
  await interaction.reply({
    content: `✅ **${produto.label}** selecionada. Faça o pagamento e envie o comprovante aqui mesmo — ${ctx.config.pagamento.modo === 'auto' ? 'a confirmação é automática' : 'a equipe confirma o pagamento'}.`,
    embeds: [embedChave(produto)],
    components: [botaoCopiarChave()],
    files: anexo ? [anexo] : [],
  });
}

module.exports = { abrirTicket, escolherProduto, acharCategoria };
