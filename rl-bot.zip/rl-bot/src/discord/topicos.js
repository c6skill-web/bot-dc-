'use strict';
// "O tópico do ticket foi apagado?" — com cuidado para NÃO cancelar pedidos por engano.
//
// Quando o bot não enxerga um tópico PRIVADO (não é membro dele e não tem "Gerenciar Tópicos"),
// o Discord responde "Unknown Channel (10003)", igual a um tópico apagado de verdade.
// Então só dá para afirmar que foi apagado se o bot consegue ver todos os tópicos privados.

const { PermissionFlagsBits } = require('discord.js');

async function topicoFoiApagado(client, ticket) {
  try {
    await client.channels.fetch(ticket.thread_id);
    return false; // existe
  } catch (erro) {
    if (erro.code !== 10003) return false; // sem acesso, rede fora do ar...: não dá pra afirmar nada
  }

  try {
    const pai = await client.channels.fetch(ticket.parent_id);
    const eu = pai.guild.members.me ?? (await pai.guild.members.fetchMe());
    return pai.permissionsFor(eu).has(PermissionFlagsBits.ManageThreads);
  } catch {
    return false;
  }
}

module.exports = { topicoFoiApagado };
