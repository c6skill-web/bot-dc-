'use strict';
// Pequenos auxiliares compartilhados pelos handlers do Discord.

const { MessageFlags } = require('discord.js');
const { ErroNegocio } = require('../services/tickets');
const { importarThread } = require('../services/importar');

const EFEMERO = MessageFlags.Ephemeral;

function atorDe(usuario) {
  return { id: usuario.id, nome: usuario.tag || usuario.username };
}

// Acha o ticket do tópico atual. Se o bot ainda não conhece o tópico (ex.: criado pelo Rio Bot),
// tenta importar pelo nome. Retorna null se não for um ticket reconhecível.
function ticketDoCanal(ctx, canal) {
  if (!canal || !canal.isThread || !canal.isThread()) return null;
  const existente = ctx.tickets.porThread(canal.id);
  if (existente) return existente;
  if (canal.parentId !== ctx.config.canais.tickets) return null;
  try {
    const r = importarThread(ctx.tickets, canal);
    return r.ticket || null;
  } catch (erro) {
    console.error('Erro ao importar tópico automaticamente:', erro.message);
    return null;
  }
}

async function responderErro(interaction, erro) {
  const texto =
    erro instanceof ErroNegocio
      ? `⚠️ ${erro.message}`
      : '⚠️ Ocorreu um erro inesperado. Tente de novo; se continuar, avise o administrador.';
  if (!(erro instanceof ErroNegocio)) console.error('Erro em interação:', erro);

  try {
    if (interaction.deferred || interaction.replied) await interaction.followUp({ content: texto, flags: EFEMERO });
    else await interaction.reply({ content: texto, flags: EFEMERO });
  } catch {
    /* a interação pode ter expirado */
  }
}

module.exports = { EFEMERO, atorDe, ticketDoCanal, responderErro };
