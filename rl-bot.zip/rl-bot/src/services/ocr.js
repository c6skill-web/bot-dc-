'use strict';
// Leitura de imagem (OCR). Um único "worker" reaproveitado e uma fila:
// só uma imagem é lida por vez, para não travar o PC quando chegarem várias juntas.

let workerPromise = null;
let fila = Promise.resolve();

function obterWorker() {
  if (!workerPromise) {
    const Tesseract = require('tesseract.js');
    workerPromise = Tesseract.createWorker('por').catch((erro) => {
      workerPromise = null; // tenta criar de novo na próxima imagem
      throw erro;
    });
  }
  return workerPromise;
}

// `imagem` pode ser um Buffer ou uma URL
function lerTexto(imagem) {
  const tarefa = fila.then(async () => {
    const worker = await obterWorker();
    const resultado = await worker.recognize(imagem);
    return resultado?.data?.text || '';
  });
  fila = tarefa.catch(() => {});
  return tarefa;
}

// Cria o leitor logo ao ligar o bot. Na primeira vez ele baixa o idioma português (alguns MB):
// sem isso, esse download acontecia justamente no PRIMEIRO comprovante.
function preaquecer() {
  return obterWorker();
}

async function encerrar() {
  if (!workerPromise) return;
  try {
    const worker = await workerPromise;
    await worker.terminate();
  } catch {
    /* ignora */
  } finally {
    workerPromise = null;
  }
}

module.exports = { lerTexto, preaquecer, encerrar };
