'use strict';
// Contagem de edits (mensagens no canal de avaliações) e cargos de nível.
// Mesma regra do bot antigo; a diferença é que agora a contagem fica no banco
// (o JSON antigo era regravado inteiro a cada mensagem e podia corromper).

const fs = require('fs');
const { lerMeta, gravarMeta } = require('../db');

function registrarAvaliacao(db, userId) {
  db.prepare(
    'INSERT INTO edits (user_id, total) VALUES (?, 1) ON CONFLICT(user_id) DO UPDATE SET total = total + 1'
  ).run(String(userId));
  return db.prepare('SELECT total FROM edits WHERE user_id = ?').get(String(userId)).total;
}

async function verificarNiveis(guild, membro, contagem, niveis) {
  for (const nivel of niveis) {
    if (contagem < nivel.minimo) continue;

    const cargo = guild.roles.cache.find((r) => r.name === nivel.cargo);
    if (!cargo) continue;
    if (membro.roles.cache.has(cargo.id)) continue;

    try {
      await membro.roles.add(cargo);
      console.log(`Cargo "${nivel.cargo}" dado pra ${membro.user.tag} (${contagem} edits)`);
    } catch (erro) {
      console.error('Erro ao dar cargo de nível:', erro);
    }
  }
}

// Traz a contagem do dados-edits.json do bot antigo (roda só uma vez)
function migrarContagemLegada(db, caminhos) {
  if (lerMeta(db, 'edits_legado_migrado')) return { migrado: false, motivo: 'ja_migrado' };

  const arquivo = caminhos.find((c) => fs.existsSync(c));
  if (!arquivo) return { migrado: false, motivo: 'sem_arquivo' };

  let dados;
  try {
    dados = JSON.parse(fs.readFileSync(arquivo, 'utf-8'));
  } catch (erro) {
    console.error(`Não consegui ler ${arquivo} para migrar a contagem de edits:`, erro.message);
    return { migrado: false, motivo: 'arquivo_invalido' };
  }

  const inserir = db.prepare(
    `INSERT INTO edits (user_id, total) VALUES (?, ?)
     ON CONFLICT(user_id) DO UPDATE SET total = MAX(total, excluded.total)`
  );
  let quantidade = 0;
  db.transaction(() => {
    for (const [userId, total] of Object.entries(dados)) {
      if (Number.isInteger(total) && total > 0) {
        inserir.run(userId, total);
        quantidade++;
      }
    }
    gravarMeta(db, 'edits_legado_migrado', '1');
  })();

  console.log(`Contagem de edits migrada de ${arquivo}: ${quantidade} clientes.`);
  return { migrado: true, quantidade };
}

module.exports = { registrarAvaliacao, verificarNiveis, migrarContagemLegada };
