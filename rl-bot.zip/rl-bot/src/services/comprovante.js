'use strict';
// Análise do TEXTO lido (OCR) de um comprovante de Pix.
// Função pura: recebe texto + contexto e devolve o que achou. Não fala com o Discord nem com o banco.
//
// O bot SEMPRE responde a algo que pareça comprovante (como o bot antigo) e mostra o que leu e o que
// não bateu, em vez de ignorar em silêncio. Só fica quieto com imagem que nem parece comprovante.
//
// Para o bot confirmar SOZINHO (modo auto), o comprovante precisa passar em TODAS as travas:
//   1. parecer um comprovante e ser para a RL (nome/chave do recebedor reconhecidos)
//   2. valor lido == valor esperado do produto escolhido
//   3. ter ID da transação legível (e nunca ter sido usado antes — checado no banco)
//   4. ter data legível, e a data não pode ser ANTERIOR à abertura do ticket
// Qualquer falha -> cai para a confirmação manual da equipe (com o motivo escrito).
//
// Limite honesto: o OCR lê a imagem, não o banco. Uma imagem editada com tudo certo
// ainda passaria. A única garantia real é consultar o banco/gateway (ver README, "Pagamento").

const { diaNoFuso, formatarReais } = require('../util/tempo');

const MESES = { jan: 1, fev: 2, mar: 3, abr: 4, mai: 5, jun: 6, jul: 7, ago: 8, set: 9, out: 10, nov: 11, dez: 12 };

const PALAVRAS_COMPROVANTE = [
  'comprovante', 'transferencia', 'pix', 'transacao', 'nu pagamentos', 'nubank', 'mercado pago',
  'picpay', 'banco inter', 'itau', 'bradesco', 'santander', 'c6 bank', 'caixa economica',
  'pagamento realizado', 'pagamento efetuado',
];

// ID "ponta a ponta" do Pix: E + 8 dígitos (banco) + 12 dígitos (data/hora) + 11 caracteres = 32
const REGEX_ID_PIX = /\bE\d{8}\d{12}[A-Z0-9]{11}\b/;
// Rótulos que os bancos usam para o código da transação (cada banco escreve de um jeito)
const ROTULOS_ID = [
  'ID DA TRANSACAO', 'ID DA TRANSFERENCIA', 'ID DE TRANSACAO', 'ID TRANSACAO', 'NUMERO DA OPERACAO',
  'NUMERO DA TRANSACAO', 'CODIGO DE AUTENTICACAO', 'CODIGO DE IDENTIFICACAO', 'AUTENTICACAO',
  'PROTOCOLO', 'END TO END', 'ENDTOEND', 'E2E',
];

function normalizar(texto) {
  return String(texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function soAlfanumerico(texto) {
  return normalizar(texto).replace(/[^a-z0-9]/g, '');
}

function paraCentavos(texto) {
  let s = String(texto).trim();
  if (/,\d{2}$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (/\.\d{2}$/.test(s)) s = s.replace(/,/g, '');
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) : null;
}

const NUM = '(\\d{1,3}(?:\\.\\d{3})*,\\d{2}|\\d+,\\d{2}|\\d+\\.\\d{2})';

function extrairValor(textoNorm) {
  // o OCR às vezes lê o zero como letra "o" dentro de números (1o,00)
  const limpo = textoNorm.replace(/(?<=\d)o(?=[\d,.])/g, '0');
  // 1) o número logo depois da palavra "valor"
  const rotulo = limpo.match(new RegExp(`valor[^\\d\\n]{0,20}?${NUM}`));
  if (rotulo) return paraCentavos(rotulo[1]);
  // 2) o primeiro "R$ 0,00" do texto (o OCR às vezes lê R$ como RS ou R5)
  const rs = limpo.match(new RegExp(`r[$s5]\\s*${NUM}`));
  if (rs) return paraCentavos(rs[1]);
  // 3) valor inteiro, sem centavos (alguns apps escrevem "R$ 10")
  const inteiro = limpo.match(/r[$s5]\s*(\d{1,6})(?![\d.,])/);
  return inteiro ? Number(inteiro[1]) * 100 : null;
}

function extrairTxId(textoNorm) {
  const t = textoNorm.toUpperCase();
  const padrao = t.match(REGEX_ID_PIX);
  if (padrao) return padrao[0];

  // Rótulo ("ID da transação", "Número da operação", "Protocolo"...) seguido de um código com vários dígitos
  for (const rotulo of ROTULOS_ID) {
    const i = t.indexOf(rotulo);
    if (i < 0) continue;
    const resto = t.slice(i + rotulo.length, i + rotulo.length + 80);
    const codigo = (resto.match(/[A-Z0-9]{8,40}/g) || []).find((x) => (x.match(/\d/g) || []).length >= 6);
    if (codigo) return codigo;
  }
  return null;
}

function dataValida(a, m, d) {
  return a >= 2020 && a <= 2100 && m >= 1 && m <= 12 && d >= 1 && d <= 31;
}

function extrairData(textoNorm) {
  const iso = textoNorm.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (iso && dataValida(Number(iso[1]), Number(iso[2]), Number(iso[3]))) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const num = textoNorm.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (num) {
    const [d, m, a] = [Number(num[1]), Number(num[2]), Number(num[3])];
    if (dataValida(a, m, d)) return `${a}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  const ext = textoNorm.match(/(\d{1,2})\s+(?:de\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-z]*\.?\s+(?:de\s+)?(\d{4})/);
  if (ext) {
    const [d, m, a] = [Number(ext[1]), MESES[ext[2]], Number(ext[3])];
    if (dataValida(a, m, d)) return `${a}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }
  return null;
}

function parecerComprovante(textoNorm, pix) {
  const chave = soAlfanumerico(pix.chave);
  if (chave && soAlfanumerico(textoNorm).includes(chave)) return true;
  if (PALAVRAS_COMPROVANTE.some((p) => textoNorm.includes(p))) return true;
  if (REGEX_ID_PIX.test(textoNorm.toUpperCase())) return true;
  return /valor[^\d\n]{0,20}\d+[.,]\d{2}/.test(textoNorm);
}

// Distância de edição <= 1: tolera um erro de leitura do OCR (Vieira -> Vleira)
function parecidas(a, b) {
  if (a === b) return true;
  if (Math.min(a.length, b.length) < 5 || Math.abs(a.length - b.length) > 1) return false;
  if (a.length === b.length) {
    let diferentes = 0;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i] && ++diferentes > 1) return false;
    return true;
  }
  const [curta, longa] = a.length < b.length ? [a, b] : [b, a];
  let i = 0;
  while (i < curta.length && curta[i] === longa[i]) i++;
  return curta.slice(i) === longa.slice(i + 1);
}

// 'confirmado' = nome (ou chave) da RL aparece; 'parcial' = só reconheci o banco; 'nao_reconhecido'
function nivelDoDestinatario(textoNorm, pix) {
  const corpo = soAlfanumerico(textoNorm);
  const chave = soAlfanumerico(pix.chave);
  if (chave && corpo.includes(chave)) return 'confirmado';
  // bancos mascaram a chave, mas costumam mostrar um pedaço dela
  if (chave.length >= 12 && (corpo.includes(chave.slice(-8)) || corpo.includes(chave.slice(0, 8)))) return 'confirmado';

  const nome = soAlfanumerico(pix.nome);
  if (nome && corpo.includes(nome)) return 'confirmado';
  const partes = normalizar(pix.nome).split(/[^a-z0-9]+/).filter((x) => x.length >= 3);
  const palavras = textoNorm.split(/[^a-z0-9]+/).filter(Boolean);
  if (partes.length && partes.every((parte) => palavras.some((w) => parecidas(w, parte)))) return 'confirmado';

  if (textoNorm.includes('nu pagamentos') || /\bnubank\b/.test(textoNorm)) return 'parcial';
  return 'nao_reconhecido';
}

const TEXTO_PROBLEMA = {
  valor_ilegivel: () => 'não consegui ler o valor no comprovante',
  valor_diferente: (c) => `valor diferente do esperado (esperado ${formatarReais(c.esperado)}, lido ${formatarReais(c.lido)})`,
  sem_valor_esperado: () => 'o cliente ainda não escolheu o produto, então não sei qual valor esperar',
  destinatario_parcial: () => 'só reconheci o banco (Nubank), não o nome nem a chave da RL — confira o destinatário',
  destinatario: () => 'não consegui confirmar que o comprovante é para a RL (nome/chave não apareceram na leitura)',
  sem_id: () => 'não consegui ler o ID da transação',
  sem_data: () => 'não consegui ler a data do comprovante',
  data_antiga: () => 'a data do comprovante é anterior à abertura do ticket',
  data_futura: () => 'a data do comprovante está no futuro',
};

function analisarComprovante(texto, contexto) {
  const { esperadoCentavos = null, ticketCriadoEm = null, agora = Date.now(), pix, fuso = 'America/Sao_Paulo' } = contexto;

  const norm = normalizar(texto);
  const parece = parecerComprovante(norm, pix);
  const nivelDestinatario = nivelDoDestinatario(norm, pix);
  const destinatarioOk = nivelDestinatario === 'confirmado';
  const valorCentavos = extrairValor(norm);
  const txId = extrairTxId(norm);
  const data = extrairData(norm);

  // Mesma regra do bot antigo: se PARECE comprovante, responde. O que não bateu (destinatário,
  // valor, ID, data) vira aviso para a equipe, nunca silêncio.
  const relevante = parece;

  const problemas = [];
  if (relevante) {
    if (nivelDestinatario === 'parcial') problemas.push({ codigo: 'destinatario_parcial', contexto: {} });
    else if (nivelDestinatario === 'nao_reconhecido') problemas.push({ codigo: 'destinatario', contexto: {} });

    if (esperadoCentavos == null) problemas.push({ codigo: 'sem_valor_esperado', contexto: {} });
    else if (valorCentavos == null) problemas.push({ codigo: 'valor_ilegivel', contexto: {} });
    else if (valorCentavos !== esperadoCentavos) {
      problemas.push({ codigo: 'valor_diferente', contexto: { esperado: esperadoCentavos, lido: valorCentavos } });
    }

    if (!txId) problemas.push({ codigo: 'sem_id', contexto: {} });

    if (!data) problemas.push({ codigo: 'sem_data', contexto: {} });
    else if (ticketCriadoEm != null) {
      if (data < diaNoFuso(ticketCriadoEm, fuso)) problemas.push({ codigo: 'data_antiga', contexto: {} });
      else if (data > diaNoFuso(agora, fuso)) problemas.push({ codigo: 'data_futura', contexto: {} });
    }
  }

  return {
    pareceComprovante: parece,
    destinatarioOk,
    nivelDestinatario,
    relevante,
    valorCentavos,
    txId,
    data,
    problemas: problemas.map((p) => ({ codigo: p.codigo, texto: TEXTO_PROBLEMA[p.codigo](p.contexto) })),
    aprovadoAuto: relevante && problemas.length === 0,
  };
}

module.exports = { analisarComprovante, normalizar, extrairValor, extrairTxId, extrairData, paraCentavos };
