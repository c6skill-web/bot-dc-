'use strict';
// Avisos automáticos para a equipe: prazo chegando, prazo estourado e fila acumulada.
// Cada aviso é mandado UMA vez por pedido (o banco guarda o que já foi avisado,
// então reiniciar o bot não repete aviso).

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { lerMeta, gravarMeta } = require('../db');
const { formatarDuracao } = require('../util/tempo');
const { rotuloTipo } = require('../util/nomes');

function criarAlertas({ tickets, notificar, painel, db, config, agora = () => Date.now() }) {
  let intervalo = null;

  const descricao = (t) => `**#${t.fila_numero ?? '?'} ${rotuloTipo(t.tipo) ?? 'sem tipo'}** <#${t.thread_id}> (cliente <@${t.user_id}>)`;

  async function verificar() {
    const agoraMs = agora();
    const { atrasados, proximos } = tickets.alertasDePrazo(agoraMs);

    for (const t of atrasados) {
      const ok = await notificar.avisarEquipe({
        pingarSuporte: true,
        conteudo: `🔴 **Pedido atrasado** — ${descricao(t)} passou do prazo de ${config.prazo.horas}h (atrasado há ${formatarDuracao(agoraMs - t.prazo_em)}).`,
      });
      if (ok) tickets.marcarAlertaEnviado(t.id, 'atraso');
    }

    for (const t of proximos) {
      const ok = await notificar.avisarEquipe({
        conteudo: `🟡 **Prazo chegando** — ${descricao(t)} tem ${formatarDuracao(t.prazo_em - agoraMs)} restantes.`,
      });
      if (ok) tickets.marcarAlertaEnviado(t.id, 'aviso');
    }

    const limite = config.fila.limiteAcumulada;
    if (limite > 0) {
      const snap = tickets.snapshot(agoraMs);
      for (const tipo of ['CLEAN', 'AVANCADA']) {
        const qtd = snap.porTipo[tipo].pendentes.length;
        const chave = `acumulo_${tipo}`;
        const jaAvisado = lerMeta(db, chave) === '1';
        if (qtd >= limite && !jaAvisado) {
          const ok = await notificar.avisarEquipe({
            pingarSuporte: true,
            conteudo: `📈 **Fila ${rotuloTipo(tipo)} acumulada** — ${qtd} pedidos pendentes (limite configurado: ${limite}).`,
          });
          if (ok) gravarMeta(db, chave, '1');
        } else if (qtd < limite && jaAvisado) {
          gravarMeta(db, chave, null); // normalizou: pode avisar de novo no próximo acúmulo
        }
      }
    }

    // Tickets fechados há N dias: pede a confirmação da equipe para apagar (uma vez por ticket)
    for (const t of tickets.fechadosParaApagar(agoraMs)) {
      const botoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`apagar_ticket_${t.id}`).setLabel('Apagar ticket').setEmoji('🗑️').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`manter_ticket_${t.id}`).setLabel('Manter').setStyle(ButtonStyle.Secondary)
      );
      const ok = await notificar.avisarEquipe({
        pingarSuporte: true,
        conteudo: `🗑️ **Ticket fechado há ${config.fechamento.apagarAposDias} dias** — <#${t.thread_id}> (cliente <@${t.user_id}>). Posso apagar de vez? Só apago se alguém da equipe confirmar.`,
        components: [botoes],
      });
      if (ok) tickets.marcarAvisoApagar(t.id);
    }

    painel.agendar(); // as cores/contagens de prazo mudam com o tempo
  }

  function iniciar() {
    const rodar = () => verificar().catch((erro) => console.error('Erro na verificação de alertas:', erro.message));
    setTimeout(rodar, 20 * 1000).unref?.();
    intervalo = setInterval(rodar, config.alertas.verificacaoMs);
    if (intervalo.unref) intervalo.unref();
  }

  function parar() {
    if (intervalo) clearInterval(intervalo);
    intervalo = null;
  }

  return { verificar, iniciar, parar };
}

module.exports = { criarAlertas };
