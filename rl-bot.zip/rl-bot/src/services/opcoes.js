'use strict';
// Dado o VALOR lido no comprovante, descobre quais pedidos são possíveis.
// Sem o menu de produto o bot não sabe o que o cliente comprou, e o mesmo valor pode ser
// mais de uma coisa (R$ 15 = Clean 1min, Avançada 30s ou Clean 30s + prioridade de R$ 5).
// A equipe escolhe a opção certa num botão. Função pura (sem Discord, sem banco).

const SUFIXO_PRIORIDADE = '+p';

function opcoesParaValor(valorCentavos, produtos, adicionais = {}) {
  if (valorCentavos == null) return [];
  const extra = adicionais.prioridade?.precoCentavos ?? null;
  const lista = [];

  for (const [chave, produto] of Object.entries(produtos)) {
    if (!produto.tipo) continue; // "Postar com Qualidade" não entra em fila
    if (produto.precoCentavos === valorCentavos) {
      lista.push({ chave, prioridade: false, produto, tipo: produto.tipo, totalCentavos: valorCentavos });
    }
    if (extra != null && produto.precoCentavos + extra === valorCentavos) {
      lista.push({ chave, prioridade: true, produto, tipo: produto.tipo, totalCentavos: valorCentavos });
    }
  }

  // sem prioridade primeiro, depois por preço do produto: a opção mais comum aparece antes
  return lista.sort((a, b) => Number(a.prioridade) - Number(b.prioridade));
}

const codigoDaOpcao = (o) => `${o.chave}${o.prioridade ? SUFIXO_PRIORIDADE : ''}`;

function decodificarOpcao(codigo) {
  const prioridade = codigo.endsWith(SUFIXO_PRIORIDADE);
  return { chave: prioridade ? codigo.slice(0, -SUFIXO_PRIORIDADE.length) : codigo, prioridade };
}

const rotuloDaOpcao = (o) => `${o.produto.label}${o.prioridade ? ' + prioridade' : ''}`;

module.exports = { opcoesParaValor, codigoDaOpcao, decodificarOpcao, rotuloDaOpcao };
