'use strict';
// Importa tickets que já existiam (criados pelo Rio Bot ou pelo bot antigo) lendo o NOME do tópico.
// Tickets já entregues/cancelados NÃO são importados (o painel começa a contar de agora).

const { interpretarNome } = require('../util/nomes');
const { CATEGORIAS_TICKET } = require('../conteudo');

function categoriaPeloEmoji(emoji) {
  const achada = CATEGORIAS_TICKET.find((c) => c.emoji === emoji);
  if (achada) return achada.value;
  if (emoji === '🎥') return 'adquirir_edit'; // 🎥 é o emoji que o /renomear coloca em pedidos de edit
  return 'importado';
}

// Importa UM tópico. Retorna { ticket } ou { pulado: 'motivo' }
function importarThread(tickets, thread) {
  const existente = tickets.porThread(thread.id);
  if (existente) return { ticket: existente, jaExistia: true };

  const lido = interpretarNome(thread.name);
  if (!lido.userId) return { pulado: 'sem_id_no_nome' };
  if (lido.status === 'ENTREGUE' || lido.status === 'CANCELADO') return { pulado: 'encerrado' };

  const status = lido.status || 'ABERTO';
  try {
    const ticket = tickets.criarImportado({
      threadId: thread.id,
      parentId: thread.parentId,
      userId: lido.userId,
      userName: lido.userName,
      nomeBase: lido.base,
      categoria: categoriaPeloEmoji(lido.emoji),
      status,
      tipo: lido.tipo,
      filaNumero: lido.filaNumero,
      criadoEm: thread.createdTimestamp ?? null,
    });
    return { ticket };
  } catch (erro) {
    if (/UNIQUE constraint failed/i.test(erro.message)) return { pulado: 'usuario_ja_tem_ticket_ativo' };
    throw erro;
  }
}

// Importa todos os tópicos ativos de um canal
async function importarCanal(tickets, canal) {
  const resumo = { importados: 0, jaExistiam: 0, pulados: {} };
  const ativos = await canal.threads.fetchActive();

  for (const thread of ativos.threads.values()) {
    const r = importarThread(tickets, thread);
    if (r.pulado) resumo.pulados[r.pulado] = (resumo.pulados[r.pulado] || 0) + 1;
    else if (r.jaExistia) resumo.jaExistiam++;
    else resumo.importados++;
  }
  return resumo;
}

module.exports = { importarThread, importarCanal };
