'use strict';
// Painel de monitoramento das filas: UMA mensagem no canal da equipe, editada automaticamente.
// Sempre que um ticket muda (criado, pago, entrou na fila, produção, entregue, cancelado,
// transferido...) o painel é recalculado a partir do BANCO — nunca de contadores soltos —
// então ele não "desincroniza". Várias mudanças seguidas viram uma única edição (debounce).

const { EmbedBuilder } = require('discord.js');
const { formatarDuracao } = require('../util/tempo');
const { lerMeta, gravarMeta } = require('../db');

const EMOJI_TIPO = { CLEAN: '🧼', AVANCADA: '🚀' };
const NOME_TIPO = { CLEAN: 'Clean', AVANCADA: 'Avançada' };
const COR_TIPO = { CLEAN: 0x3498db, AVANCADA: 0x9b59b6 };
const ROTULO_STATUS = { EM_PRODUCAO: 'Em produção', EM_PROCESSO: 'Em processo', RENDERIZANDO: 'Renderizando' };

const num = (t) => (t.fila_numero != null ? `#${t.fila_numero}` : '#?');

function linhaPendente(t, agora) {
  return `${t.prioridade ? '⚡ ' : ''}**${num(t)}** <#${t.thread_id}> · <@${t.user_id}> · há ${formatarDuracao(agora - (t.na_fila_em ?? agora))}`;
}

function linhaProducao(t, agora) {
  let prazo = '';
  if (t.prazo_em != null) {
    prazo =
      t.prazo_em > agora
        ? ` · ⏳ restam ${formatarDuracao(t.prazo_em - agora)}`
        : ` · 🔴 atrasado ${formatarDuracao(agora - t.prazo_em)}`;
  }
  return `${t.prioridade ? '⚡ ' : ''}**${num(t)}** <#${t.thread_id}> · <@${t.user_id}> · ${ROTULO_STATUS[t.status] || t.status}${prazo}`;
}

// Limite do Discord: 1024 caracteres por campo
function campoLista(linhas, vazio = '—', maxChars = 900) {
  if (!linhas.length) return vazio;
  let texto = '';
  let usadas = 0;
  for (const linha of linhas) {
    if (texto.length + linha.length + 1 > maxChars) break;
    texto += (texto ? '\n' : '') + linha;
    usadas++;
  }
  const resto = linhas.length - usadas;
  if (resto > 0) texto += `\n… e mais ${resto}`;
  return texto;
}

// Alertas "de estado" (o que está errado AGORA). Os avisos com mensagem avulsa ficam em alertas.js
function calcularAlertas(snap, agora, { avisoHorasAntes, limiteAcumulada }) {
  const avisoMs = avisoHorasAntes * 3600 * 1000;
  const atrasados = [];
  const proximos = [];
  const acumuladas = [];

  for (const tipo of Object.keys(snap.porTipo)) {
    for (const t of snap.porTipo[tipo].producao) {
      if (t.prazo_em == null) continue;
      if (t.prazo_em <= agora) atrasados.push(t);
      else if (t.prazo_em - agora <= avisoMs) proximos.push(t);
    }
    const qtd = snap.porTipo[tipo].pendentes.length;
    if (limiteAcumulada > 0 && qtd >= limiteAcumulada) acumuladas.push({ tipo, quantidade: qtd });
  }
  return { atrasados, proximos, acumuladas };
}

function montarEmbeds(snap, agora, opcoes) {
  const alertas = calcularAlertas(snap, agora, opcoes);
  const { porTipo } = snap;

  const cor = alertas.atrasados.length ? 0xe74c3c : alertas.proximos.length || alertas.acumuladas.length ? 0xf1c40f : 0x2ecc71;

  const resumo = new EmbedBuilder()
    .setColor(cor)
    .setTitle('📊 Painel de Filas')
    .setDescription('Situação dos pedidos em tempo real. Esta mensagem se atualiza sozinha.')
    .setFooter({ text: `Prazo de entrega: ${opcoes.prazoHoras}h a partir da entrada em produção` })
    .setTimestamp(agora);

  for (const tipo of ['CLEAN', 'AVANCADA']) {
    resumo.addFields({
      name: `${EMOJI_TIPO[tipo]} ${NOME_TIPO[tipo]}`,
      value: `⏳ Pendentes: **${porTipo[tipo].pendentes.length}**\n🎬 Em produção: **${porTipo[tipo].producao.length}**`,
      inline: true,
    });
  }

  resumo.addFields({
    name: '📦 Geral',
    value: `✅ Entregues hoje: **${snap.entreguesHoje}**\n🏁 Entregues no total: **${snap.entreguesTotal}**\n❌ Cancelados: **${snap.canceladosTotal}**`,
    inline: true,
  });

  const outros = [];
  if (snap.aguardandoPagamento) outros.push(`💳 Aguardando pagamento: **${snap.aguardandoPagamento}**`);
  if (snap.pagosSemTipo.length) outros.push(`💰 Pagos, sem tipo definido: **${snap.pagosSemTipo.length}** (use /tipo)`);
  if (snap.semTipo.length) outros.push(`❓ Na fila/produção sem tipo: **${snap.semTipo.length}** (use /tipo)`);
  if (snap.conversasAbertas) outros.push(`💬 Outros tickets abertos: **${snap.conversasAbertas}**`);
  if (outros.length) resumo.addFields({ name: 'Outros', value: outros.join('\n') });

  const linhasAlerta = [];
  const listar = (lista) =>
    lista
      .slice(0, 8)
      .map((t) => `${num(t)} ${NOME_TIPO[t.tipo]} <#${t.thread_id}>`)
      .join(', ') + (lista.length > 8 ? ` e mais ${lista.length - 8}` : '');
  if (alertas.atrasados.length) linhasAlerta.push(`🔴 **${alertas.atrasados.length} atrasado(s):** ${listar(alertas.atrasados)}`);
  if (alertas.proximos.length) linhasAlerta.push(`🟡 **${alertas.proximos.length} com menos de ${opcoes.avisoHorasAntes}h:** ${listar(alertas.proximos)}`);
  for (const a of alertas.acumuladas) {
    linhasAlerta.push(`📈 **Fila ${NOME_TIPO[a.tipo]} acumulada:** ${a.quantidade} pendentes (limite ${opcoes.limiteAcumulada})`);
  }
  if (linhasAlerta.length) resumo.addFields({ name: '⚠️ Alertas', value: campoLista(linhasAlerta, '—', 900) });

  const embeds = [resumo];

  for (const tipo of ['CLEAN', 'AVANCADA']) {
    const g = porTipo[tipo];
    embeds.push(
      new EmbedBuilder()
        .setColor(COR_TIPO[tipo])
        .setTitle(`${EMOJI_TIPO[tipo]} Fila ${NOME_TIPO[tipo]}`)
        .addFields(
          { name: `⏳ Pendentes (${g.pendentes.length})`, value: campoLista(g.pendentes.map((t) => linhaPendente(t, agora))) },
          { name: `🎬 Em produção (${g.producao.length})`, value: campoLista(g.producao.map((t) => linhaProducao(t, agora))) }
        )
    );
  }

  return embeds;
}

function criarPainel({ client, db, tickets, config, agora = () => Date.now() }) {
  let timer = null;
  let periodico = null;
  let rodando = false;
  let repetir = false;

  const opcoes = () => ({
    prazoHoras: config.prazo.horas,
    avisoHorasAntes: config.prazo.avisoHorasAntes,
    limiteAcumulada: config.fila.limiteAcumulada,
  });

  // A mensagem fixa do painel é só o resumo; as listas das filas ficam no comando /filas
  const payload = () => ({
    embeds: montarEmbeds(tickets.snapshot(agora()), agora(), opcoes()).slice(0, 1),
    allowedMentions: { parse: [] },
  });

  const embedsDasFilas = () => montarEmbeds(tickets.snapshot(agora()), agora(), opcoes()).slice(1);

  async function atualizarAgora() {
    const canalId = lerMeta(db, 'painel_canal');
    if (!canalId) return;

    const canal = await client.channels.fetch(canalId).catch(() => null);
    if (!canal) return;

    const msgId = lerMeta(db, 'painel_msg');
    const msg = msgId ? await canal.messages.fetch(msgId).catch(() => null) : null;

    if (msg) {
      await msg.edit(payload());
    } else {
      const nova = await canal.send(payload()); // apagaram a mensagem? recria
      gravarMeta(db, 'painel_msg', nova.id);
    }
  }

  async function executar() {
    if (rodando) {
      repetir = true;
      return;
    }
    rodando = true;
    try {
      await atualizarAgora();
    } catch (erro) {
      console.error('Erro ao atualizar o painel de filas:', erro.message);
    } finally {
      rodando = false;
      if (repetir) {
        repetir = false;
        agendar();
      }
    }
  }

  // Chamado a cada mudança: junta tudo que acontecer nos próximos instantes numa edição só
  function agendar() {
    if (timer) return;
    timer = setTimeout(() => {
      timer = null;
      executar();
    }, config.painel.debounceMs);
    if (timer.unref) timer.unref();
  }

  // /painelfilas: (re)instala o painel no canal em que o comando foi usado
  async function instalar(canal) {
    const antigoCanal = lerMeta(db, 'painel_canal');
    const antigaMsg = lerMeta(db, 'painel_msg');

    if (antigoCanal && antigaMsg && antigoCanal !== canal.id) {
      try {
        const c = await client.channels.fetch(antigoCanal);
        const m = await c.messages.fetch(antigaMsg);
        await m.delete();
      } catch {
        /* a mensagem antiga já não existe: tudo bem */
      }
    }

    gravarMeta(db, 'painel_canal', canal.id);

    let msg = null;
    if (antigoCanal === canal.id && antigaMsg) msg = await canal.messages.fetch(antigaMsg).catch(() => null);
    if (msg) await msg.edit(payload());
    else msg = await canal.send(payload());

    gravarMeta(db, 'painel_msg', msg.id);
    return msg;
  }

  function iniciar() {
    agendar();
    periodico = setInterval(agendar, config.painel.atualizacaoPeriodicaMs);
    if (periodico.unref) periodico.unref();
  }

  function parar() {
    if (timer) clearTimeout(timer);
    if (periodico) clearInterval(periodico);
    timer = periodico = null;
  }

  return { agendar, atualizarAgora, instalar, iniciar, parar, embedsDasFilas };
}

module.exports = { criarPainel, montarEmbeds, calcularAlertas, campoLista };
