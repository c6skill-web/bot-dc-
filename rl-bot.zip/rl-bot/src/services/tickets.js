'use strict';
// Regras de negócio dos tickets e das filas. NÃO conhece o Discord:
// só lê/grava no banco e avisa o resto do bot por eventos ("mudou").
// Isso deixa tudo testável e impede que duas partes do bot discordem do estado.

const EventEmitter = require('events');
const { diaNoFuso, formatarReais } = require('../util/tempo');

const STATUS_FINAIS = ['ENTREGUE', 'CANCELADO', 'FECHADO'];
// pedido pago e ainda não entregue: fechar o ticket CANCELA o pedido, então pede confirmação da equipe
const STATUS_PEDIDO_ATIVO = ['PAGO', 'NA_FILA', 'EM_PRODUCAO', 'EM_PROCESSO', 'RENDERIZANDO'];
const STATUS_EM_ANDAMENTO = ['EM_PRODUCAO', 'EM_PROCESSO', 'RENDERIZANDO'];
const STATUS_ANTES_DO_PAGAMENTO = ['ABERTO', 'AGUARDANDO_PAGAMENTO'];
const TIPOS = ['CLEAN', 'AVANCADA'];

class ErroNegocio extends Error {
  constructor(mensagem, codigo) {
    super(mensagem);
    this.name = 'ErroNegocio';
    this.codigo = codigo;
  }
}

function ehViolacaoUnica(erro) {
  return /UNIQUE constraint failed/i.test(String(erro && erro.message));
}

function criarServicoTickets(db, opcoes = {}) {
  const prazoHoras = opcoes.prazoHoras ?? 42;
  const apagarAposDias = opcoes.apagarAposDias ?? 3;
  const avisoHorasAntes = opcoes.avisoHorasAntes ?? 12;
  const exigirChaveAntesPagamento = opcoes.exigirChaveAntesPagamento === true;
  const produtos = opcoes.produtos || {};
  const fuso = opcoes.fusoHorario || 'America/Sao_Paulo';
  const agora = opcoes.agora || (() => Date.now());

  const bus = new EventEmitter();

  // ---------- leitura ----------

  const obter = (id) => db.prepare('SELECT * FROM tickets WHERE id = ?').get(id);
  const porThread = (threadId) =>
    db.prepare('SELECT * FROM tickets WHERE thread_id = ?').get(String(threadId));
  const ativoDoUsuario = (userId) =>
    db
      .prepare("SELECT * FROM tickets WHERE user_id = ? AND status NOT IN ('ENTREGUE','CANCELADO','FECHADO')")
      .get(String(userId));

  function exigir(id) {
    const t = obter(id);
    if (!t) throw new ErroNegocio('Ticket não encontrado no sistema.', 'nao_encontrado');
    return t;
  }

  function exigirAtivo(id) {
    const t = exigir(id);
    if (STATUS_FINAIS.includes(t.status)) {
      throw new ErroNegocio('Este ticket já foi encerrado (entregue ou cancelado).', 'encerrado');
    }
    return t;
  }

  // ---------- escrita (sempre dentro de transação) ----------

  function registrar(ticketId, tipo, ator, detalhe) {
    db.prepare(
      'INSERT INTO ticket_eventos (ticket_id, em, tipo, ator_id, ator_nome, detalhe) VALUES (?,?,?,?,?,?)'
    ).run(ticketId, agora(), tipo, ator?.id ?? null, ator?.nome ?? 'sistema', detalhe ?? null);
  }

  function proximoNumero(tipo) {
    const linha = db.prepare('SELECT ultimo FROM contadores WHERE tipo = ?').get(tipo);
    let n = (linha ? linha.ultimo : 0) + 1;
    const ocupado = db.prepare(
      "SELECT 1 FROM tickets WHERE tipo = ? AND fila_numero = ? AND status NOT IN ('ENTREGUE','CANCELADO','FECHADO')"
    );
    while (ocupado.get(tipo, n)) n++;
    garantirContadorMinimo(tipo, n);
    return n;
  }

  function garantirContadorMinimo(tipo, n) {
    db.prepare(
      `INSERT INTO contadores (tipo, ultimo) VALUES (?, ?)
       ON CONFLICT(tipo) DO UPDATE SET ultimo = MAX(ultimo, excluded.ultimo)`
    ).run(tipo, n);
  }

  // Coloca o ticket na fila do tipo dele (usa o número que ele já tem, se tiver)
  function colocarNaFila(ticket, ator, detalheExtra) {
    let numero = ticket.fila_numero;
    if (numero == null) numero = proximoNumero(ticket.tipo);
    else garantirContadorMinimo(ticket.tipo, numero);

    db.prepare(
      `UPDATE tickets SET status = 'NA_FILA', fila_numero = ?, na_fila_em = ?,
         producao_em = NULL, prazo_em = NULL, aviso_prazo_enviado = 0, atraso_enviado = 0
       WHERE id = ?`
    ).run(numero, agora(), ticket.id);

    registrar(
      ticket.id,
      'NA_FILA',
      ator,
      `Fila ${ticket.tipo} #${numero}${detalheExtra ? ` — ${detalheExtra}` : ''}`
    );
  }

  function emitir(ticketId, tipoEvento, ator, detalhe) {
    const ticket = obter(ticketId);
    try {
      bus.emit('mudou', { ticket, evento: tipoEvento, ator, detalhe });
    } catch (erro) {
      console.error('Erro em um ouvinte de evento do ticket:', erro);
    }
    return ticket;
  }

  // Executa `fn` em transação e depois dispara os eventos (só se deu tudo certo)
  function transacao(fn) {
    const pendentes = [];
    const resultado = db.transaction(() => fn((...args) => pendentes.push(args)))();
    let ultimo = null;
    for (const [id, tipo, ator, detalhe] of pendentes) ultimo = emitir(id, tipo, ator, detalhe);
    return { resultado, ticket: ultimo };
  }

  // ---------- operações ----------

  function criar(dados, ator) {
    const { threadId, parentId, userId, userName, categoria } = dados;
    const nomeBase = dados.nomeBase || `${userName} (${userId})`;

    try {
      const { ticket } = transacao((avisar) => {
        const info = db
          .prepare(
            `INSERT INTO tickets (thread_id, parent_id, user_id, user_name, nome_base, categoria, status, criado_em)
             VALUES (?,?,?,?,?,?, 'ABERTO', ?)`
          )
          .run(String(threadId), parentId ?? null, String(userId), userName ?? null, nomeBase, categoria, agora());
        const id = Number(info.lastInsertRowid);
        registrar(id, 'CRIADO', ator, `Categoria: ${categoria}`);
        avisar(id, 'CRIADO', ator, `Categoria: ${categoria}`);

        // "Postar com Qualidade" tem valor fixo e não entra em fila
        if (categoria === 'postar_qualidade' && produtos.postar_qualidade) {
          const p = produtos.postar_qualidade;
          db.prepare(
            "UPDATE tickets SET produto = 'postar_qualidade', preco_centavos = ?, status = 'AGUARDANDO_PAGAMENTO' WHERE id = ?"
          ).run(p.precoCentavos, id);
          registrar(id, 'PRODUTO', ator, p.label);
        }
        return id;
      });
      return ticket;
    } catch (erro) {
      if (ehViolacaoUnica(erro)) {
        throw new ErroNegocio('Você já tem um ticket aberto.', 'ja_aberto');
      }
      throw erro;
    }
  }

  // Cliente (ou suporte) escolhe o produto: define fila, valor esperado e aguarda pagamento
  function definirProduto(ticketId, chaveProduto, ator) {
    const produto = produtos[chaveProduto];
    if (!produto || !produto.tipo) {
      throw new ErroNegocio('Produto inválido.', 'produto_invalido');
    }

    const { ticket } = transacao((avisar) => {
      const t = exigirAtivo(ticketId);
      if (!STATUS_ANTES_DO_PAGAMENTO.includes(t.status)) {
        throw new ErroNegocio(
          'O pagamento deste pedido já foi confirmado. Para trocar o tipo, chame a equipe.',
          'ja_pago'
        );
      }
      db.prepare(
        "UPDATE tickets SET produto = ?, tipo = ?, preco_centavos = ?, status = 'AGUARDANDO_PAGAMENTO' WHERE id = ?"
      ).run(chaveProduto, produto.tipo, produto.precoCentavos, t.id);
      registrar(t.id, 'PRODUTO', ator, produto.label);
      avisar(t.id, 'PRODUTO', ator, produto.label);
    });
    return ticket;
  }

  // Adicional de prioridade (R$ 5): só uma marca no pedido, para a equipe puxar antes
  function definirPrioridade(ticketId, ativo, ator) {
    const { ticket } = transacao((avisar) => {
      const t = exigirAtivo(ticketId);
      const valor = ativo ? 1 : 0;
      if (t.prioridade === valor) {
        throw new ErroNegocio(ativo ? 'Este pedido já está com prioridade.' : 'Este pedido não tem prioridade.', 'sem_mudanca');
      }
      db.prepare('UPDATE tickets SET prioridade = ? WHERE id = ?').run(valor, t.id);
      const detalhe = ativo ? 'Prioridade ativada' : 'Prioridade removida';
      registrar(t.id, 'PRIORIDADE', ator, detalhe);
      avisar(t.id, 'PRIORIDADE', ator, detalhe);
    });
    return ticket;
  }

  // Fechamento do ticket (botão "Fechar Ticket").
  // - sem pedido (ou já entregue/cancelado): fecha direto;
  // - com pedido pago em andamento: só com { forcar: true } (equipe), e o pedido é CANCELADO.
  function fecharTicket(ticketId, ator, opcoesFechar = {}) {
    const { ticket } = transacao((avisar) => {
      const t = exigir(ticketId);
      if (t.fechado_em) throw new ErroNegocio('Este ticket já foi fechado.', 'ja_fechado');

      const comPedido = STATUS_PEDIDO_ATIVO.includes(t.status);
      if (comPedido && !opcoesFechar.forcar) {
        throw new ErroNegocio('Este pedido ainda está em andamento. Só a equipe pode fechar o ticket.', 'pedido_em_andamento');
      }

      const em = agora();
      let detalhe = null;
      if (STATUS_FINAIS.includes(t.status)) {
        db.prepare('UPDATE tickets SET fechado_em = ? WHERE id = ?').run(em, t.id);
      } else if (comPedido) {
        db.prepare("UPDATE tickets SET status = 'CANCELADO', cancelado_em = ?, fechado_em = ? WHERE id = ?").run(em, em, t.id);
        detalhe = 'pedido em andamento cancelado';
      } else {
        db.prepare("UPDATE tickets SET status = 'FECHADO', fechado_em = ? WHERE id = ?").run(em, t.id);
      }
      registrar(t.id, 'FECHADO', ator, detalhe);
      avisar(t.id, 'FECHADO', ator, detalhe);
    });
    return ticket;
  }

  // Tickets fechados há `apagarAposDias` dias que a equipe ainda não foi avisada para apagar
  function fechadosParaApagar(agoraMs = agora()) {
    return db
      .prepare(
        `SELECT * FROM tickets
         WHERE fechado_em IS NOT NULL AND fechado_em <= ?
           AND apagado_em IS NULL AND apagar_aviso_enviado = 0
         ORDER BY fechado_em`
      )
      .all(agoraMs - apagarAposDias * 24 * 3600 * 1000);
  }

  function marcarAvisoApagar(ticketId) {
    db.prepare('UPDATE tickets SET apagar_aviso_enviado = 1 WHERE id = ?').run(ticketId);
  }

  function marcarApagado(ticketId, ator) {
    db.prepare('UPDATE tickets SET apagado_em = ?, apagar_aviso_enviado = 1 WHERE id = ?').run(agora(), ticketId);
    registrar(ticketId, 'APAGADO', ator, 'Tópico apagado');
  }

  function marcarChaveAutorizada(ticketId, ator) {
    const t = exigirAtivo(ticketId);
    db.prepare('UPDATE tickets SET chave_autorizada_em = ?, chave_autorizada_por = ? WHERE id = ?')
      .run(agora(), ator?.id ?? null, t.id);
    registrar(t.id, 'CHAVE_ENVIADA', ator, 'Comando /chave executado por cargo autorizado');
    emitir(t.id, 'CHAVE_ENVIADA', ator, 'Comando /chave executado por cargo autorizado');
    return obter(t.id);
  }

  function comprovanteUsado({ txId, hash }) {
    if (txId) {
      const a = db.prepare('SELECT ticket_id FROM pagamentos WHERE tx_id = ?').get(txId);
      if (a) return { motivo: 'tx_id', ticketId: a.ticket_id };
    }
    if (hash) {
      const b = db.prepare('SELECT ticket_id FROM pagamentos WHERE hash_imagem = ?').get(hash);
      if (b) return { motivo: 'imagem', ticketId: b.ticket_id };
    }
    return null;
  }

  // Registra o pagamento e, se for pedido de edit com tipo definido, já coloca na fila.
  function confirmarPagamento(ticketId, dados, ator) {
    const { valorCentavos = null, txId = null, hash = null, modo = 'manual' } = dados || {};

    const { ticket, resultado } = transacao((avisar) => {
      const t = exigirAtivo(ticketId);
      if (t.pago_em) throw new ErroNegocio('O pagamento deste ticket já foi confirmado.', 'ja_pago');
      if (exigirChaveAntesPagamento && t.categoria === 'adquirir_edit' && !t.chave_autorizada_em) {
        throw new ErroNegocio('Antes de confirmar o pagamento, um membro autorizado precisa executar /chave neste ticket.', 'chave_nao_enviada');
      }

      try {
        db.prepare(
          `INSERT INTO pagamentos (ticket_id, user_id, valor_centavos, tx_id, hash_imagem, modo, confirmado_por, em)
           VALUES (?,?,?,?,?,?,?,?)`
        ).run(t.id, t.user_id, valorCentavos, txId, hash, modo, ator?.id ?? null, agora());
      } catch (erro) {
        if (ehViolacaoUnica(erro)) {
          throw new ErroNegocio('Este comprovante já foi usado em outro pedido.', 'comprovante_duplicado');
        }
        throw erro;
      }

      db.prepare('UPDATE tickets SET pago_em = ? WHERE id = ?').run(agora(), t.id);
      registrar(
        t.id,
        'PAGAMENTO',
        ator,
        `${modo === 'auto' ? 'Automático (OCR)' : 'Manual'}${valorCentavos != null ? ` — ${formatarReais(valorCentavos)}` : ''}${txId ? ` — ID ${txId}` : ''}`
      );
      avisar(t.id, 'PAGAMENTO', ator, modo);

      let entrouNaFila = false;
      if (t.categoria === 'adquirir_edit' && (STATUS_ANTES_DO_PAGAMENTO.includes(t.status) || t.status === 'PAGO')) {
        if (t.tipo) {
          colocarNaFila(t, ator);
          avisar(t.id, 'NA_FILA', ator, null);
          entrouNaFila = true;
        } else {
          db.prepare("UPDATE tickets SET status = 'PAGO' WHERE id = ?").run(t.id);
          registrar(t.id, 'PAGO_SEM_TIPO', ator, 'Pagamento confirmado; falta definir Clean/Avançada');
          avisar(t.id, 'PAGO_SEM_TIPO', ator, null);
        }
      }
      return { entrouNaFila };
    });

    return { ticket, entrouNaFila: resultado.entrouNaFila };
  }

  // Mudança de status feita pela equipe: produção/processo/renderizando/entregue/cancelado/voltar à fila
  function mudarStatus(ticketId, novoStatus, ator, detalhe) {
    const validos = [...STATUS_EM_ANDAMENTO, 'ENTREGUE', 'CANCELADO', 'NA_FILA'];
    if (!validos.includes(novoStatus)) throw new ErroNegocio('Status inválido.', 'status_invalido');

    const { ticket } = transacao((avisar) => {
      const t = exigirAtivo(ticketId);
      const agoraMs = agora();

      if (STATUS_EM_ANDAMENTO.includes(novoStatus)) {
        // O prazo de entrega começa a contar na PRIMEIRA entrada em produção
        const producaoEm = t.producao_em ?? agoraMs;
        const prazoEm = t.prazo_em ?? producaoEm + prazoHoras * 3600 * 1000;
        db.prepare(
          'UPDATE tickets SET status = ?, producao_em = ?, prazo_em = ? WHERE id = ?'
        ).run(novoStatus, producaoEm, prazoEm, t.id);
        if (!t.producao_em) {
          db.prepare(
            'UPDATE tickets SET aviso_prazo_enviado = 0, atraso_enviado = 0 WHERE id = ?'
          ).run(t.id);
        }
      } else if (novoStatus === 'ENTREGUE') {
        db.prepare("UPDATE tickets SET status = 'ENTREGUE', entregue_em = ? WHERE id = ?").run(agoraMs, t.id);
      } else if (novoStatus === 'CANCELADO') {
        db.prepare("UPDATE tickets SET status = 'CANCELADO', cancelado_em = ? WHERE id = ?").run(agoraMs, t.id);
      } else if (novoStatus === 'NA_FILA') {
        if (!t.tipo) {
          throw new ErroNegocio(
            'Este pedido ainda não tem tipo (Clean/Avançada). Use /tipo primeiro.',
            'sem_tipo'
          );
        }
        colocarNaFila(t, ator, 'voltou para a fila');
        avisar(t.id, 'NA_FILA', ator, 'voltou para a fila');
        return;
      }

      registrar(t.id, novoStatus, ator, detalhe);
      avisar(t.id, novoStatus, ator, detalhe);
    });
    return ticket;
  }

  // Classifica (PAGO -> fila) ou transfere o pedido para a outra fila
  function definirTipo(ticketId, novoTipo, ator) {
    if (!TIPOS.includes(novoTipo)) throw new ErroNegocio('Tipo inválido.', 'tipo_invalido');

    const { ticket } = transacao((avisar) => {
      const t = exigirAtivo(ticketId);
      if (t.tipo === novoTipo) {
        throw new ErroNegocio(`Este pedido já está na fila ${novoTipo}.`, 'mesmo_tipo');
      }
      if (STATUS_ANTES_DO_PAGAMENTO.includes(t.status)) {
        throw new ErroNegocio(
          'O pagamento ainda não foi confirmado neste ticket. Confirme o pagamento primeiro (botão do comprovante ou /confirmarpagamento) e depois use /tipo.',
          'sem_pagamento'
        );
      }

      const tipoAnterior = t.tipo;
      db.prepare('UPDATE tickets SET tipo = ?, fila_numero = NULL WHERE id = ?').run(novoTipo, t.id);
      const atualizado = obter(t.id);

      if (t.status === 'PAGO') {
        colocarNaFila(atualizado, ator, 'classificado pela equipe');
        avisar(t.id, 'NA_FILA', ator, null);
        return;
      }

      // pedido já na fila/produção: ganha novo número na fila nova, mantendo o status
      const numero = proximoNumero(novoTipo);
      db.prepare('UPDATE tickets SET fila_numero = ? WHERE id = ?').run(numero, t.id);
      const detalhe = `${tipoAnterior ?? 'sem tipo'} -> ${novoTipo} (#${numero})`;
      registrar(t.id, 'TRANSFERIDO', ator, detalhe);
      avisar(t.id, 'TRANSFERIDO', ator, detalhe);
    });
    return ticket;
  }

  // Compatibilidade com o /renomear fila:<n> tipo:<...> do bot antigo
  function definirNumeroManual(ticketId, { tipo, numero }, ator) {
    if (!Number.isInteger(numero) || numero < 1) throw new ErroNegocio('Número de fila inválido.', 'numero_invalido');
    if (tipo && !TIPOS.includes(tipo)) throw new ErroNegocio('Tipo inválido.', 'tipo_invalido');

    const { ticket } = transacao((avisar) => {
      const t = exigirAtivo(ticketId);
      const tipoFinal = tipo || t.tipo;

      if (tipoFinal) {
        const outro = db
          .prepare(
            "SELECT id FROM tickets WHERE tipo = ? AND fila_numero = ? AND id != ? AND status NOT IN ('ENTREGUE','CANCELADO','FECHADO')"
          )
          .get(tipoFinal, numero, t.id);
        if (outro) {
          throw new ErroNegocio(`Já existe um pedido ativo com o número ${numero} na fila ${tipoFinal}.`, 'numero_ocupado');
        }
        garantirContadorMinimo(tipoFinal, numero);
      }

      db.prepare(
        `UPDATE tickets SET tipo = ?, fila_numero = ?, status = 'NA_FILA',
           na_fila_em = COALESCE(na_fila_em, ?), producao_em = NULL, prazo_em = NULL,
           aviso_prazo_enviado = 0, atraso_enviado = 0
         WHERE id = ?`
      ).run(tipoFinal ?? null, numero, agora(), t.id);

      const detalhe = `Fila ${tipoFinal ?? ''} #${numero} (definido manualmente)`.replace('  ', ' ');
      registrar(t.id, 'NA_FILA', ator, detalhe);
      avisar(t.id, 'NA_FILA', ator, detalhe);
    });
    return ticket;
  }

  // Importação de tickets que já existiam (Rio Bot / nomes de tópico antigos)
  function criarImportado(dados, ator) {
    const {
      threadId, parentId, userId, userName, nomeBase, categoria,
      status = 'ABERTO', tipo = null, filaNumero = null, criadoEm = null,
    } = dados;

    const { ticket } = transacao((avisar) => {
      const agoraMs = agora();
      const info = db
        .prepare(
          `INSERT INTO tickets (thread_id, parent_id, user_id, user_name, nome_base, categoria, tipo, status, criado_em, importado)
           VALUES (?,?,?,?,?,?,?,?,?,1)`
        )
        .run(String(threadId), parentId ?? null, String(userId), userName ?? null, nomeBase ?? null, categoria, tipo, status, criadoEm ?? agoraMs);
      const id = Number(info.lastInsertRowid);

      if (status === 'NA_FILA') {
        let numero = filaNumero;
        if (tipo && numero != null) {
          const ocupado = db
            .prepare(
              "SELECT 1 FROM tickets WHERE tipo = ? AND fila_numero = ? AND id != ? AND status NOT IN ('ENTREGUE','CANCELADO','FECHADO')"
            )
            .get(tipo, numero, id);
          if (ocupado) numero = null;
        }
        if (tipo && numero == null) numero = proximoNumero(tipo);
        if (tipo && numero != null) garantirContadorMinimo(tipo, numero);
        db.prepare('UPDATE tickets SET fila_numero = ?, na_fila_em = ? WHERE id = ?').run(numero, agoraMs, id);
      } else if (STATUS_EM_ANDAMENTO.includes(status)) {
        // não sabemos quando entrou em produção: o prazo conta a partir da importação
        db.prepare('UPDATE tickets SET producao_em = ?, prazo_em = ?, fila_numero = ? WHERE id = ?').run(
          agoraMs, agoraMs + prazoHoras * 3600 * 1000, null, id
        );
      }

      registrar(id, 'IMPORTADO', ator, `Importado com status ${status}`);
      avisar(id, 'IMPORTADO', ator, status);
      return id;
    });
    return ticket;
  }

  // ---------- consultas para painel/alertas ----------

  function snapshot(agoraMs = agora()) {
    const ativos = db
      .prepare("SELECT * FROM tickets WHERE status NOT IN ('ENTREGUE','CANCELADO','FECHADO')")
      .all();

    const porTipo = {
      CLEAN: { pendentes: [], producao: [] },
      AVANCADA: { pendentes: [], producao: [] },
    };
    const semTipo = [];
    const pagosSemTipo = [];
    let aguardandoPagamento = 0;
    let semFila = 0;

    for (const t of ativos) {
      if (t.status === 'NA_FILA' || STATUS_EM_ANDAMENTO.includes(t.status)) {
        const grupo = t.tipo ? porTipo[t.tipo] : null;
        if (!grupo) {
          semTipo.push(t);
          continue;
        }
        if (t.status === 'NA_FILA') grupo.pendentes.push(t);
        else grupo.producao.push(t);
      } else if (t.status === 'PAGO') {
        pagosSemTipo.push(t);
      } else if (t.status === 'AGUARDANDO_PAGAMENTO' && t.categoria === 'adquirir_edit') {
        aguardandoPagamento++;
      } else {
        semFila++;
      }
    }

    for (const tipo of TIPOS) {
      porTipo[tipo].pendentes.sort((a, b) => (a.na_fila_em ?? 0) - (b.na_fila_em ?? 0) || (a.fila_numero ?? 0) - (b.fila_numero ?? 0));
      porTipo[tipo].producao.sort((a, b) => (a.prazo_em ?? Infinity) - (b.prazo_em ?? Infinity));
    }

    const hoje = diaNoFuso(agoraMs, fuso);
    const entreguesRecentes = db
      .prepare("SELECT entregue_em FROM tickets WHERE status = 'ENTREGUE' AND entregue_em >= ?")
      .all(agoraMs - 48 * 3600 * 1000);
    const entreguesHoje = entreguesRecentes.filter((r) => diaNoFuso(r.entregue_em, fuso) === hoje).length;

    const contar = (status) => db.prepare('SELECT COUNT(*) AS n FROM tickets WHERE status = ?').get(status).n;

    return {
      porTipo,
      semTipo,
      pagosSemTipo,
      aguardandoPagamento,
      conversasAbertas: semFila,
      entreguesHoje,
      entreguesTotal: contar('ENTREGUE'),
      canceladosTotal: contar('CANCELADO'),
    };
  }

  // Pedidos em produção que precisam de aviso de prazo (e ainda não receberam)
  function alertasDePrazo(agoraMs = agora()) {
    const avisoMs = avisoHorasAntes * 3600 * 1000;
    const lista = db
      .prepare(
        `SELECT * FROM tickets WHERE status IN ('EM_PRODUCAO','EM_PROCESSO','RENDERIZANDO') AND prazo_em IS NOT NULL`
      )
      .all();

    const atrasados = lista.filter((t) => agoraMs >= t.prazo_em && !t.atraso_enviado);
    const proximos = lista.filter(
      (t) => agoraMs < t.prazo_em && agoraMs >= t.prazo_em - avisoMs && !t.aviso_prazo_enviado
    );
    return { atrasados, proximos };
  }

  function marcarAlertaEnviado(ticketId, tipo) {
    if (tipo === 'atraso') {
      db.prepare('UPDATE tickets SET atraso_enviado = 1, aviso_prazo_enviado = 1 WHERE id = ?').run(ticketId);
    } else {
      db.prepare('UPDATE tickets SET aviso_prazo_enviado = 1 WHERE id = ?').run(ticketId);
    }
  }

  function historico(ticketId) {
    return db.prepare('SELECT * FROM ticket_eventos WHERE ticket_id = ? ORDER BY id').all(ticketId);
  }

  return {
    bus,
    obter,
    porThread,
    ativoDoUsuario,
    criar,
    criarImportado,
    definirProduto,
    definirPrioridade,
    fecharTicket,
    fechadosParaApagar,
    marcarAvisoApagar,
    marcarApagado,
    comprovanteUsado,
    confirmarPagamento,
    marcarChaveAutorizada,
    mudarStatus,
    definirTipo,
    definirNumeroManual,
    snapshot,
    alertasDePrazo,
    marcarAlertaEnviado,
    historico,
    // exportados para testes e para quem precisar
    constantes: { STATUS_FINAIS, STATUS_EM_ANDAMENTO, STATUS_ANTES_DO_PAGAMENTO, TIPOS },
  };
}

module.exports = { criarServicoTickets, ErroNegocio, STATUS_FINAIS, STATUS_EM_ANDAMENTO, TIPOS };
