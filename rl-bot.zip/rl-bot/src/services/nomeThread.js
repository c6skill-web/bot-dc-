'use strict';
// Renomeia os tópicos no Discord sem travar o bot.
// O Discord só deixa renomear um tópico 2x a cada 10 minutos. Então:
//  - nada aqui espera o resultado (quem chama não fica travado);
//  - se pedirem vários nomes seguidos para o mesmo tópico, só o ÚLTIMO é aplicado.
// O banco é a fonte da verdade; o nome é só o reflexo visual.

function criarRenomeador(client) {
  const estado = new Map(); // threadId -> { alvo, ativo }

  async function aplicar(threadId) {
    const item = estado.get(threadId);
    if (!item || item.ativo) return;
    item.ativo = true;
    try {
      while (item.alvo != null) {
        const nome = item.alvo;
        item.alvo = null;
        try {
          const thread = await client.channels.fetch(threadId);
          if (thread && thread.name !== nome) await thread.setName(nome);
        } catch (erro) {
          console.error(`Não consegui renomear o tópico ${threadId} para "${nome}":`, erro.message);
        }
      }
    } finally {
      item.ativo = false;
      if (item.alvo == null) estado.delete(threadId);
    }
  }

  function solicitar(threadId, nome) {
    if (!nome) return;
    const item = estado.get(threadId) || { alvo: null, ativo: false };
    item.alvo = nome;
    estado.set(threadId, item);
    aplicar(threadId); // de propósito sem await
  }

  return { solicitar };
}

module.exports = { criarRenomeador };
