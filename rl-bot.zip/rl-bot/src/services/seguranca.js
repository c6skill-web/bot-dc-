'use strict';

const { MessageFlags } = require('discord.js');

function criarSeguranca({ db, client, config, painel, ocr }) {
  const inserir = db.prepare(`INSERT INTO alertas_seguranca
    (em,tipo,usuario_id,usuario_nome,cargo_id,thread_id,ticket_id,detalhe,mensagem_id)
    VALUES (?,?,?,?,?,?,?,?,?)`);

  function membroTemCargo(member, ids) {
    return Boolean(ids.some(id => member?.roles?.cache?.has(id) || member?.roles?.includes?.(id)));
  }

  async function alertar({ tipo, user, member, channel, ticket, detalhe, messageId }) {
    const cargoMonitorado = config.cargos.chaveMonitorados.find(id => member?.roles?.cache?.has(id)) || null;
    inserir.run(Date.now(), tipo, user?.id || null, user?.tag || user?.username || 'Desconhecido', cargoMonitorado,
      channel?.id || null, ticket?.id || null, String(detalhe).slice(0, 1500), messageId || null);
    try { painel?.agendar?.(); } catch {}
    const texto = `🚨 **Alerta de segurança — RL BOT**\nTipo: **${tipo}**\nUsuário: <@${user?.id || ''}> (${user?.tag || user?.username || 'desconhecido'})\nCargo monitorado: ${cargoMonitorado ? `<@&${cargoMonitorado}>` : 'não identificado'}\nTicket: ${channel ? `<#${channel.id}>` : 'fora de ticket'}\nDetalhe: ${String(detalhe).slice(0, 700)}`;
    // Envia por DM para membros que tenham um dos cargos superiores configurados.
    const guild = client.guilds.cache.get(config.guildId);
    if (guild && config.cargos.superioresAlertas.length) {
      try {
        await guild.members.fetch();
        const destinatarios = guild.members.cache.filter(m => !m.user.bot && membroTemCargo(m, config.cargos.superioresAlertas));
        await Promise.all([...destinatarios.values()].map(m => m.send({ content: texto, allowedMentions: { users: [user?.id].filter(Boolean), roles: [] } }).catch(() => null)));
      } catch (e) { console.error('[seguranca] Falha ao enviar DM aos superiores:', e.message); }
    }
    return true;
  }

  function autorizadoChave(member) {
    // Sem exceção automática para administradores: apenas os IDs explicitamente permitidos.
    return membroTemCargo(member, config.cargos.chaveAutorizados) || membroTemCargo(member, config.cargos.chaveMonitorados);
  }

  function contemPix(texto) {
    const t = String(texto || '').toLowerCase();
    const oficial = String(config.pix.chave || '').trim().toLowerCase();
    if (oficial && t.includes(oficial)) return 'Chave Pix oficial publicada no chat';

    // Menções do Discord contêm IDs numéricos (<@123...>, <@!123...>, <@&123...>).
    // Remova a marcação antes de procurar CPF/telefone/CNPJ para não tratar IDs como Pix.
    const semMencoes = t.replace(/<@!?\d+>|<@&\d+>|<@everyone>|<@here>/gi, ' ');
    if (/\b[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b/i.test(semMencoes)) return 'Possível chave Pix aleatória';
    if (/\b[\w.+-]{2,}@[\w.-]+\.[a-z]{2,}\b/i.test(semMencoes)) return 'Possível chave Pix por e-mail';
    if (/(?:\+?55\s*)?(?:\(?\d{2}\)?\s*)?9?\d{4}[- .]?\d{4}\b/.test(semMencoes)) return 'Possível chave Pix por telefone';
    if (/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/.test(semMencoes)) return 'Possível CPF publicado no chat';
    if (/\b\d{14}\b|\b\d{2}\.?\d{3}\.?\d{3}\/ ?\d{4}-?\d{2}\b/.test(semMencoes)) return 'Possível CNPJ publicado no chat';
    if (/\b(?:pix|qr\s?code|qrcode|copia e cola|copia-e-cola|chave pix)\b/i.test(semMencoes)) return 'Mensagem menciona Pix/QR Code';
    return null;
  }

  async function verificarMensagem(message) {
    if (!message || message.author?.bot || !message.guild || !message.channel?.isThread?.()) return;
    if (config.canais.tickets && message.channel.parentId !== config.canais.tickets) return;
    const member = message.member || await message.guild.members.fetch(message.author.id).catch(() => null);
    const texto = message.content || '';
    let motivo = contemPix(texto);
    // OCR de imagens anexadas: sinaliza texto reconhecido; não afirma que decodifica QR visual sem texto.
    if (!motivo && message.attachments?.size) {
      for (const a of message.attachments.values()) {
        if (!/^image\//i.test(a.contentType || '') && !/\.(png|jpe?g|webp|bmp)$/i.test(a.name || '')) continue;
        try {
          const lido = await ocr.lerTexto(a.url);
          motivo = contemPix(lido);
          if (motivo) { motivo = `Imagem/anexo: ${motivo}`; break; }
        } catch (e) { console.warn('[seguranca] OCR não conseguiu ler anexo:', e.message); }
        // OCR não decodifica QR visual; sinaliza imagens para revisão quando não consegue classificar.
        if (!motivo) motivo = 'Imagem publicada no ticket: revisar possível QR Code/chave Pix (detecção visual automática de QR ainda limitada)';
      }
    }
    if (!motivo) return;
    const monitorado = membroTemCargo(member, config.cargos.chaveMonitorados);
    const chaveOficial = String(config.pix.chave || '').trim().toLowerCase();
    const textoLower = texto.toLowerCase();
    const contemChaveOficial = Boolean(chaveOficial && textoLower.includes(chaveOficial));
    // O cargo monitorado pode usar /chave, mas não publicar outras chaves/dados Pix manualmente.
    if (monitorado && !contemChaveOficial) {
      try { await message.delete(); } catch (e) { console.warn('[seguranca] Não foi possível apagar mensagem com possível chave:', e.message); }
    }
    const ticket = db.prepare('SELECT id FROM tickets WHERE thread_id = ?').get(message.channel.id) || null;
    await alertar({ tipo: 'POSSIVEL_CHAVE_PIX', user: message.author, member, channel: message.channel, ticket, detalhe: motivo, messageId: message.id });
  }

  async function tratarComandoChave(interaction) {
    const member = interaction.member;
    if (autorizadoChave(member)) return false;
    const monitorado = membroTemCargo(member, config.cargos.chaveMonitorados);
    const ticket = interaction.channel?.isThread?.() ? db.prepare('SELECT id FROM tickets WHERE thread_id = ?').get(interaction.channel.id) : null;
    await alertar({
      tipo: 'TENTATIVA_CHAVE_NAO_AUTORIZADA', user: interaction.user, member, channel: interaction.channel, ticket,
      detalhe: monitorado ? 'Usuário com cargo monitorado tentou usar /chave; verificar configuração.' : 'Usuário sem cargo explicitamente autorizado tentou usar /chave; comando bloqueado.'
    });
    const resposta = monitorado
      ? '🚫 O uso de /chave foi bloqueado e a tentativa foi registrada. Os superiores foram notificados.'
      : '🚫 Você não tem autorização para usar /chave. A tentativa foi registrada e os superiores foram notificados.';
    if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: resposta, flags: MessageFlags.Ephemeral });
    else await interaction.followUp({ content: resposta, flags: MessageFlags.Ephemeral }).catch(() => {});
    return true;
  }

  return { alertar, autorizadoChave, verificarMensagem, tratarComandoChave };
}

module.exports = { criarSeguranca };
