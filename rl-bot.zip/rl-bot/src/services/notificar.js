'use strict';
// Avisos para a equipe (novo pedido, atraso, comprovante repetido...).
// Vão para o canal de avisos; se não houver, para o mesmo canal do painel de filas.

const { lerMeta } = require('../db');
const { acharCargo } = require('../util/permissoes');

function criarNotificador({ client, db, config }) {
  async function canalDeAvisos() {
    const id = config.canais.avisos || lerMeta(db, 'painel_canal');
    if (!id) return null;
    return client.channels.fetch(id).catch(() => null);
  }

  // opcoes: { conteudo, embeds, pingarSuporte }
  async function avisarEquipe(opcoes) {
    try {
      const canal = await canalDeAvisos();
      if (!canal || !canal.send) return false;

      const guild = canal.guild || client.guilds.cache.get(config.guildId);
      const cargo = opcoes.pingarSuporte ? acharCargo(guild, config.cargos.suporte) : null;

      await canal.send({
        content: [cargo ? `<@&${cargo.id}>` : null, opcoes.conteudo].filter(Boolean).join(' '),
        embeds: opcoes.embeds || [],
        components: opcoes.components || [],
        allowedMentions: cargo ? { roles: [cargo.id] } : { parse: [] },
      });
      return true;
    } catch (erro) {
      console.error('Erro ao avisar a equipe:', erro.message);
      return false;
    }
  }

  return { avisarEquipe };
}

module.exports = { criarNotificador };
