'use strict';
// Textos e mensagens prontas do atendimento (mesmos do bot antigo).
// Para mudar um texto, é só editar aqui.

const fs = require('fs');
const path = require('path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, AttachmentBuilder } = require('discord.js');
const config = require('./config');
const { formatarReais } = require('./util/tempo');

// ---------- categorias do painel de abertura de ticket ----------

const CATEGORIAS_TICKET = [
  {
    value: 'adquirir_edit',
    emoji: '🧩',
    label: 'Adquirir Edit',
    descricao: 'Abrir ticket para adquirir edit',
    resposta: 'Pra adquirir sua edit, clique no botão abaixo pra abrir o atendimento.',
    boasVindas:
      'Olá {{userMention}}, seja bem-vindo(a) ao atendimento! Me conta qual edit você quer (Clean ou Avançada) e qualquer referência que você tenha.',
  },
  {
    value: 'duvidas',
    emoji: '🤔',
    label: 'Tirar Dúvidas Gerais',
    descricao: 'Abrir ticket para tirar dúvidas',
    resposta: 'Pra tirar sua dúvida, clique no botão abaixo pra abrir o atendimento.',
    boasVindas: 'Olá {{userMention}}, pode mandar sua dúvida que um {{supportRole}} já te responde!',
  },
  {
    value: 'evento',
    emoji: '🎁',
    label: 'Resgatar Evento',
    descricao: 'Abra um ticket para resgatar evento',
    resposta: 'Pra resgatar o evento, clique no botão abaixo pra abrir o atendimento.',
    boasVindas: 'Olá {{userMention}}, me conta qual evento você quer resgatar!',
  },
  {
    value: 'postar_qualidade',
    emoji: '✨',
    label: 'Postar com Qualidade',
    descricao: 'Abrir ticket para Postar com Qualidade',
    resposta: 'Pra postar com qualidade máxima, clique no botão abaixo pra abrir o atendimento.',
    boasVindas: 'Olá {{userMention}}, essa é a postagem em máxima qualidade (R$ 3,00 adicional). Envie o comprovante quando pagar!',
  },
  {
    value: 'parcerias',
    emoji: '🤝',
    label: 'Parcerias',
    descricao: 'Abra um ticket para Parcerias',
    resposta: 'Pra propor uma parceria, clique no botão abaixo pra abrir o atendimento.',
    boasVindas: 'Olá {{userMention}}, me conta sobre a sua proposta de parceria!',
  },
];

const acharCategoria = (value) => CATEGORIAS_TICKET.find((c) => c.value === value);

function painelAberturaEmbed() {
  const embed = new EmbedBuilder()
    .setColor('#2B2D31')
    .setTitle("CENTRAL DE TICKETS • RL EDIT'S")
    .setDescription(
      'Bem-vindo à central de atendimento da RL Edit’s!\nEscolha uma categoria no menu logo abaixo para falar com nossa equipe.\n\n⚠️ Abra tickets somente quando necessário.'
    )
    .addFields(
      { name: '🧩 Adquirir Edit', value: 'Compre sua edit', inline: true },
      { name: '🤔 Dúvidas Gerais', value: 'Tire suas dúvidas', inline: true },
      { name: '🎁 Resgatar Evento', value: 'Resgate recompensas', inline: true },
      { name: '✨ Postar com Qualidade', value: 'Solicite postagem', inline: true },
      { name: '🤝 Parcerias', value: 'Envie sua proposta', inline: true },
    )
    .setThumbnail('attachment://logo-rl.png')
    .setImage('attachment://central-tickets.png')
    .setFooter({ text: "RL EDIT'S • Selecione uma categoria para começar" });
  return embed;
}

function painelAberturaRow() {
  const menu = new StringSelectMenuBuilder()
    .setCustomId('painel_categoria')
    .setPlaceholder('Selecione uma opção...')
    .addOptions(
      CATEGORIAS_TICKET.map((c) => ({ label: c.label, description: c.descricao, value: c.value, emoji: c.emoji }))
    );
  return new ActionRowBuilder().addComponents(menu);
}

// Menu que aparece dentro do ticket "Adquirir Edit" para o cliente escolher o produto
function menuProdutoRow() {
  const opcoes = Object.entries(config.produtos)
    .filter(([, p]) => p.tipo)
    .map(([chave, p]) => ({
      label: `${p.label} — ${formatarReais(p.precoCentavos)}`,
      value: chave,
      emoji: p.tipo === 'CLEAN' ? '🧼' : '🚀',
    }));

  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('produto_select')
      .setPlaceholder('Escolha sua edit...')
      .addOptions(opcoes)
  );
}

// ---------- mensagens prontas ----------

// Caminho absoluto: funciona não importa de qual pasta o bot foi iniciado
const CAMINHO_QR = path.join(config.raiz, 'assets', 'qrcode-pix.png');
const qrDisponivel = () => fs.existsSync(CAMINHO_QR);
const anexoQrCode = () => (qrDisponivel() ? new AttachmentBuilder(CAMINHO_QR, { name: 'qrcode-pix.png' }) : null);

function embedChave(produto) {
  const linhas = [
    '**Aqui está nossa chave:**',
    `\`${config.pix.chave}\``,
    `Nome: ${config.pix.nome}`,
    '',
  ];
  if (produto) {
    linhas.push(`**Valor a pagar: ${formatarReais(produto.precoCentavos)}** (${produto.label})`, '');
  }
  linhas.push(
    '**Ao efetuar o pagamento, envie o comprovante aqui mesmo!**',
    '',
    produto
      ? 'Escaneie o QR Code do Pix abaixo e digite o valor acima na hora de pagar:'
      : 'Escaneie o QR Code do Pix abaixo (o valor você digita na hora de pagar):'
  );

  const embed = new EmbedBuilder().setColor('#0E1C40').setTitle('🔑 Chave Pix').setDescription(linhas.join('\n'));
  if (qrDisponivel()) embed.setImage('attachment://qrcode-pix.png');
  return embed;
}

function botaoCopiarChave() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('copiar_chave').setLabel('Copiar chave').setEmoji('📋').setStyle(ButtonStyle.Secondary)
  );
}

function embedEntregue() {
  return new EmbedBuilder()
    .setColor(0x27ae60)
    .setTitle('✅ Entregue!')
    .setDescription(
      [
        '**Entregue!** ao fazer o download, verifique a **qualidade!**',
        '',
        '**Parabéns pela sua compra! esperamos te ver em breve!** 🟢',
        '',
        'E não se **esqueça** de fazer suas https://discord.com/channels/1539980708427210803/1541310975435743243! para garantir **benefícios** futuros.',
        '',
        '📢 **ATENÇÃO!!!** O vídeo no drive ficará **disponível** por apenas 3 **dias** 🔴',
      ].join('\n')
    );
}

function embedPostar() {
  return new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle('⭐ Quer garantir que sua edit não perderá a qualidade?')
    .setDescription(
      [
        'Além da sua edit, oferecemos a postagem em **MÁXIMA QUALIDADE** no valor',
        'adicional de **R$ 3,00 reais** ✨',
      ].join('\n')
    );
}

function embedValores() {
  const glowDot = '<:591110glowingdotblue:1541300400219623455>';
  const voiceClip = '<:54627voiceclip:1541306813352382506>';
  const setaVerde = '<:arrowgreen:1541335746453970975>';

  return new EmbedBuilder()
    .setColor(7733097)
    .setTitle(`${glowDot}   ***VALORES***  --- ${voiceClip}`)
    .setDescription(
      [
        '**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**',
        '',
        `${setaVerde}  EDIT **CLEAN** DE **30s**: **R$10,00**`,
        '',
        `${setaVerde} EDIT **CLEAN** DE **1min**: **R$ 15,00**`,
        '',
        '--------------------------------------------',
        '',
        `${setaVerde}  EDIT **AVANÇADA** DE **30s**: **R$ 15,00**`,
        '',
        `${setaVerde}  EDIT **AVANÇADA** DE **1min**: **R$ 20,00**`,
        '',
        '**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**',
      ].join('\n')
    )
    .setFooter({ text: 'Equipe RL' });
}

module.exports = {
  CATEGORIAS_TICKET,
  acharCategoria,
  painelAberturaEmbed,
  painelAberturaRow,
  menuProdutoRow,
  embedChave,
  anexoQrCode,
  botaoCopiarChave,
  embedEntregue,
  embedPostar,
  embedValores,
};
