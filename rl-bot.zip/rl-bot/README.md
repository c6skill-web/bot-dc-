# RL Bot v2 — tickets, filas e painel automático

Reformulação do bot de tickets: o ticket agora existe num **banco de dados** (SQLite), com
**filas de Clean e Avançada**, **painel de monitoramento** que se atualiza sozinho, **prazo de 42h**,
**leitura automática do comprovante** (a equipe confirma com um clique) e **histórico** de cada pedido.

## Instalar e ligar

1. Instale o **Node.js 22 (LTS)** — https://nodejs.org
2. Copie `.env.example` para `.env` e preencha os dados do Discord e do Pix. Para habilitar o painel web, defina também `ADMIN_PASSWORD` com uma senha forte.
3. Dê dois cliques em `iniciar-bot.cmd` (ele roda `npm install` e liga o bot).
4. O banco usa o SQLite que já vem dentro do Node (precisa de **Node 22.13 ou mais novo**), então não há nada nativo para compilar.
   Um aviso amarelo "SQLite is an experimental feature" ao ligar é normal e pode ser ignorado.
5. Com `ADMIN_PASSWORD` definido, abra `http://127.0.0.1:3210/admin` no computador em que o bot está rodando.

> ⚠️ **Token:** o `.env` do bot antigo foi enviado em um arquivo compartilhado. Gere um token novo no
> Discord Developer Portal (Bot → Reset Token) e use o novo no `.env`.


## Painel web administrativo

O painel web usa o mesmo processo do bot e lê os dados reais do banco SQLite já existente. Não requer framework nem dependências adicionais.

1. Copie `.env.example` para `.env` e defina `ADMIN_PASSWORD` com uma senha longa e exclusiva. Sem essa variável, o servidor web não inicia.
2. Inicie o bot normalmente e abra `http://127.0.0.1:3210/admin` no navegador do mesmo computador.
3. Para acesso pelo Tailscale, defina `ADMIN_HOST=100.100.219.62` (ou o IP Tailscale deste computador) e `ADMIN_PORT=3210` no `.env`, salve e reinicie o bot. Se esse IP não pertencer ao computador que executa o bot, use o IP Tailscale correto mostrado pelo comando `tailscale ip -4`. No computador que hospeda o bot, descubra o IPv4 com `ipconfig`; no PC do sócio, abra `http://IP-DO-PC-DO-BOT:3210/admin` e entre com a senha administrativa. Ambos precisam estar na mesma rede Wi-Fi/LAN. Se o Windows Firewall perguntar, permita Node.js apenas em redes privadas; se necessário, crie uma regra de entrada TCP para a porta 3210 restrita ao perfil Privado.
4. O painel exibe o status do bot, contagens, tickets, pagamentos registrados e histórico de eventos. Os dados atualizam a cada 30 segundos.

**Segurança:** isso é para rede local confiável. Não faça port forwarding nem exponha a porta 3210 diretamente à internet. Para seu sócio acessar de outra rede, prefira uma VPN privada como Tailscale e mantenha o painel protegido por senha. Não compartilhe o `.env`; ele contém o token do Discord e credenciais privadas.

**Escopo atual:** o painel é de consulta. Ações que alterem tickets, filas ou pagamentos ainda devem ser conectadas aos serviços existentes e testadas individualmente antes de serem habilitadas.

## Permissões do bot (importante)

No cargo do bot, ligue: **Gerenciar Cargos** (dar o cargo cliente; o cargo do bot precisa estar *acima* do `・client`), **Gerenciar Tópicos** (trancar, arquivar e apagar tickets)
e **Adicionar Reações** (o 🔎 enquanto lê o comprovante). **Gerenciar Tópicos** também faz o bot enxergar os tópicos privados criados pelo Rio Bot;
sem ele o Discord só entrega ao bot as mensagens dos tópicos de que ele participa, e os comprovantes dos tickets do Rio Bot não chegam.
Os comandos aparecem só para administradores por padrão: em Configurações do servidor → Integrações → RL Bot, libere os comandos para o `・suporte`.

## Colocando em funcionamento (com o Rio Bot ainda ativo)

1. Ligue o bot novo e, no canal **só da equipe** onde quer o painel, use **`/painelfilas`**.
   O bot avisa se o canal estiver visível para `@everyone` — ajuste as permissões do canal para só o `・suporte` ver.
2. Use **`/importar`**: traz para o sistema os tickets que já estão abertos no canal de tickets
   (lê o nome do tópico: `🎥 (FILA 2 - CLEAN) nome (id)`, `(EM PRODUÇÃO)`, etc.).
   Pedidos importados "em produção" têm as 42h contadas **a partir da importação** (o bot não tem como saber quando entraram).
3. Se tiver o `dados-edits.json` do bot antigo, coloque-o na pasta do projeto (ou em `data/`):
   a contagem de edits é migrada sozinha na primeira vez.
4. Enquanto os dois bots estiverem ligados, **use só um painel de abertura de ticket por vez** (`/painel` no bot novo)
   para não ter dois bots disputando o mesmo ticket. Quando o novo estiver validado, desligue o Rio Bot.

## Como funciona o pedido (versão para testes)

O ticket abre **como no Rio Bot**: o cliente escolhe a categoria, abre o ticket e conversa normalmente (sem menu de produto).
O pagamento é **confirmado pela equipe com um clique**, e o bot ajuda lendo o comprovante.

| Etapa | O que acontece |
|---|---|
| Cliente abre ticket em **Adquirir Edit** | Mensagem de boas-vindas de sempre. A equipe passa a chave com `/chave` |
| Cliente envia o comprovante | O bot responde com um **resumo do que leu** (valor, data, ID da transação, destinatário) e avisa de problemas: data antiga, destinatário diferente, ID ilegível. Comprovante **repetido** (mesmo ID ou mesma imagem) é bloqueado e a equipe é avisada |
| Equipe clica na opção do pedido | O bot mostra só os pedidos que **somam o valor lido** (tabela abaixo). Um clique confirma o pagamento, dá o cargo, define Clean/Avançada, coloca na fila com número e renomeia o tópico |
| Equipe usa `/renomear producao:true` | Status **Em produção**: **aqui começam as 42h** |
| `/renomear processo:true` / `renderizando:true` | Troca o sub-status sem reiniciar o prazo |
| `/entregue` | Entregue (mensagem de sempre; sai das filas) |

| Valor lido | Botões que aparecem |
|---|---|
| R$ 10 | Clean 30s |
| R$ 15 | Clean 1min · Avançada 30s · Clean 30s + prioridade |
| R$ 20 | Avançada 1min · Clean 1min + prioridade · Avançada 30s + prioridade |
| R$ 25 | Avançada 1min + prioridade |
| outro | só "Confirmar e dar cargo cliente" (com aviso); depois use `/tipo` |

Sempre existe também o botão **"Confirmar sem definir a fila"** (o pedido fica como "pago, sem tipo" até a equipe usar `/tipo`).
Só quem tem o cargo `・suporte` consegue clicar nos botões.

**Adicional de R$ 5 (prioridade):** por enquanto é só uma **marca ⚡** no pedido (aparece no painel e nos avisos) para a equipe puxar antes.
Ele **não muda a numeração nem a ordem** da fila. Se o cliente pagar o R$ 5 separado ou depois, use `/prioridade` no ticket
(`/prioridade ativar:false` remove). Se quiser que a prioridade passe na frente automaticamente, é uma mudança pequena: avise.

A numeração é por fila (Clean #1, #2… / Avançada #1, #2…), na ordem de confirmação do pagamento, e não reinicia sozinha.

### Fechar ticket e apagar depois de 3 dias

Todo ticket novo vem com a mensagem **"Caso sua questão já tenha sido resolvida, clique no botão abaixo para fechar o ticket"** e o botão vermelho **Fechar Ticket**
(sem comando). Quem pode clicar: o dono do ticket e a equipe.

- **Fechar = fechar totalmente:** o ticket é encerrado no sistema e o tópico é **trancado e arquivado** (ninguém escreve mais).
- **Pedido em andamento** (pago e ainda na fila/produção): o cliente **não consegue** fechar; só a equipe, e o bot pede uma confirmação extra porque fechar **cancela o pedido**.
- **Depois de 3 dias** (`APAGAR_APOS_DIAS` no `.env`), o bot avisa no canal da equipe, **marcando o `・suporte`**, com os botões **Apagar ticket** e **Manter**.
  O tópico **só é apagado se alguém da equipe clicar em Apagar** (a confirmação é sempre manual). Cada ticket gera esse aviso uma vez só.
- O bot precisa da permissão **Gerenciar Tópicos** (para trancar, arquivar e apagar tópicos privados).
- Tickets criados pelo Rio Bot não têm o botão do bot novo (só os tickets abertos pelo bot novo).

### Painel (canal da equipe)
O painel fixo (`/painelfilas`) mostra o **resumo**: pendentes e em produção por fila, entregues hoje/total, cancelados, pagamentos aguardando, e **alertas** (atrasados 🔴, prazo < 12h 🟡, fila acumulada 📈).
Atualiza a cada mudança (juntando várias mudanças seguidas) e a cada 1 min.

### Avisos para a equipe (mesmo canal do painel, ou `CANAL_AVISOS_ID`)
Novo pedido na fila, pedido transferido/cancelado, comprovante repetido,
pago sem tipo, prazo chegando, atraso e fila acumulada (cada aviso de prazo é enviado **uma única vez**).

## Comandos (todos só para `・suporte`)

Antigos (continuam iguais): `/chave` `/entregue` `/postar` `/valores` `/painel` `/confirmarpagamento` `/renomear`
Novos: `/painelfilas` (resumo fixo) `/filas` (listas das filas Clean e Avançada, com número, cliente, tempo de espera e **tempo restante do prazo**; só você vê) `/importar` `/tipo` (define/troca Clean↔Avançada) `/prioridade` `/cancelar` `/historico`

`/renomear fila:N tipo:...` continua existindo para acertos manuais de número.

## Pagamento — leia isto

**Padrão: manual.** O bot nunca confirma sozinho, a equipe sempre clica. A ajuda do bot é ler o comprovante e barrar fraudes comuns:

1. **responde a qualquer imagem que pareça comprovante** (como o bot antigo) e só ignora o que nem parece (print de edit, meme). Se não conseguir ler a imagem, avisa na hora em vez de ficar mudo;
2. mostra o **valor, a data, o ID e o destinatário** lidos (✅ é para a RL / 🟡 só reconheci o banco / ⚠️ não reconheci) e quais pedidos batem com o valor. Tolera nome mascarado, pequenos erros de leitura e comprovantes que mostram "R$ 10" sem centavos;
3. **ID da transação repetido ou mesma imagem** (hash) já usada em outro pedido: bloqueia e avisa a equipe;
4. **data anterior à abertura do ticket**: avisa que pode ser comprovante antigo reaproveitado;
5. só o **dono do ticket** dispara a leitura, e só enquanto o pagamento não foi confirmado.

O botão do pedido ainda confere que a opção clicada **soma exatamente o valor lido** no print.

**Confirmação automática (opcional):** com `PAGAMENTO_MODO=auto` e `MENU_PRODUTO=sim` o cliente escolhe o produto no ticket
e o bot confirma sozinho quando todas as travas passam (valor = produto, ID único, data válida). Fica desligado por padrão.

**Limite que não dá para eliminar com OCR:** o bot lê a *imagem*, não o *dinheiro*. Um print adulterado
com valor, ID novo e data certos passaria. Se isso virar um risco real, use `PAGAMENTO_MODO=manual`
(a equipe confere cada um) ou migre para a verificação real abaixo.

**Verificação real (opção que fica para depois):** gerar uma cobrança Pix por ticket por um provedor
(Mercado Pago, Efí, Asaas, etc.) e receber o aviso de "pago" por webhook. Aí o bot confirma pelo dinheiro,
sem depender de imagem. Exige conta no provedor (podem existir taxas por transação — confira com ele) e um endereço
público para o webhook. O ponto de encaixe já existe: `tickets.confirmarPagamento(ticketId, { modo: 'api', txId })`.

## Configurações (src/config.js e .env)

- Preços/produtos: `config.produtos` (o texto do `/valores` fica em `src/conteudo.js` — mantenha os dois iguais).
- Prazo: 42h; aviso antes: 12h (`config.prazo`).
- `APAGAR_APOS_DIAS` — dias até o bot pedir confirmação para apagar um ticket fechado (padrão: 3).
- `PAGAMENTO_MODO` — `manual` (padrão) ou `auto`. `MENU_PRODUTO` — `sim` mostra o menu de produtos no ticket (padrão: não).
- Adicional de prioridade (R$ 5): `config.adicionais.prioridade`.
- `LIMITE_FILA_ACUMULADA` — avisa quando uma fila tiver X pendentes (`0` = desligado; defina o número que fizer sentido).
- `CARGO_SUPORTE_ID` / `CARGO_CLIENT_ID` — opcionais; sem eles o bot procura pelo nome (`・suporte`, `・client`).

## Estrutura

```
src/
  index.js               liga tudo
  config.js              preços, prazo, cargos, modo de pagamento
  db.js                  banco SQLite + migrações
  conteudo.js            textos/embeds (painel de abertura, chave, entregue...)
  services/              regras (sem Discord): tickets, painel, alertas, comprovante, ocr, importar...
  discord/               comandos, botões, mensagens, pagamentos
test/                    npm test
data/bot.sqlite          o banco (faça backup deste arquivo!)
```

## O que mudou em relação ao bot antigo

- Estado do pedido no **banco**, não no nome do tópico (o nome é só reflexo; renomeações são agrupadas para respeitar o limite do Discord).
- Banco SQLite embutido no Node (nada para instalar/compilar), cargos por ID (opcional), comprovante com OCR numa fila (1 por vez), contagem de edits sem risco de corromper arquivo.
- Ao ligar, o bot prepara o leitor de comprovantes (OCR). Na **primeira vez** ele baixa o idioma português, o que pode levar um tempo; a mensagem "Leitor de comprovantes (OCR) pronto" no terminal indica que já pode testar. É preciso internet no PC.
- O bot só cancela um pedido por "tópico apagado" quando tem certeza (precisa de Gerenciar Tópicos); na dúvida, mantém o pedido.
- Mantido: painel de categorias, tabela de valores, mensagens, `/chave` `/entregue` `/postar` `/valores`, cargos de nível, OCR do comprovante.
- Corrigido: o QR do `/chave` agora usa caminho absoluto (`assets/qrcode-pix.png`), funciona de qualquer pasta.
- Novo: "Postar com Qualidade" tem valor fixo de R$ 3 (confirma o pagamento, mas não entra em fila).


## Proteção de /chave e alertas de segurança

- `CARGOS_CHAVE_AUTORIZADOS`: allowlist estrita de cargos que podem usar `/chave`; administradores e outros cargos não têm bypass.
- `CARGOS_CHAVE_MONITORADOS`: cargos cujas tentativas não autorizadas são destacadas nos alertas.
- `CARGOS_SUPERIORES_ALERTAS`: cargos que recebem alertas por DM.
- Os alertas persistem em `alertas_seguranca` e aparecem na seção **Segurança** do painel.
- Mensagens em tickets são verificadas para a chave Pix configurada em `PIX_CHAVE`, padrões de e-mail/telefone/CPF/CNPJ e anexos de imagem. Anexos de imagem são sinalizados para revisão porque OCR de texto não é um decodificador completo de QR Code.
- Em pedidos `adquirir_edit`, o pagamento não pode ser confirmado pelo fluxo normal até que um membro autorizado execute `/chave` no ticket. Isso registra o responsável e a hora no histórico.
- As DMs dependem de o bot conseguir consultar os membros do servidor e de o destinatário permitir mensagens diretas; falhas de DM não apagam o alerta do painel.


**Discord Developer Portal:** para os alertas por DM encontrarem todos os membros dos cargos superiores, habilite o intent privilegiado **Server Members Intent** (Guild Members) na página do bot. O intent Message Content também deve continuar habilitado para detectar texto nos tickets.
