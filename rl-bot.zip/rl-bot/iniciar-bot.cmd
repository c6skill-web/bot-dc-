@echo off
title RL Bot
cd /d "%~dp0"

echo ==========================================
echo   Iniciando o RL Bot...
echo ==========================================
echo.

call npm install

rem Se a instalacao ficou pela metade (acontece), apaga a pasta e instala de novo do zero
node -e "require('discord.js'); require('dotenv'); require('tesseract.js')" >nul 2>&1
if errorlevel 1 (
  echo.
  echo Instalacao incompleta. Refazendo do zero, aguarde...
  if exist node_modules rmdir /s /q node_modules
  call npm install
)

echo.
echo ==========================================
echo   Ligando o bot...
echo ==========================================
echo.

call npm start

echo.
echo ==========================================
echo   O bot parou. Se foi um erro, olhe a
echo   mensagem acima pra entender o motivo.
echo ==========================================
pause
