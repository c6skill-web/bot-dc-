'use strict';
// Discord simulado (mensagens, tópicos, cargos) compartilhado pelos testes de fluxo.
const { Collection } = require('discord.js');
const { novoBanco } = require('./banco');
const config = require('../../src/config');
const { criarServicoTickets } = require('../../src/services/tickets');
const { ligarReacoes } = require('../../src/discord/eventos');

config.canais.tickets = 'CANAL_TICKETS';
config.pix = { chave: '11111111-2222-3333-4444-555555555555', nome: 'Arthur Vieira' };

const hoje = new Intl.DateTimeFormat('en-CA', { timeZone: config.fusoHorario }).format(new Date()).split('-').reverse().join('/');
let contadorId = 0;
const comprovante = (valor = '10,00', id) =>
  `Comprovante de transferência\n${hoje} 10:30:00\nValor R$ ${valor}\nDestino Arthur Vieira\nID da transação ${id || 'E18236120' + '2026' + String(++contadorId).padStart(8, '0') + 'aB3dE5fGh12'}`;

function montar({ textoOcr }) {
  const db = novoBanco();
  const tickets = criarServicoTickets(db, { produtos: config.produtos });
  const enviadas = [];     // mensagens enviadas ao canal de avisos
  const renomeados = [];
  const cargos = new Collection([['R1', { id: 'R1', name: config.cargos.cliente.nome }], ['R2', { id: 'R2', name: config.cargos.suporte.nome }]]);
  const rolesDoMembro = new Collection();
  const membro = { id: 'U1', roles: { cache: rolesDoMembro, add: async (r) => rolesDoMembro.set(r.id, r) }, user: { tag: 'u#1' } };
  const guild = {
    roles: { cache: cargos },
    members: { fetch: async () => membro },
  };
  const canalAvisos = { send: async (m) => enviadas.push(m), guild };
  const client = {
    channels: { fetch: async (id) => (id === 'AVISOS' ? canalAvisos : { id, name: 'x', setName: async (n) => renomeados.push(n) }) },
    guilds: { cache: new Collection() },
  };
  const painel = { agendar: () => {} };
  const ctx = {
    client, config, db, tickets, painel, analises: new Map(),
    notificar: { avisarEquipe: async (o) => enviadas.push(o) },
    renomeador: { solicitar: (id, nome) => renomeados.push(nome) },
    ocr: { lerTexto: async () => (typeof textoOcr === 'function' ? textoOcr() : textoOcr) },
  };
  ligarReacoes(ctx);
  return { ctx, db, tickets, enviadas, renomeados, membro, guild };
}

function mensagem({ guild, autor = 'U1', imagem = Buffer.from('img-' + Math.random()) }) {
  const respostas = [];
  global.fetch = async () => ({ ok: true, arrayBuffer: async () => imagem });
  return {
    respostas,
    msg: {
      author: { id: autor, bot: false },
      channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' },
      guild,
      id: 'M' + Math.random(),
      attachments: new Collection([['a', { contentType: 'image/png', size: 1000, url: 'http://x/y.png' }]]),
      reply: async (c) => { respostas.push(c); return { id: 'R' + respostas.length }; },
    },
  };
}


module.exports = { montar, mensagem, comprovante };
