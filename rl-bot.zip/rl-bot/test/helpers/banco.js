'use strict';
// Banco em memória para os testes (mesmo adaptador que o bot usa em produção).
const { criarBanco } = require('../../src/db');

const novoBanco = () => criarBanco(':memory:');
module.exports = { novoBanco };
