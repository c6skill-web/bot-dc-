'use strict';
// Botão "Fechar Ticket", apagar depois de 3 dias (com confirmação e ping no suporte), /filas e painel enxuto.
const test = require('node:test');
const assert = require('node:assert/strict');
const { Collection } = require('discord.js');
const config = require('../src/config');
const { novoBanco } = require('./helpers/banco');
const { montar } = require('./helpers/discord');
const { criarServicoTickets } = require('../src/services/tickets');
const { criarAlertas } = require('../src/services/alertas');
const { criarPainel } = require('../src/services/painel');
const { criarRoteador } = require('../src/discord/interacoes');
const { handlers } = require('../src/discord/comandos');

const ator = { id: 's', nome: 's' };
const DIA = 24 * 3600 * 1000;

// ---------- regras (serviço) ----------

function servico() {
  const db = novoBanco();
  const rel = { t: new Date('2026-10-10T12:00:00-03:00').getTime() };
  const tk = criarServicoTickets(db, { produtos: config.produtos, agora: () => rel.t });
  let n = 0;
  const novo = (uid) => tk.criar({ threadId: `t${++n}`, parentId: 'p', userId: uid, userName: 'u', categoria: 'adquirir_edit' }, ator);
  const comPedido = (uid, produto = 'clean_30') => {
    const t = novo(uid);
    tk.definirProduto(t.id, produto, ator);
    tk.confirmarPagamento(t.id, { txId: `TX${uid}`, modo: 'manual' }, ator);
    return t;
  };
  return { db, tk, rel, novo, comPedido };
}

test('fechar ticket sem pedido: vira FECHADO e a pessoa pode abrir outro', () => {
  const { tk, novo } = servico();
  const t = novo('1');
  const f = tk.fecharTicket(t.id, ator);
  assert.equal(f.status, 'FECHADO');
  assert.ok(f.fechado_em);
  assert.doesNotThrow(() => novo('1'));
  assert.throws(() => tk.fecharTicket(t.id, ator), (e) => e.codigo === 'ja_fechado');
  assert.throws(() => tk.mudarStatus(t.id, 'EM_PRODUCAO', ator), (e) => e.codigo === 'encerrado');
});

test('fechar com pedido em andamento: bloqueia; só com confirmação da equipe e cancela o pedido', () => {
  const { tk, comPedido, rel } = servico();
  const t = comPedido('1');
  assert.equal(tk.obter(t.id).status, 'NA_FILA');
  assert.throws(() => tk.fecharTicket(t.id, ator), (e) => e.codigo === 'pedido_em_andamento');
  assert.equal(tk.obter(t.id).status, 'NA_FILA', 'nada mudou');

  const f = tk.fecharTicket(t.id, ator, { forcar: true });
  assert.equal(f.status, 'CANCELADO');
  assert.ok(f.fechado_em);
  assert.equal(tk.snapshot(rel.t).porTipo.CLEAN.pendentes.length, 0, 'saiu da fila');
});

test('ticket entregue fechado continua ENTREGUE (só marca o fechamento)', () => {
  const { tk, comPedido } = servico();
  const t = comPedido('1');
  tk.mudarStatus(t.id, 'ENTREGUE', ator);
  const f = tk.fecharTicket(t.id, ator);
  assert.equal(f.status, 'ENTREGUE');
  assert.ok(f.fechado_em);
});

test('fechado não aparece em "outros tickets abertos" nem no total de cancelados', () => {
  const { tk, novo, rel } = servico();
  const a = novo('1'); novo('2');
  assert.equal(tk.snapshot(rel.t).conversasAbertas, 2);
  tk.fecharTicket(a.id, ator);
  const s = tk.snapshot(rel.t);
  assert.equal(s.conversasAbertas, 1);
  assert.equal(s.canceladosTotal, 0);
});

test('apagar: só depois de 3 dias, uma vez, e some da lista quando apagado', () => {
  const { tk, novo, rel } = servico();
  const t = novo('1');
  tk.fecharTicket(t.id, ator);
  assert.equal(tk.fechadosParaApagar().length, 0);
  rel.t += 2 * DIA + 23 * 3600_000;
  assert.equal(tk.fechadosParaApagar().length, 0);
  rel.t += 2 * 3600_000;
  assert.equal(tk.fechadosParaApagar().length, 1);
  tk.marcarAvisoApagar(t.id);
  assert.equal(tk.fechadosParaApagar().length, 0);
  tk.marcarApagado(t.id, ator);
  assert.ok(tk.obter(t.id).apagado_em);
  assert.ok(tk.historico(t.id).some((e) => e.tipo === 'APAGADO'));
});

test('aviso de apagar: marca o suporte, tem os botões Apagar/Manter e não repete', async () => {
  const { db, tk, novo, rel } = servico();
  const t = novo('1');
  tk.fecharTicket(t.id, ator);
  rel.t += 3 * DIA + 1000;

  const avisos = [];
  const alertas = criarAlertas({
    tickets: tk, db, config, agora: () => rel.t, painel: { agendar() {} },
    notificar: { avisarEquipe: async (o) => { avisos.push(o); return true; } },
  });
  await alertas.verificar();
  const aviso = avisos.find((a) => /fechado há 3 dias/.test(a.conteudo));
  assert.ok(aviso, 'avisou a equipe');
  assert.equal(aviso.pingarSuporte, true);
  assert.deepEqual(aviso.components[0].toJSON().components.map((c) => c.custom_id), [`apagar_ticket_${t.id}`, `manter_ticket_${t.id}`]);

  await alertas.verificar();
  assert.equal(avisos.filter((a) => /fechado há 3 dias/.test(a.conteudo)).length, 1, 'não repete');
});

// ---------- Discord (botões) ----------

function ticketNoCanal(e, { userId = 'U1', thread = 'T1', pago = false } = {}) {
  const t = e.tickets.criar({ threadId: thread, parentId: 'CANAL_TICKETS', userId, userName: 'cliente', categoria: 'adquirir_edit' }, ator);
  if (pago) {
    e.tickets.definirProduto(t.id, 'clean_30', ator);
    e.tickets.confirmarPagamento(t.id, { txId: `PAGO-${thread}`, modo: 'manual' }, ator);
  }
  return t;
}

function clique(e, { customId, usuario = 'U1', suporte = false, canalId = 'T1', apagar = null }) {
  const acoes = { travado: false, arquivado: false, enviadas: [], respostas: [], atualizacoes: [], followUps: [], apagados: [] };
  const canal = {
    id: canalId, parentId: 'CANAL_TICKETS', name: 'x', isThread: () => true,
    setLocked: async () => { acoes.travado = true; },
    setArchived: async () => { acoes.arquivado = true; },
    send: async (m) => acoes.enviadas.push(m),
  };
  const interacao = {
    isStringSelectMenu: () => false, isChatInputCommand: () => false, isButton: () => true,
    customId, channel: canal, channelId: canalId, guild: e.guild,
    member: { roles: { cache: new Collection(suporte ? [['R2', { id: 'R2', name: config.cargos.suporte.nome }]] : []) } },
    user: { id: usuario, tag: `${usuario}#1`, toString: () => `<@${usuario}>` },
    client: { channels: { fetch: async () => { if (apagar?.erro) throw apagar.erro; return { delete: async () => acoes.apagados.push(1) }; } } },
    reply: async (c) => acoes.respostas.push(c),
    update: async (c) => acoes.atualizacoes.push(c),
    followUp: async (c) => acoes.followUps.push(c),
  };
  return { acoes, rotear: () => criarRoteador(e.ctx)(interacao) };
}

test('dono fecha o ticket (sem pedido): fecha no sistema, avisa e tranca + arquiva o tópico', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e);
  const c = clique(e, { customId: 'fechar_ticket' });
  await c.rotear();
  assert.equal(e.tickets.obter(t.id).status, 'FECHADO');
  assert.match(c.acoes.respostas[0].content, /Ticket fechado.*daqui a 3 dias/);
  assert.equal(c.acoes.travado, true);
  assert.equal(c.acoes.arquivado, true);
});

test('quem não é dono nem suporte não consegue fechar', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e);
  const c = clique(e, { customId: 'fechar_ticket', usuario: 'INTRUSO' });
  await c.rotear();
  assert.match(c.acoes.respostas[0].content, /Só quem abriu/);
  assert.equal(e.tickets.obter(t.id).status, 'ABERTO');
  assert.equal(c.acoes.travado, false);
});

test('cliente com pedido na fila não fecha sozinho; suporte precisa confirmar e o pedido é cancelado', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e, { pago: true });

  const cliente = clique(e, { customId: 'fechar_ticket' });
  await cliente.rotear();
  assert.match(cliente.acoes.respostas[0].content, /só a equipe pode fechar/);
  assert.equal(e.tickets.obter(t.id).status, 'NA_FILA');

  const equipe = clique(e, { customId: 'fechar_ticket', usuario: 'S1', suporte: true });
  await equipe.rotear();
  assert.match(equipe.acoes.respostas[0].content, /cancela o pedido/);
  assert.equal(e.tickets.obter(t.id).status, 'NA_FILA', 'ainda não fechou: espera a confirmação');
  assert.equal(equipe.acoes.travado, false);

  const confirma = clique(e, { customId: `fechar_confirmar_${t.id}`, usuario: 'S1', suporte: true });
  await confirma.rotear();
  assert.equal(e.tickets.obter(t.id).status, 'CANCELADO');
  assert.ok(e.tickets.obter(t.id).fechado_em);
  assert.equal(confirma.acoes.travado && confirma.acoes.arquivado, true);
  assert.ok(e.enviadas.some((m) => /Ticket fechado com pedido em andamento/.test(m.conteudo)));

  // e quem não é da equipe não consegue usar o botão de confirmação
  const t2 = ticketNoCanal(e, { userId: 'U2', thread: 'T2', pago: true });
  const falso = clique(e, { customId: `fechar_confirmar_${t2.id}`, usuario: 'U2', canalId: 'T2' });
  await falso.rotear();
  assert.match(falso.acoes.respostas[0].content, /Só a equipe/);
  assert.equal(e.tickets.obter(t2.id).status, 'NA_FILA');
});

test('apagar: só o suporte; apaga o tópico e registra', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e);
  e.tickets.fecharTicket(t.id, ator);

  const intruso = clique(e, { customId: `apagar_ticket_${t.id}`, usuario: 'U1' });
  await intruso.rotear();
  assert.match(intruso.acoes.respostas[0].content, /Só a equipe/);
  assert.equal(intruso.acoes.apagados.length, 0);

  const equipe = clique(e, { customId: `apagar_ticket_${t.id}`, usuario: 'S1', suporte: true });
  await equipe.rotear();
  assert.equal(equipe.acoes.apagados.length, 1);
  assert.ok(e.tickets.obter(t.id).apagado_em);
  assert.match(equipe.acoes.atualizacoes[0].content, /apagado por/);
  assert.deepEqual(equipe.acoes.atualizacoes[0].components, []);
});

test('apagar: tópico que já não existe é aceito; outro erro NÃO finge que apagou', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e);
  e.tickets.fecharTicket(t.id, ator);

  const falha = clique(e, { customId: `apagar_ticket_${t.id}`, usuario: 'S1', suporte: true, apagar: { erro: Object.assign(new Error('sem permissão'), { code: 50013 }) } });
  await falha.rotear();
  assert.match(falha.acoes.respostas[0].content, /Não consegui apagar/);
  assert.equal(e.tickets.obter(t.id).apagado_em, null);

  const sumiu = clique(e, { customId: `apagar_ticket_${t.id}`, usuario: 'S1', suporte: true, apagar: { erro: Object.assign(new Error('Unknown Channel'), { code: 10003 }) } });
  await sumiu.rotear();
  assert.ok(e.tickets.obter(t.id).apagado_em);
});

test('apagar não funciona em ticket que não foi fechado', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e);
  const c = clique(e, { customId: `apagar_ticket_${t.id}`, usuario: 'S1', suporte: true });
  await c.rotear();
  assert.match(c.acoes.respostas[0].content, /não está fechado/);
  assert.equal(c.acoes.apagados.length, 0);
});

test('manter: não apaga e não pergunta de novo', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e);
  e.tickets.fecharTicket(t.id, ator);
  e.tickets.marcarAvisoApagar(t.id);
  const c = clique(e, { customId: `manter_ticket_${t.id}`, usuario: 'S1', suporte: true });
  await c.rotear();
  assert.match(c.acoes.atualizacoes[0].content, /mantido/);
  assert.equal(c.acoes.apagados.length, 0);
  assert.equal(e.tickets.fechadosParaApagar(Date.now() + 10 * DIA).length, 0);
});

// ---------- painel e /filas ----------

test('painel fixo tem só o resumo; /filas mostra as duas filas', async () => {
  const e = montar({ textoOcr: '' });
  const enviadas = [];
  const canal = { id: 'CP', messages: { fetch: async () => null }, send: async (p) => { enviadas.push(p); return { id: 'MP' }; } };
  const painel = criarPainel({ client: e.ctx.client, db: e.db, tickets: e.tickets, config });
  await painel.instalar(canal);
  assert.equal(enviadas[0].embeds.length, 1);
  assert.match(JSON.stringify(enviadas[0].embeds[0].toJSON()), /Painel de Filas/);

  const respostas = [];
  await handlers.filas({ reply: async (c) => respostas.push(c) }, { painel });
  const titulos = respostas[0].embeds.map((x) => x.toJSON().title);
  assert.deepEqual(titulos, ['🧼 Fila Clean', '🚀 Fila Avançada']);
  assert.ok(respostas[0].flags, 'resposta só para quem usou o comando');
});

// ---------- /confirmarpagamento não falha mais em silêncio ----------

test('/confirmarpagamento avisa quando o escolhido não é o dono do ticket', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e, { userId: 'U2' });
  const respostas = [];
  const i = {
    channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' }, guild: e.guild, user: { id: 'S', tag: 's' },
    options: { getMember: () => e.membro }, // U1, mas o dono do ticket é U2
    reply: async (c) => respostas.push(c),
  };
  await handlers.confirmarpagamento(i, e.ctx);
  assert.match(respostas[0].content, /O dono deste ticket é <@U2>/);
  assert.match(respostas[0].content, /NÃO foi registrado/);
  assert.equal(e.tickets.obter(t.id).pago_em, null);
});

test('/confirmarpagamento no dono do ticket registra o pagamento e diz o próximo passo', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketNoCanal(e, { userId: 'U1' });
  const respostas = [];
  const i = {
    channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' }, guild: e.guild, user: { id: 'S', tag: 's' },
    options: { getMember: () => e.membro },
    reply: async (c) => respostas.push(c),
  };
  await handlers.confirmarpagamento(i, e.ctx);
  assert.equal(e.tickets.obter(t.id).status, 'PAGO');
  assert.match(respostas[0].content, /Falta definir o tipo/);
  e.tickets.definirTipo(t.id, 'CLEAN', ator);
  assert.equal(e.tickets.obter(t.id).status, 'NA_FILA');
});
