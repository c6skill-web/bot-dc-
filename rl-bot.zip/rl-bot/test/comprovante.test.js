'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { analisarComprovante } = require('../src/services/comprovante');

const pix = { chave: '11111111-2222-3333-4444-555555555555', nome: 'Arthur Vieira' };
const criado = new Date('2026-10-10T10:00:00-03:00').getTime();
const agora = new Date('2026-10-10T11:00:00-03:00').getTime();
const ctx = (extra = {}) => ({ esperadoCentavos: 1000, ticketCriadoEm: criado, agora, pix, ...extra });

const base = (valor = '10,00', data = '10 OUT 2026 - 10:30:00', id = 'E18236120202610101330aB3dE5fGh1') => `Comprovante de transferência
${data}
Valor R$ ${valor}
Destino Nome Arthur Vieira
Tipo de transferência Pix
ID da transação ${id}`;

test('comprovante correto é aprovado automaticamente', () => {
  const r = analisarComprovante(base(), ctx());
  assert.equal(r.aprovadoAuto, true, JSON.stringify(r.problemas));
  assert.equal(r.valorCentavos, 1000);
  assert.equal(r.data, '2026-10-10');
});

test('valor diferente do esperado NÃO aprova sozinho', () => {
  const r = analisarComprovante(base('5,00'), ctx());
  assert.equal(r.aprovadoAuto, false);
  assert.equal(r.problemas[0].codigo, 'valor_diferente');
});

test('comprovante antigo (data anterior à abertura do ticket) NÃO aprova', () => {
  const r = analisarComprovante(base('10,00', '02 SET 2026 - 10:30:00'), ctx());
  assert.equal(r.aprovadoAuto, false);
  assert.ok(r.problemas.some((p) => p.codigo === 'data_antiga'));
});

test('sem ID da transação ou sem data NÃO aprova', () => {
  const semId = analisarComprovante(base().replace(/ID da transa.*$/m, ''), ctx());
  assert.ok(semId.problemas.some((p) => p.codigo === 'sem_id'));
  const semData = analisarComprovante(base().replace('10 OUT 2026 - 10:30:00', ''), ctx());
  assert.ok(semData.problemas.some((p) => p.codigo === 'sem_data'));
});

test('comprovante para outra pessoa: o bot responde, mas avisa e NÃO aprova sozinho', () => {
  const r = analisarComprovante(base().replace('Arthur Vieira', 'Maria Souza'), ctx());
  assert.equal(r.relevante, true, 'nunca ignora em silêncio um comprovante');
  assert.equal(r.nivelDestinatario, 'nao_reconhecido');
  assert.equal(r.aprovadoAuto, false);
  assert.ok(r.problemas.some((p) => p.codigo === 'destinatario'));
});

test('texto qualquer não é comprovante', () => {
  assert.equal(analisarComprovante('foto de uma paisagem bonita', ctx()).relevante, false);
});

test('sem produto escolhido nunca aprova sozinho', () => {
  const r = analisarComprovante(base(), ctx({ esperadoCentavos: null }));
  assert.equal(r.aprovadoAuto, false);
  assert.equal(r.problemas[0].codigo, 'sem_valor_esperado');
});

test('aceita valor com milhar, data numérica e erro comum de OCR em R$', () => {
  const r = analisarComprovante(base('1.250,00', '10/10/2026 10:30').replace('R$', 'RS'), ctx({ esperadoCentavos: 125000 }));
  assert.equal(r.valorCentavos, 125000);
  assert.equal(r.data, '2026-10-10');
});

test('tarifa R$ 0,00 depois do valor não confunde a leitura', () => {
  const r = analisarComprovante(base() + '\nTarifa R$ 0,00', ctx());
  assert.equal(r.valorCentavos, 1000);
});
