'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { nomeDoTicket, interpretarNome } = require('../src/util/nomes');

const base = 'joao (123456789012345678)';
test('nomes seguem o padrão do bot antigo', () => {
  assert.equal(nomeDoTicket({ status: 'NA_FILA', tipo: 'CLEAN', fila_numero: 7, nome_base: base }), `🎥 (FILA 7 - CLEAN) ${base}`);
  assert.equal(nomeDoTicket({ status: 'NA_FILA', tipo: 'AVANCADA', fila_numero: 2, nome_base: base }), `🎥 (FILA 2 - AVANÇADA) ${base}`);
  assert.equal(nomeDoTicket({ status: 'EM_PRODUCAO', nome_base: base }), `🎥 (EM PRODUÇÃO) ${base}`);
  assert.equal(nomeDoTicket({ status: 'ENTREGUE', nome_base: base }), `🎥 (✅ENTREGUE) ${base}`);
  assert.equal(nomeDoTicket({ status: 'AGUARDANDO_PAGAMENTO', nome_base: base }), null, 'não renomeia antes da fila');
});
test('nunca passa de 100 caracteres', () => {
  assert.ok(nomeDoTicket({ status: 'EM_PRODUCAO', nome_base: 'x'.repeat(200) }).length <= 100);
});
test('interpreta nomes de tópicos existentes', () => {
  const a = interpretarNome('🎥 (FILA 4 - AVANÇADA) maria (123456789012345678)');
  assert.deepEqual([a.status, a.filaNumero, a.tipo, a.userId, a.userName], ['NA_FILA', 4, 'AVANCADA', '123456789012345678', 'maria']);
  assert.equal(interpretarNome('🎥 (RENDERIZANDO) a (123456789012345678)').status, 'RENDERIZANDO');
  assert.equal(interpretarNome('🎥 (✅ENTREGUE) a (123456789012345678)').status, 'ENTREGUE');
  assert.equal(interpretarNome('ticket-do-fulano').userId, null);
});
