'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { novoBanco } = require('./helpers/banco');
const { criarServicoTickets, ErroNegocio } = require('../src/services/tickets');
const config = require('../src/config');

function ambiente() {
  const db = novoBanco();
  const relogio = { t: new Date('2026-10-10T12:00:00-03:00').getTime() };
  const tickets = criarServicoTickets(db, {
    prazoHoras: 42, avisoHorasAntes: 12, produtos: config.produtos, agora: () => relogio.t,
  });
  const eventos = [];
  tickets.bus.on('mudou', (e) => eventos.push(e.evento));
  let n = 0;
  const novo = (userId, categoria = 'adquirir_edit') =>
    tickets.criar({ threadId: `t${++n}`, parentId: 'p', userId, userName: `u${userId}`, categoria }, { id: 'a', nome: 'x' });
  return { db, tickets, relogio, eventos, novo };
}
const ator = { id: 'sup', nome: 'suporte' };

test('fluxo completo: produto -> pagamento -> fila -> produção -> entregue', () => {
  const { tickets, novo, relogio } = ambiente();
  const t = novo('1');
  assert.equal(t.status, 'ABERTO');

  const t2 = tickets.definirProduto(t.id, 'clean_30', ator);
  assert.equal(t2.status, 'AGUARDANDO_PAGAMENTO');
  assert.equal(t2.preco_centavos, 1000);

  const r = tickets.confirmarPagamento(t.id, { valorCentavos: 1000, txId: 'TX1', hash: 'H1', modo: 'auto' }, ator);
  assert.equal(r.entrouNaFila, true);
  assert.equal(r.ticket.status, 'NA_FILA');
  assert.equal(r.ticket.fila_numero, 1);

  relogio.t += 3600_000;
  const p = tickets.mudarStatus(t.id, 'EM_PRODUCAO', ator);
  assert.equal(p.prazo_em, relogio.t + 42 * 3600_000, 'prazo de 42h conta da entrada em produção');

  relogio.t += 5 * 3600_000;
  const p2 = tickets.mudarStatus(t.id, 'RENDERIZANDO', ator);
  assert.equal(p2.prazo_em, p.prazo_em, 'trocar de sub-status não reinicia o prazo');

  const e = tickets.mudarStatus(t.id, 'ENTREGUE', ator);
  assert.equal(e.status, 'ENTREGUE');
  assert.ok(tickets.historico(t.id).length >= 5);
});

test('numeração separada por fila e crescente', () => {
  const { tickets, novo } = ambiente();
  const nums = [];
  for (const [uid, prod] of [['1', 'clean_30'], ['2', 'avancada_30'], ['3', 'clean_60']]) {
    const t = novo(uid);
    tickets.definirProduto(t.id, prod, ator);
    nums.push(tickets.confirmarPagamento(t.id, { valorCentavos: 1, txId: `T${uid}`, modo: 'auto' }, ator).ticket);
  }
  assert.deepEqual(nums.map((t) => [t.tipo, t.fila_numero]), [['CLEAN', 1], ['AVANCADA', 1], ['CLEAN', 2]]);
});

test('comprovante repetido (mesmo ID ou mesma imagem) é bloqueado', () => {
  const { tickets, novo } = ambiente();
  const a = novo('1'); tickets.definirProduto(a.id, 'clean_30', ator);
  const b = novo('2'); tickets.definirProduto(b.id, 'clean_30', ator);
  tickets.confirmarPagamento(a.id, { txId: 'TX', hash: 'H', modo: 'auto' }, ator);
  assert.ok(tickets.comprovanteUsado({ txId: 'TX' }));
  assert.ok(tickets.comprovanteUsado({ hash: 'H' }));
  assert.throws(() => tickets.confirmarPagamento(b.id, { txId: 'TX', modo: 'auto' }, ator), (e) => e.codigo === 'comprovante_duplicado');
  assert.throws(() => tickets.confirmarPagamento(b.id, { hash: 'H', modo: 'auto' }, ator), (e) => e.codigo === 'comprovante_duplicado');
  assert.equal(tickets.obter(b.id).status, 'AGUARDANDO_PAGAMENTO', 'rollback: nada mudou');
});

test('um ticket ativo por pessoa; depois de entregue pode abrir outro', () => {
  const { tickets, novo } = ambiente();
  const a = novo('1');
  assert.throws(() => novo('1'), (e) => e.codigo === 'ja_aberto');
  tickets.mudarStatus(a.id, 'CANCELADO', ator);
  assert.doesNotThrow(() => novo('1'));
});

test('pago sem tipo vira PAGO; /tipo coloca na fila; trocar de tipo transfere', () => {
  const { tickets, novo, db } = ambiente();
  const a = novo('1');
  const r = tickets.confirmarPagamento(a.id, { modo: 'manual' }, ator);
  assert.equal(r.ticket.status, 'PAGO');
  const q = tickets.definirTipo(a.id, 'AVANCADA', ator);
  assert.equal(q.status, 'NA_FILA');
  assert.equal(q.fila_numero, 1);
  const t = tickets.definirTipo(a.id, 'CLEAN', ator);
  assert.equal(t.tipo, 'CLEAN');
  assert.equal(t.status, 'NA_FILA');
  assert.ok(db.prepare("SELECT 1 FROM ticket_eventos WHERE tipo='TRANSFERIDO'").get());
  assert.throws(() => tickets.definirTipo(a.id, 'CLEAN', ator), (e) => e.codigo === 'mesmo_tipo');
});

test('antes do pagamento não dá pra definir tipo nem entrar na fila sem tipo', () => {
  const { tickets, novo } = ambiente();
  const a = novo('1');
  assert.throws(() => tickets.definirTipo(a.id, 'CLEAN', ator), (e) => e.codigo === 'sem_pagamento');
  assert.throws(() => tickets.mudarStatus(a.id, 'NA_FILA', ator), (e) => e.codigo === 'sem_tipo');
});

test('ticket encerrado não aceita mais mudanças', () => {
  const { tickets, novo } = ambiente();
  const a = novo('1');
  tickets.mudarStatus(a.id, 'ENTREGUE', ator);
  assert.throws(() => tickets.mudarStatus(a.id, 'EM_PRODUCAO', ator), (e) => e.codigo === 'encerrado');
});

test('/renomear manual: número ocupado é recusado', () => {
  const { tickets, novo } = ambiente();
  const a = novo('1'); const b = novo('2');
  tickets.definirNumeroManual(a.id, { tipo: 'CLEAN', numero: 5 }, ator);
  assert.throws(() => tickets.definirNumeroManual(b.id, { tipo: 'CLEAN', numero: 5 }, ator), (e) => e.codigo === 'numero_ocupado');
  // o contador automático passa do 5
  const c = novo('3'); tickets.definirProduto(c.id, 'clean_30', ator);
  assert.equal(tickets.confirmarPagamento(c.id, { txId: 'Z', modo: 'auto' }, ator).ticket.fila_numero, 6);
});

test('Postar com Qualidade: valor fixo de R$ 3 e não entra em fila', () => {
  const { tickets, novo } = ambiente();
  const a = novo('1', 'postar_qualidade');
  assert.equal(a.preco_centavos, 300);
  assert.equal(a.status, 'AGUARDANDO_PAGAMENTO');
  const r = tickets.confirmarPagamento(a.id, { valorCentavos: 300, txId: 'P', modo: 'auto' }, ator);
  assert.equal(r.entrouNaFila, false);
  assert.equal(r.ticket.status, 'AGUARDANDO_PAGAMENTO');
});

test('alertas de prazo: aviso 12h antes e atraso, cada um uma vez', () => {
  const { tickets, novo, relogio } = ambiente();
  const a = novo('1'); tickets.definirProduto(a.id, 'clean_30', ator);
  tickets.confirmarPagamento(a.id, { txId: 'A', modo: 'auto' }, ator);
  tickets.mudarStatus(a.id, 'EM_PRODUCAO', ator);

  assert.equal(tickets.alertasDePrazo(relogio.t + 29 * 3600_000).proximos.length, 0);
  relogio.t += 31 * 3600_000;
  let al = tickets.alertasDePrazo();
  assert.equal(al.proximos.length, 1);
  tickets.marcarAlertaEnviado(a.id, 'aviso');
  assert.equal(tickets.alertasDePrazo().proximos.length, 0);

  relogio.t += 12 * 3600_000;
  al = tickets.alertasDePrazo();
  assert.equal(al.atrasados.length, 1);
  tickets.marcarAlertaEnviado(a.id, 'atraso');
  assert.equal(tickets.alertasDePrazo().atrasados.length, 0);
});

test('snapshot conta pendentes, produção, entregues de hoje e cancelados', () => {
  const { tickets, novo, relogio } = ambiente();
  const ids = [];
  for (let i = 1; i <= 4; i++) {
    const t = novo(String(i)); tickets.definirProduto(t.id, i % 2 ? 'clean_30' : 'avancada_30', ator);
    tickets.confirmarPagamento(t.id, { txId: `S${i}`, modo: 'auto' }, ator); ids.push(t.id);
  }
  tickets.mudarStatus(ids[0], 'EM_PRODUCAO', ator);
  tickets.mudarStatus(ids[1], 'ENTREGUE', ator);
  tickets.mudarStatus(ids[2], 'CANCELADO', ator);
  const s = tickets.snapshot(relogio.t);
  assert.equal(s.porTipo.CLEAN.producao.length, 1);
  assert.equal(s.porTipo.CLEAN.pendentes.length, 0);
  assert.equal(s.porTipo.AVANCADA.pendentes.length, 1);
  assert.equal(s.entreguesHoje, 1);
  assert.equal(s.canceladosTotal, 1);
});

test('eventos são emitidos só depois do commit (e não em caso de erro)', () => {
  const { tickets, novo, eventos } = ambiente();
  const a = novo('1'); tickets.definirProduto(a.id, 'clean_30', ator);
  tickets.confirmarPagamento(a.id, { txId: 'E', modo: 'auto' }, ator);
  const antes = eventos.length;
  const b = novo('2'); tickets.definirProduto(b.id, 'clean_30', ator);
  const depoisB = eventos.length;
  try { tickets.confirmarPagamento(b.id, { txId: 'E', modo: 'auto' }, ator); } catch {}
  assert.equal(eventos.length, depoisB, 'pagamento duplicado não emitiu nada');
  assert.ok(antes > 0);
});

test('importação: números repetidos não quebram e contador continua do maior', () => {
  const { tickets } = ambiente();
  const base = { parentId: 'p', userName: 'x', categoria: 'adquirir_edit' };
  tickets.criarImportado({ ...base, threadId: 'i1', userId: '1', status: 'NA_FILA', tipo: 'CLEAN', filaNumero: 3 }, ator);
  const dup = tickets.criarImportado({ ...base, threadId: 'i2', userId: '2', status: 'NA_FILA', tipo: 'CLEAN', filaNumero: 3 }, ator);
  assert.notEqual(dup.fila_numero, 3);
  const prod = tickets.criarImportado({ ...base, threadId: 'i3', userId: '3', status: 'EM_PRODUCAO', tipo: 'AVANCADA' }, ator);
  assert.ok(prod.prazo_em > prod.producao_em);
});
