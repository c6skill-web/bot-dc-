'use strict';
// Correções da revisão geral: comprovante nunca ignorado em silêncio, OCR com falha avisa,
// admin é equipe, pedido nunca cancelado por engano ao conferir tópicos, importação com a data certa.
const test = require('node:test');
const assert = require('node:assert/strict');
const { Collection, PermissionFlagsBits } = require('discord.js');
const config = require('../src/config');
const { analisarComprovante } = require('../src/services/comprovante');
const { tratarImagemDeTicket } = require('../src/discord/pagamentos');
const { criarRoteador } = require('../src/discord/interacoes');
const { topicoFoiApagado } = require('../src/discord/topicos');
const { importarThread } = require('../src/services/importar');
const { temCargo } = require('../src/util/permissoes');
const { novoBanco } = require('./helpers/banco');
const { criarServicoTickets } = require('../src/services/tickets');
const { montar, mensagem, comprovante } = require('./helpers/discord');

config.pagamento.modo = 'manual';
const ator = { id: 's', nome: 's' };
const pix = { chave: '534194f3-9687-4b2f-8a2a-f6cb1200873a', nome: 'Arthur Vieira' };
const ctxAnalise = { esperadoCentavos: null, ticketCriadoEm: Date.parse('2026-10-10T10:00:00-03:00'), agora: Date.parse('2026-10-10T12:00:00-03:00'), pix };
const ler = (texto) => analisarComprovante(texto, ctxAnalise);

// ---------- leitura de comprovantes de bancos diferentes ----------

test('nome mascarado + banco Nubank: responde e marca destinatário como parcial', () => {
  const r = ler('Comprovante de transferência\n10 OUT 2026 - 10:30\nValor R$ 10,00\nNome ARTHUR V***\nInstituição NU PAGAMENTOS - IP\nID da transação E18236120202610101330aB3dE5fGh1');
  assert.equal(r.relevante, true);
  assert.equal(r.nivelDestinatario, 'parcial');
  assert.ok(r.problemas.some((p) => p.codigo === 'destinatario_parcial'));
  assert.equal(r.aprovadoAuto, false);
});

test('valor sem centavos, "Número da operação" como ID e data por extenso', () => {
  const r = ler('Você pagou R$ 10 via Pix\n10 de outubro de 2026 às 10:30\nNúmero da operação 98765432101\nPara Arthur Vieira');
  assert.equal(r.valorCentavos, 1000);
  assert.equal(r.txId, '98765432101');
  assert.equal(r.data, '2026-10-10');
  assert.equal(r.nivelDestinatario, 'confirmado');
});

test('tolera erro de OCR no nome (Vleira) e zero lido como letra O', () => {
  const r = ler('Pix enviado\nValor R$ 1o,00\n10/10/2026\nPara Arthur Vleira\nID da transacao E18236120202610101330aB3dE5fGh1');
  assert.equal(r.valorCentavos, 1000);
  assert.equal(r.nivelDestinatario, 'confirmado');
});

test('nome em outra ordem e pedaço da chave Pix também confirmam o destinatário', () => {
  assert.equal(ler('Comprovante Pix\nValor R$ 10,00\nDestino VIEIRA, ARTHUR').nivelDestinatario, 'confirmado');
  assert.equal(ler('Comprovante Pix\nValor R$ 10,00\nChave 534194f3-****-****-****-f6cb1200873a').nivelDestinatario, 'confirmado');
});

test('data no formato ISO e imagem que nem parece comprovante', () => {
  assert.equal(ler('Pix\nValor R$ 10,00\n2026-10-10 10:30').data, '2026-10-10');
  assert.equal(ler('print do premiere, timeline 00:12, projeto final').relevante, false);
});

// ---------- fluxo: nunca fica mudo ----------

function ticketDoDono(e, extra = {}) {
  return e.tickets.criar({ threadId: 'T1', parentId: 'CANAL_TICKETS', userId: 'U1', userName: 'cliente', categoria: 'adquirir_edit', ...extra }, ator);
}

test('comprovante para outra pessoa: o bot responde com aviso e botão (antes ficava mudo)', async () => {
  const e = montar({ textoOcr: comprovante('10,00').replace('Arthur Vieira', 'Maria Souza') });
  ticketDoDono(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.equal(respostas.length, 1);
  assert.match(respostas[0].content, /Destinatário: ⚠️ não reconheci/);
  assert.equal(respostas[0].components.length, 1);
});

test('falha na leitura (OCR): avisa a equipe com botão em vez de ignorar', async () => {
  const e = montar({ textoOcr: () => { throw new Error('idioma não baixou'); } });
  const t = ticketDoDono(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.match(respostas[0].content, /Não consegui ler esse print/);
  assert.equal(respostas[0].components[0].toJSON().components[0].custom_id, 'confirmar_comprovante_U1');
  assert.equal(e.tickets.obter(t.id).status, 'ABERTO', 'nada foi confirmado');
});

test('print que não parece comprovante continua ignorado (sem spam)', async () => {
  const e = montar({ textoOcr: 'timeline do premiere 00:12 projeto final' });
  ticketDoDono(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.equal(respostas.length, 0);
});

test('várias imagens na mesma mensagem: acha o comprovante mesmo se não for a primeira', async () => {
  let chamada = 0;
  const e = montar({ textoOcr: () => (++chamada === 1 ? 'print da edit no premiere' : comprovante('10,00')) });
  ticketDoDono(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  msg.attachments.set('b', { contentType: 'image/png', size: 1000, url: 'http://x/z.png' });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.equal(chamada, 2);
  assert.match(respostas[0].content, /Valor: \*\*R\$\s?10,00\*\*/);
});

test('imagem sem contentType (extensão .png) também é lida', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  ticketDoDono(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  msg.attachments = new Collection([['a', { contentType: null, name: 'comprovante.PNG', size: 1000, url: 'http://x/y' }]]);
  await tratarImagemDeTicket(msg, e.ctx);
  assert.equal(respostas.length, 1);
});

test('ticket do próprio bot funciona mesmo com TICKET_FORUM_ID errado/vazio; tópico desconhecido fora do canal é ignorado', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  ticketDoDono(e);
  const original = config.canais.tickets;
  config.canais.tickets = '';
  try {
    const registrado = mensagem({ guild: e.guild });
    registrado.msg.channel.parentId = 'QUALQUER';
    await tratarImagemDeTicket(registrado.msg, e.ctx);
    assert.equal(registrado.respostas.length, 1, 'tópico registrado é lido');

    const desconhecido = mensagem({ guild: e.guild });
    desconhecido.msg.channel.id = 'T-OUTRO';
    desconhecido.msg.channel.parentId = 'QUALQUER';
    await tratarImagemDeTicket(desconhecido.msg, e.ctx);
    assert.equal(desconhecido.respostas.length, 0, 'tópico que o bot não conhece e fora do canal de tickets: ignora');
  } finally {
    config.canais.tickets = original;
  }
});

test('mostra 🔎 enquanto lê e tira depois', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  e.ctx.client.user = { id: 'BOT' };
  ticketDoDono(e);
  const { msg } = mensagem({ guild: e.guild });
  const log = [];
  msg.react = async (emoji) => { log.push(`react ${emoji}`); return { users: { remove: async (id) => { log.push(`remove ${id}`); } } }; };
  await tratarImagemDeTicket(msg, e.ctx);
  assert.deepEqual(log, ['react 🔎', 'remove BOT']);
});

// ---------- botão manual não "confirma" sem registrar ----------

test('botão manual num ticket de OUTRA pessoa avisa que o pedido não foi registrado', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketDoDono(e, { userId: 'U2' });
  const respostas = [];
  const interacao = {
    isStringSelectMenu: () => false, isChatInputCommand: () => false, isButton: () => true,
    customId: 'confirmar_comprovante_U1',
    member: { roles: { cache: new Collection([['R2', { id: 'R2', name: config.cargos.suporte.nome }]]) } },
    guild: e.guild, channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' },
    message: { id: 'R1' }, user: { id: 'S1', tag: 's#1' },
    reply: async (c) => respostas.push(c), update: async (c) => respostas.push(c),
  };
  await criarRoteador(e.ctx)(interacao);
  assert.match(respostas[0].content, /O dono deste ticket é <@U2>/);
  assert.match(respostas[0].content, /NÃO foi registrado/);
  assert.equal(e.tickets.obter(t.id).pago_em, null);
});

// ---------- permissões ----------

test('administrador do servidor conta como equipe; membro comum sem cargo, não', () => {
  const comum = { roles: { cache: new Collection() }, permissions: { has: () => false } };
  const admin = { roles: { cache: new Collection() }, permissions: { has: (p) => p === PermissionFlagsBits.Administrator } };
  const suporte = { roles: { cache: new Collection([['R2', { id: 'R2', name: config.cargos.suporte.nome }]]) }, permissions: { has: () => false } };
  assert.equal(temCargo(comum, config.cargos.suporte), false);
  assert.equal(temCargo(admin, config.cargos.suporte), true);
  assert.equal(temCargo(suporte, config.cargos.suporte), true);
});

// ---------- nunca cancelar pedido por engano ----------

const clienteDiscord = ({ erroTopico, podeVerTudo }) => ({
  channels: {
    fetch: async (id) => {
      if (id === 'THREAD') { if (erroTopico) throw erroTopico; return { id }; }
      return { guild: { members: { me: {} } }, permissionsFor: () => ({ has: (p) => p === PermissionFlagsBits.ManageThreads && podeVerTudo }) };
    },
  },
});
const ticketFalso = { thread_id: 'THREAD', parent_id: 'PAI' };
const erro = (code) => Object.assign(new Error('x'), { code });

test('tópico existente: não foi apagado', async () => {
  assert.equal(await topicoFoiApagado(clienteDiscord({}), ticketFalso), false);
});
test('"Unknown Channel" só vale como apagado se o bot enxerga todos os tópicos privados', async () => {
  assert.equal(await topicoFoiApagado(clienteDiscord({ erroTopico: erro(10003), podeVerTudo: true }), ticketFalso), true);
  assert.equal(await topicoFoiApagado(clienteDiscord({ erroTopico: erro(10003), podeVerTudo: false }), ticketFalso), false, 'pode ser só falta de acesso');
});
test('qualquer outro erro (sem acesso, rede) não conta como apagado', async () => {
  assert.equal(await topicoFoiApagado(clienteDiscord({ erroTopico: erro(50001), podeVerTudo: true }), ticketFalso), false);
  assert.equal(await topicoFoiApagado(clienteDiscord({ erroTopico: new Error('ECONNRESET'), podeVerTudo: true }), ticketFalso), false);
});

// ---------- importação ----------

test('ticket importado usa a data de criação do tópico (não a hora da importação)', () => {
  const db = novoBanco();
  const tk = criarServicoTickets(db, { produtos: config.produtos, agora: () => Date.parse('2026-10-12T12:00:00-03:00') });
  const criado = Date.parse('2026-10-09T09:00:00-03:00');
  const r = importarThread(tk, { id: 'X1', name: '🎥 cliente (123456789012345678)', parentId: 'P', createdTimestamp: criado });
  assert.equal(r.ticket.criado_em, criado);
  // sem a data do Discord, cai para "agora"
  const r2 = importarThread(tk, { id: 'X2', name: '🎥 outro (223456789012345678)', parentId: 'P' });
  assert.equal(r2.ticket.criado_em, Date.parse('2026-10-12T12:00:00-03:00'));
});
