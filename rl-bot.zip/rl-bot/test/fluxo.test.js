'use strict';
// Fluxo completo com o Discord simulado (ver test/helpers/discord.js).
const test = require('node:test');
const assert = require('node:assert/strict');
const { Collection } = require('discord.js');
const config = require('../src/config');
const { tratarImagemDeTicket } = require('../src/discord/pagamentos');
const { criarRoteador } = require('../src/discord/interacoes');
const { handlers } = require('../src/discord/comandos');
const { criarRenomeador } = require('../src/services/nomeThread');
const { montar, mensagem, comprovante } = require('./helpers/discord');

config.pagamento.modo = 'auto';

const ator = { id: 's', nome: 's' };
function ticketComProduto(tickets, chave = 'clean_30') {
  const t = tickets.criar({ threadId: 'T1', parentId: 'CANAL_TICKETS', userId: 'U1', userName: 'cliente', categoria: 'adquirir_edit' }, ator);
  tickets.definirProduto(t.id, chave, ator);
  return t;
}

test('pagamento correto: confirma sozinho, dá cargo, entra na fila, renomeia e avisa a equipe', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  const t = ticketComProduto(e.tickets);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);

  const depois = e.tickets.obter(t.id);
  assert.equal(depois.status, 'NA_FILA');
  assert.equal(depois.fila_numero, 1);
  assert.match(respostas[0].content, /confirmado automaticamente/);
  assert.match(respostas[0].content, /#1/);
  assert.ok(e.membro.roles.cache.has('R1'), 'cargo de cliente dado');
  assert.ok(e.renomeados.some((n) => n.includes('(FILA 1 - CLEAN)')), 'tópico renomeado: ' + e.renomeados);
  assert.ok(e.enviadas.some((m) => /Novo pedido na fila/.test(m.conteudo)));
  assert.ok(e.enviadas.some((m) => /automaticamente/.test(m.conteudo)));
});

test('valor errado: NÃO confirma, mostra botão e o motivo', async () => {
  const e = montar({ textoOcr: comprovante('5,00') });
  const t = ticketComProduto(e.tickets);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);

  assert.equal(e.tickets.obter(t.id).status, 'AGUARDANDO_PAGAMENTO');
  assert.match(respostas[0].content, /valor diferente do esperado/);
  assert.ok(respostas[0].components.length === 1, 'botão de confirmação manual');
  assert.equal(e.membro.roles.cache.size, 0);
});

test('mesmo comprovante em outro ticket: bloqueado, equipe alertada', async () => {
  const texto = comprovante('10,00', 'E18236120202610101330REPETIDO12');
  const e = montar({ textoOcr: texto });
  ticketComProduto(e.tickets);
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx);

  // outro cliente tenta usar o mesmo comprovante
  const t2 = e.tickets.criar({ threadId: 'T2', parentId: 'CANAL_TICKETS', userId: 'U2', userName: 'outro', categoria: 'adquirir_edit' }, ator);
  e.tickets.definirProduto(t2.id, 'clean_30', ator);
  const { msg, respostas } = mensagem({ guild: e.guild, autor: 'U2' });
  msg.channel.id = 'T2';
  await tratarImagemDeTicket(msg, e.ctx);

  assert.equal(e.tickets.obter(t2.id).status, 'AGUARDANDO_PAGAMENTO');
  assert.match(respostas[0].content, /já foi utilizado/);
  assert.ok(e.enviadas.some((m) => /Comprovante repetido/.test(m.conteudo) && m.pingarSuporte));
});

test('mesma imagem reenviada (mesmo hash) também é barrada', async () => {
  const e = montar({ textoOcr: () => comprovante('10,00') });
  ticketComProduto(e.tickets);
  const imagem = Buffer.from('mesma-imagem');
  await tratarImagemDeTicket(mensagem({ guild: e.guild, imagem }).msg, e.ctx);
  const t2 = e.tickets.criar({ threadId: 'T2', parentId: 'CANAL_TICKETS', userId: 'U2', userName: 'o', categoria: 'adquirir_edit' }, ator);
  e.tickets.definirProduto(t2.id, 'clean_30', ator);
  const { msg } = mensagem({ guild: e.guild, autor: 'U2', imagem });
  msg.channel.id = 'T2';
  await tratarImagemDeTicket(msg, e.ctx);
  assert.equal(e.tickets.obter(t2.id).status, 'AGUARDANDO_PAGAMENTO');
});

test('imagem de outra pessoa no ticket e imagens após o pagamento são ignoradas (sem gastar OCR)', async () => {
  let leituras = 0;
  const e = montar({ textoOcr: () => { leituras++; return comprovante('10,00'); } });
  ticketComProduto(e.tickets);
  await tratarImagemDeTicket(mensagem({ guild: e.guild, autor: 'OUTRO' }).msg, e.ctx);
  assert.equal(leituras, 0);
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx);
  assert.equal(leituras, 1);
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx); // referência do cliente depois de pago
  assert.equal(leituras, 1);
});

test('modo manual: nunca confirma sozinho, mesmo com comprovante perfeito', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  e.ctx.config = { ...config, pagamento: { modo: 'manual' } };
  const t = ticketComProduto(e.tickets);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.equal(e.tickets.obter(t.id).status, 'AGUARDANDO_PAGAMENTO');
  assert.ok(respostas[0].components.length === 1);
});

test('botão manual da equipe registra pagamento, coloca na fila e dá cargo; só suporte pode', async () => {
  const e = montar({ textoOcr: comprovante('5,00') });
  const t = ticketComProduto(e.tickets);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);

  const rotear = criarRoteador(e.ctx);
  const respondidas = [];
  const interacao = (temSuporte) => ({
    isStringSelectMenu: () => false, isButton: () => true, isChatInputCommand: () => false,
    customId: 'confirmar_comprovante_U1',
    member: { roles: { cache: new Collection(temSuporte ? [['R2', { id: 'R2', name: config.cargos.suporte.nome }]] : []) } },
    guild: e.guild, channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' },
    message: { id: 'R1' }, user: { id: 'S1', tag: 's#1' },
    reply: async (c) => respondidas.push(c), update: async (c) => respondidas.push(c),
  });

  await rotear(interacao(false));
  assert.match(respondidas[0].content, /não tem permissão/);
  assert.equal(e.tickets.obter(t.id).status, 'AGUARDANDO_PAGAMENTO');

  await rotear(interacao(true));
  assert.equal(e.tickets.obter(t.id).status, 'NA_FILA');
  assert.ok(e.membro.roles.cache.has('R1'));
  assert.match(respondidas[1].content, /Pedido na fila CLEAN #1/);
});

test('/renomear producao inicia o prazo e /entregue encerra; comandos só para suporte', async () => {
  const e = montar({ textoOcr: '' });
  const t = ticketComProduto(e.tickets);
  e.tickets.confirmarPagamento(t.id, { txId: 'Q', modo: 'manual' }, ator);

  const respostas = [];
  const interacao = (opcoes) => ({
    channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' }, guild: e.guild, user: { id: 'S', tag: 's' },
    options: { getInteger: (n) => opcoes[n] ?? null, getString: (n) => opcoes[n] ?? null, getBoolean: (n) => opcoes[n] ?? null, getMember: () => null },
    deferReply: async () => {}, editReply: async (c) => respostas.push(c), reply: async (c) => respostas.push(c), followUp: async (c) => respostas.push(c),
  });

  await handlers.renomear(interacao({ producao: true }), e.ctx);
  const emProd = e.tickets.obter(t.id);
  assert.equal(emProd.status, 'EM_PRODUCAO');
  assert.ok(emProd.prazo_em - emProd.producao_em === 42 * 3600_000);
  assert.ok(e.renomeados.some((n) => n.includes('(EM PRODUÇÃO)')));

  await handlers.entregue(interacao({}), e.ctx);
  assert.equal(e.tickets.obter(t.id).status, 'ENTREGUE');
  assert.ok(e.renomeados.some((n) => n.includes('ENTREGUE')));
});

test('renomeador junta pedidos seguidos e aplica só o último nome', async () => {
  const aplicados = [];
  const client = { channels: { fetch: async () => ({ name: 'antigo', setName: async (n) => { await new Promise((r) => setTimeout(r, 20)); aplicados.push(n); } }) } };
  const r = criarRenomeador(client);
  r.solicitar('T', 'um'); r.solicitar('T', 'dois'); r.solicitar('T', 'tres');
  await new Promise((res) => setTimeout(res, 150));
  assert.deepEqual(aplicados, ['um', 'tres']);
});
