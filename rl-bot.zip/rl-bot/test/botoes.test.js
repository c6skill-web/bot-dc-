'use strict';
// Ticket aberto "como no Rio Bot" (sem menu de produto) + pagamento manual com botões de opção.
const test = require('node:test');
const assert = require('node:assert/strict');
const { Collection } = require('discord.js');
const config = require('../src/config');
const { tratarImagemDeTicket } = require('../src/discord/pagamentos');
const { criarRoteador } = require('../src/discord/interacoes');
const { handlers } = require('../src/discord/comandos');
const { abrirTicket } = require('../src/discord/tickets');
const { acharCategoria } = require('../src/conteudo');
const { opcoesParaValor, codigoDaOpcao } = require('../src/services/opcoes');
const { montarEmbeds } = require('../src/services/painel');
const { montar, mensagem, comprovante } = require('./helpers/discord');

config.pagamento.modo = 'manual';
const ator = { id: 's', nome: 's' };

const novoTicketSemProduto = (e, userId = 'U1', threadId = 'T1') =>
  e.tickets.criar({ threadId, parentId: 'CANAL_TICKETS', userId, userName: 'cliente', categoria: 'adquirir_edit' }, ator);

const botoesDe = (resposta) => resposta.components[0].toJSON().components;

function cliqueNaOpcao(e, { codigo, suporte = true, cliente = 'U1', msgId = 'R1', canal = 'T1' }) {
  const respostas = [];
  const interacao = {
    isStringSelectMenu: () => false, isButton: () => true, isChatInputCommand: () => false,
    customId: `confirmar_opcao_${cliente}_${codigo}`,
    member: { roles: { cache: new Collection(suporte ? [['R2', { id: 'R2', name: config.cargos.suporte.nome }]] : []) } },
    guild: e.guild, channel: { id: canal, parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' },
    message: { id: msgId }, user: { id: 'S1', tag: 's#1' },
    reply: async (c) => respostas.push(c), update: async (c) => respostas.push(c),
  };
  return { interacao, respostas, rotear: () => criarRoteador(e.ctx)(interacao) };
}

test('opcoesParaValor: cada valor lista só os pedidos que realmente somam aquilo', () => {
  const op = (v) => opcoesParaValor(v, config.produtos, config.adicionais).map(codigoDaOpcao);
  assert.deepEqual(op(1000), ['clean_30']);
  assert.deepEqual(op(1500), ['clean_60', 'avancada_30', 'clean_30+p']);
  assert.deepEqual(op(2000), ['avancada_60', 'clean_60+p', 'avancada_30+p']);
  assert.deepEqual(op(2500), ['avancada_60+p']);
  assert.deepEqual(op(500), []);
  assert.deepEqual(op(1234), []);
  assert.deepEqual(op(null), []);
  assert.deepEqual(op(300), [], 'Postar com Qualidade (R$ 3) não é pedido de fila');
});

test('R$ 15: mostra o resumo e 3 opções + botão alternativo; NADA é confirmado sozinho', async () => {
  const e = montar({ textoOcr: comprovante('15,00') });
  const t = novoTicketSemProduto(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);

  assert.equal(e.tickets.obter(t.id).status, 'ABERTO', 'modo manual: não confirma sozinho');
  const texto = respostas[0].content;
  assert.match(texto, /Valor: \*\*R\$\s?15,00\*\*/);
  assert.match(texto, /Destinatário: ✅/);
  assert.match(texto, /ID da transação: `E/);
  assert.match(texto, /Mais de um pedido bate/);

  const b = botoesDe(respostas[0]);
  assert.deepEqual(
    b.map((x) => x.custom_id),
    ['confirmar_opcao_U1_clean_60', 'confirmar_opcao_U1_avancada_30', 'confirmar_opcao_U1_clean_30+p', 'confirmar_comprovante_U1']
  );
  assert.match(b[2].label, /prioridade/);
});

test('clicar numa opção confirma o pagamento, define a fila, dá cargo e registra a prioridade', async () => {
  const e = montar({ textoOcr: comprovante('15,00') });
  const t = novoTicketSemProduto(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  const idDaMensagem = 'R1'; // o helper responde com id R<n>

  const c = cliqueNaOpcao(e, { codigo: 'clean_30+p', msgId: idDaMensagem });
  await c.rotear();

  const depois = e.tickets.obter(t.id);
  assert.equal(depois.status, 'NA_FILA');
  assert.equal(depois.tipo, 'CLEAN');
  assert.equal(depois.produto, 'clean_30');
  assert.equal(depois.prioridade, 1);
  assert.equal(depois.fila_numero, 1);
  assert.ok(depois.pago_em);
  assert.ok(e.membro.roles.cache.has('R1'), 'cargo de cliente');
  assert.match(c.respostas[0].content, /Clean de 30s \+ prioridade.*⚡.*CLEAN #1/s);
  assert.ok(e.renomeados.some((n) => n.includes('(FILA 1 - CLEAN)')));
  assert.ok(e.enviadas.some((m) => /Novo pedido na fila/.test(m.conteudo) && m.conteudo.includes('⚡')));
  const eventos = e.tickets.historico(t.id).map((x) => x.tipo);
  assert.ok(eventos.includes('PRIORIDADE') && eventos.includes('PAGAMENTO'));
  assert.equal(e.db.prepare('SELECT valor_centavos AS v, modo FROM pagamentos').get().v, 1500);
});

test('a mesma tela serve para Avançada 30s no R$ 15 (sem prioridade)', async () => {
  const e = montar({ textoOcr: comprovante('15,00') });
  const t = novoTicketSemProduto(e);
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx);
  await cliqueNaOpcao(e, { codigo: 'avancada_30' }).rotear();
  const d = e.tickets.obter(t.id);
  assert.deepEqual([d.tipo, d.prioridade, d.status], ['AVANCADA', 0, 'NA_FILA']);
});

test('R$ 10: uma opção só, e mesmo assim espera o clique da equipe', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  const t = novoTicketSemProduto(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.match(respostas[0].content, /Só uma opção bate/);
  assert.equal(botoesDe(respostas[0]).length, 2);
  assert.equal(e.tickets.obter(t.id).status, 'ABERTO');
});

test('valor fora da tabela: só o botão alternativo, com aviso; /tipo resolve depois', async () => {
  const e = montar({ textoOcr: comprovante('12,34') });
  const t = novoTicketSemProduto(e);
  const { msg, respostas } = mensagem({ guild: e.guild });
  await tratarImagemDeTicket(msg, e.ctx);
  assert.match(respostas[0].content, /não bate com nenhum pedido da tabela/);
  const b = botoesDe(respostas[0]);
  assert.deepEqual(b.map((x) => x.custom_id), ['confirmar_comprovante_U1']);

  const respondidas = [];
  const i = {
    isStringSelectMenu: () => false, isButton: () => true, isChatInputCommand: () => false,
    customId: 'confirmar_comprovante_U1',
    member: { roles: { cache: new Collection([['R2', { id: 'R2', name: config.cargos.suporte.nome }]]) } },
    guild: e.guild, channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' },
    message: { id: 'R1' }, user: { id: 'S1', tag: 's#1' },
    reply: async (c) => respondidas.push(c), update: async (c) => respondidas.push(c),
  };
  await criarRoteador(e.ctx)(i);
  assert.equal(e.tickets.obter(t.id).status, 'PAGO');
  e.tickets.definirTipo(t.id, 'AVANCADA', ator);
  assert.equal(e.tickets.obter(t.id).status, 'NA_FILA');
});

test('quem não é suporte não consegue clicar, e nada muda', async () => {
  const e = montar({ textoOcr: comprovante('15,00') });
  const t = novoTicketSemProduto(e);
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx);
  const c = cliqueNaOpcao(e, { codigo: 'clean_60', suporte: false });
  await c.rotear();
  assert.match(c.respostas[0].content, /não tem permissão/);
  assert.equal(e.tickets.obter(t.id).status, 'ABERTO');
  assert.equal(e.membro.roles.cache.size, 0);
});

test('opção que não soma o valor lido no print é recusada', async () => {
  const e = montar({ textoOcr: comprovante('10,00') });
  const t = novoTicketSemProduto(e);
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx);
  const c = cliqueNaOpcao(e, { codigo: 'avancada_60' }); // R$ 20 num comprovante de R$ 10
  await c.rotear();
  assert.match(c.respostas[0].content, /não bate com o valor lido/);
  assert.equal(e.tickets.obter(t.id).status, 'ABERTO');
});

test('comprovante já usado em outro pedido: o clique não confirma', async () => {
  const e = montar({ textoOcr: comprovante('10,00', 'E18236120202610101330JAUSADO12') });
  const a = novoTicketSemProduto(e, 'U1', 'T1');
  await tratarImagemDeTicket(mensagem({ guild: e.guild }).msg, e.ctx);
  await cliqueNaOpcao(e, { codigo: 'clean_30' }).rotear();
  assert.equal(e.tickets.obter(a.id).status, 'NA_FILA');

  // outro cliente tenta o mesmo comprovante: barrado já no envio
  const b = novoTicketSemProduto(e, 'U2', 'T2');
  const { msg, respostas } = mensagem({ guild: e.guild, autor: 'U2' });
  msg.channel.id = 'T2';
  await tratarImagemDeTicket(msg, e.ctx);
  assert.match(respostas[0].content, /já foi utilizado/);
  assert.equal(e.tickets.obter(b.id).status, 'ABERTO');
});

test('/prioridade liga e desliga a marca; painel mostra ⚡', async () => {
  const e = montar({ textoOcr: '' });
  const t = novoTicketSemProduto(e);
  e.tickets.definirProduto(t.id, 'clean_30', ator);
  e.tickets.confirmarPagamento(t.id, { txId: 'Z', modo: 'manual' }, ator);

  const respostas = [];
  const interacao = (ativar) => ({
    channel: { id: 'T1', parentId: 'CANAL_TICKETS', isThread: () => true, name: 'x' }, guild: e.guild, user: { id: 'S', tag: 's' },
    options: { getBoolean: () => ativar },
    reply: async (c) => respostas.push(c),
  });

  await handlers.prioridade(interacao(null), e.ctx); // padrão = ativar
  assert.equal(e.tickets.obter(t.id).prioridade, 1);
  const agora = Date.now();
  const emb = montarEmbeds(e.tickets.snapshot(agora), agora, { prazoHoras: 42, avisoHorasAntes: 12, limiteAcumulada: 0 });
  assert.match(JSON.stringify(emb.map((x) => x.toJSON())), /⚡/);

  await assert.rejects(handlers.prioridade(interacao(true), e.ctx), /já está com prioridade/);
  await handlers.prioridade(interacao(false), e.ctx);
  assert.equal(e.tickets.obter(t.id).prioridade, 0);
});

test('ticket abre como no Rio Bot (sem menu de produto) e o menu volta com MENU_PRODUTO=sim', async () => {
  const e = montar({ textoOcr: '' });
  const enviados = [];
  let n = 0;
  const criarThread = async () => ({ id: `TH${++n}`, send: async (m) => enviados.push(m), delete: async () => {} });
  const interacao = {
    user: { id: 'U9', username: 'fulano', tag: 'fulano#1' },
    deferReply: async () => {}, editReply: async () => {},
    client: e.ctx.client,
    channel: { id: 'CANAL_TICKETS', threads: { create: criarThread } },
  };
  await abrirTicket(interacao, e.ctx, acharCategoria('adquirir_edit'));
  assert.equal(enviados[0].components.length, 0);
  assert.doesNotMatch(enviados[0].content, /Escolha abaixo/);
  assert.match(enviados[1].content, /fechar o ticket/);
  assert.equal(enviados[1].components[0].toJSON().components[0].custom_id, 'fechar_ticket');

  const interacao2 = { ...interacao, user: { id: 'U8', username: 'beltrano', tag: 'b#1' } };
  e.ctx.config.ticket.menuProduto = true;
  try {
    await abrirTicket(interacao2, e.ctx, acharCategoria('adquirir_edit'));
  } finally {
    e.ctx.config.ticket.menuProduto = false;
  }
  assert.equal(enviados[2].components.length, 1, 'com MENU_PRODUTO=sim a boas-vindas leva o menu');
  assert.equal(enviados[3].components[0].toJSON().components[0].custom_id, 'fechar_ticket');
});
