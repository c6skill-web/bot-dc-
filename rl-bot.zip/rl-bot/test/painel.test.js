'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { novoBanco } = require('./helpers/banco');
const { criarServicoTickets } = require('../src/services/tickets');
const { montarEmbeds, campoLista } = require('../src/services/painel');
const config = require('../src/config');

const ator = { id: 's', nome: 's' };
const opc = { prazoHoras: 42, avisoHorasAntes: 12, limiteAcumulada: 3 };

function cenario(qtdClean = 3) {
  const db = novoBanco();
  const rel = { t: new Date('2026-10-10T12:00:00-03:00').getTime() };
  const tk = criarServicoTickets(db, { produtos: config.produtos, agora: () => rel.t });
  for (let i = 1; i <= qtdClean; i++) {
    const t = tk.criar({ threadId: `t${i}`, userId: String(i), userName: `u${i}`, categoria: 'adquirir_edit' }, ator);
    tk.definirProduto(t.id, 'clean_30', ator);
    tk.confirmarPagamento(t.id, { txId: `X${i}`, modo: 'auto' }, ator);
  }
  return { tk, rel };
}

test('painel mostra contagens, listas e respeita limites do Discord', () => {
  const { tk, rel } = cenario(3);
  tk.mudarStatus(1, 'EM_PRODUCAO', ator);
  const emb = montarEmbeds(tk.snapshot(rel.t), rel.t, opc).map((e) => e.toJSON());
  assert.equal(emb.length, 3);
  assert.match(JSON.stringify(emb[0]), /Pendentes: \*\*2\*\*/);
  assert.match(emb[1].fields[1].value, /restam 42h00/);
  for (const e of emb) {
    const total = JSON.stringify(e).length;
    assert.ok(total < 6000);
    for (const f of e.fields || []) assert.ok(f.value.length <= 1024);
  }
});

test('alertas: atrasado (vermelho) e fila acumulada', () => {
  const { tk, rel } = cenario(3);
  tk.mudarStatus(1, 'EM_PRODUCAO', ator);
  rel.t += 43 * 3600_000;
  const emb = montarEmbeds(tk.snapshot(rel.t), rel.t, opc).map((e) => e.toJSON());
  assert.equal(emb[0].color, 0xe74c3c);
  assert.match(JSON.stringify(emb[0]), /atrasado/);
  const acum = montarEmbeds(tk.snapshot(rel.t), rel.t, { ...opc, limiteAcumulada: 2 })[0].toJSON();
  assert.match(JSON.stringify(acum), /acumulada/);
});

test('com 200 pedidos a lista é cortada e ainda cabe no embed', () => {
  const { tk, rel } = cenario(200);
  const emb = montarEmbeds(tk.snapshot(rel.t), rel.t, opc).map((e) => e.toJSON());
  assert.match(emb[1].fields[0].value, /… e mais/);
  for (const e of emb) assert.ok(JSON.stringify(e).length < 6000);
});

test('campoLista vazio', () => assert.equal(campoLista([]), '—'));
